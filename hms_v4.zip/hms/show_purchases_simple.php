<?php
// Show recent purchases (inventory withdrawals) in plain text format
require_once 'config/config.php';

echo "=== RECENT PURCHASES (INVENTORY WITHDRAWALS) ===\n\n";

try {
    // Get recent withdrawals
    $sql = "SELECT 
                w.withdrawal_id,
                w.withdrawal_date,
                w.customer_name,
                w.sale_type,
                w.payment_status,
                w.amount_due,
                w.amount_paid,
                w.discount_value,
                w.discount_type,
                w.status,
                COUNT(wi.withdrawal_item_id) as total_items
            FROM inventory_withdrawals w
            LEFT JOIN inventory_withdrawal_items wi ON w.withdrawal_id = wi.withdrawal_id
            GROUP BY w.withdrawal_id
            ORDER BY w.withdrawal_date DESC
            LIMIT 10";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "SUMMARY:\n";
        echo "- Total Recent Withdrawals: " . $result->num_rows . "\n\n";
        
        echo "RECENT WITHDRAWALS:\n";
        echo str_repeat("=", 120) . "\n";
        printf("%-5s %-20s %-20s %-10s %-6s %-12s %-12s %-12s %-12s %-12s\n", 
               "ID", "Date", "Customer", "Sale Type", "Items", "Amount Due", "Amount Paid", "Discount", "Payment", "Status");
        echo str_repeat("=", 120) . "\n";
        
        while ($row = $result->fetch_assoc()) {
            $discount_display = "";
            if ($row['discount_value'] > 0) {
                if ($row['discount_type'] == 'percentage') {
                    $discount_display = $row['discount_value'] . "%";
                } else {
                    $discount_display = "₱" . number_format($row['discount_value'], 2);
                }
            } else {
                $discount_display = "-";
            }
            
            printf("%-5s %-20s %-20s %-10s %-6s %-12s %-12s %-12s %-12s %-12s\n",
                   "#" . $row['withdrawal_id'],
                   date('M d, Y H:i', strtotime($row['withdrawal_date'])),
                   substr($row['customer_name'], 0, 18),
                   ucfirst($row['sale_type']),
                   $row['total_items'],
                   "₱" . number_format($row['amount_due'], 2),
                   "₱" . number_format($row['amount_paid'], 2),
                   $discount_display,
                   ucfirst($row['payment_status']),
                   ucfirst($row['status']));
        }
        echo str_repeat("=", 120) . "\n\n";
        
        // Show detailed items for recent withdrawals
        echo "DETAILED ITEMS IN RECENT WITHDRAWALS:\n";
        echo str_repeat("=", 100) . "\n";
        
        $detailSql = "SELECT 
                        w.withdrawal_id,
                        w.withdrawal_date,
                        w.customer_name,
                        ii.item_name,
                        wi.quantity,
                        ii.price,
                        ii.unit,
                        (wi.quantity * ii.price) as total_item_cost
                    FROM inventory_withdrawals w
                    JOIN inventory_withdrawal_items wi ON w.withdrawal_id = wi.withdrawal_id
                    JOIN inventory_items ii ON wi.item_id = ii.item_id
                    ORDER BY w.withdrawal_date DESC, w.withdrawal_id DESC
                    LIMIT 20";
        
        $detailResult = $conn->query($detailSql);
        
        if ($detailResult->num_rows > 0) {
            printf("%-5s %-12s %-20s %-25s %-10s %-12s %-12s\n", 
                   "ID", "Date", "Customer", "Item", "Quantity", "Unit Price", "Total");
            echo str_repeat("=", 100) . "\n";
            
            while ($detail = $detailResult->fetch_assoc()) {
                printf("%-5s %-12s %-20s %-25s %-10s %-12s %-12s\n",
                       "#" . $detail['withdrawal_id'],
                       date('M d, Y', strtotime($detail['withdrawal_date'])),
                       substr($detail['customer_name'], 0, 18),
                       substr($detail['item_name'], 0, 23),
                       $detail['quantity'] . " " . $detail['unit'],
                       "₱" . number_format($detail['price'], 2),
                       "₱" . number_format($detail['total_item_cost'], 2));
            }
        }
        echo str_repeat("=", 100) . "\n\n";
        
        // Show recent inventory movements
        echo "RECENT INVENTORY MOVEMENTS:\n";
        echo str_repeat("=", 80) . "\n";
        
        $movementSql = "SELECT 
                          im.movement_id,
                          im.movement_date,
                          im.movement_type,
                          im.quantity,
                          im.notes,
                          ii.item_name
                      FROM inventory_movements im
                      JOIN inventory_items ii ON im.item_id = ii.item_id
                      ORDER BY im.movement_date DESC
                      LIMIT 10";
        
        $movementResult = $conn->query($movementSql);
        
        if ($movementResult->num_rows > 0) {
            printf("%-5s %-15s %-6s %-25s %-10s %-20s\n", 
                   "ID", "Date", "Type", "Item", "Quantity", "Notes");
            echo str_repeat("=", 80) . "\n";
            
            while ($movement = $movementResult->fetch_assoc()) {
                $typeSymbol = $movement['movement_type'] == 'in' ? '↑ IN' : '↓ OUT';
                
                printf("%-5s %-15s %-6s %-25s %-10s %-20s\n",
                       "#" . $movement['movement_id'],
                       date('M d, Y H:i', strtotime($movement['movement_date'])),
                       $typeSymbol,
                       substr($movement['item_name'], 0, 23),
                       $movement['quantity'],
                       substr($movement['notes'], 0, 18));
            }
        }
        echo str_repeat("=", 80) . "\n\n";
        
        // Show current inventory levels (low stock items)
        echo "CURRENT INVENTORY LEVELS (LOW STOCK ITEMS):\n";
        echo str_repeat("=", 90) . "\n";
        
        $inventorySql = "SELECT 
                           ii.item_id,
                           ii.item_name,
                           ii.quantity_in_stock,
                           ii.reorder_level,
                           ii.unit,
                           ii.price,
                           ic.category_name
                       FROM inventory_items ii
                       JOIN inventory_categories ic ON ii.category_id = ic.category_id
                       WHERE ii.status = 'active' AND ii.quantity_in_stock <= ii.reorder_level
                       ORDER BY ii.quantity_in_stock ASC";
        
        $inventoryResult = $conn->query($inventorySql);
        
        if ($inventoryResult->num_rows > 0) {
            printf("%-5s %-25s %-15s %-12s %-12s %-12s\n", 
                   "ID", "Item Name", "Category", "Current", "Reorder", "Unit Price");
            echo str_repeat("=", 90) . "\n";
            
            while ($inventory = $inventoryResult->fetch_assoc()) {
                printf("%-5s %-25s %-15s %-12s %-12s %-12s\n",
                       "#" . $inventory['item_id'],
                       substr($inventory['item_name'], 0, 23),
                       substr($inventory['category_name'], 0, 13),
                       $inventory['quantity_in_stock'] . " " . $inventory['unit'],
                       $inventory['reorder_level'] . " " . $inventory['unit'],
                       "₱" . number_format($inventory['price'], 2));
            }
        } else {
            echo "No low stock items found.\n";
        }
        echo str_repeat("=", 90) . "\n\n";
        
    } else {
        echo "No recent withdrawals found.\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "You can also view the detailed HTML version by accessing: http://localhost/hms/show_recent_purchases.php\n";
?> 