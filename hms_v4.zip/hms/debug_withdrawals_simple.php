<!DOCTYPE html>
<html>
<head>
    <title>Withdrawals Debug</title>
    <link rel="stylesheet" href="css/bulma.min.css">
    <style>
        .debug-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { background-color: #d4edda; border-color: #c3e6cb; }
        .error { background-color: #f8d7da; border-color: #f5c6cb; }
        .info { background-color: #d1ecf1; border-color: #bee5eb; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="title">Inventory Withdrawals Debug Tool</h1>
        
        <div class="debug-section info">
            <h3 class="subtitle">Step 1: Testing API Endpoint</h3>
            <button class="button is-primary" onclick="testAPI()">Test API Call</button>
            <div id="apiResult"></div>
        </div>
        
        <div class="debug-section info">
            <h3 class="subtitle">Step 2: Testing Inventory Items</h3>
            <button class="button is-info" onclick="testInventoryItems()">Test Inventory Items</button>
            <div id="inventoryResult"></div>
        </div>
        
        <div class="debug-section info">
            <h3 class="subtitle">Step 3: Testing Direct Database Query</h3>
            <div id="dbResult">
                <?php
                require_once 'config/config.php';
                
                try {
                    $sql = "SELECT w.withdrawal_id, w.customer_name, w.withdrawal_date, w.status, w.sale_type,
                                   w.payment_status, w.amount_due, w.amount_paid
                            FROM inventory_withdrawals w
                            ORDER BY w.withdrawal_date DESC 
                            LIMIT 5";
                    $result = $conn->query($sql);
                    
                    if ($result && $result->num_rows > 0) {
                        echo "<div class='notification is-success'>✅ Found " . $result->num_rows . " withdrawals</div>";
                        echo "<table class='table is-striped is-fullwidth'>";
                        echo "<thead><tr><th>ID</th><th>Customer</th><th>Date</th><th>Status</th><th>Sale Type</th><th>Payment</th><th>Amount Due</th></tr></thead><tbody>";
                        
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['withdrawal_id'] . "</td>";
                            echo "<td>" . htmlspecialchars($row['customer_name']) . "</td>";
                            echo "<td>" . $row['withdrawal_date'] . "</td>";
                            echo "<td><span class='tag'>" . $row['status'] . "</span></td>";
                            echo "<td>" . $row['sale_type'] . "</td>";
                            echo "<td>" . $row['payment_status'] . "</td>";
                            echo "<td>₱" . number_format($row['amount_due'], 2) . "</td>";
                            echo "</tr>";
                        }
                        echo "</tbody></table>";
                    } else {
                        echo "<div class='notification is-warning'>⚠️ No withdrawals found in database</div>";
                    }
                } catch (Exception $e) {
                    echo "<div class='notification is-danger'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</div>";
                }
                ?>
            </div>
        </div>
        
        <div class="debug-section info">
            <h3 class="subtitle">Step 4: Test Page Elements</h3>
            <button class="button is-warning" onclick="testPageElements()">Test DOM Elements</button>
            <div id="domResult"></div>
        </div>
        
        <div class="debug-section info">
            <h3 class="subtitle">Step 5: Navigation</h3>
            <a href="inventory_withdrawals.php" class="button is-link">🔗 Go to Withdrawals Page</a>
            <a href="controllers/InventoryWithdrawalController.php?action=list" class="button is-success" target="_blank">🔗 Test API Directly</a>
        </div>
    </div>

    <script>
        async function testAPI() {
            const resultDiv = document.getElementById('apiResult');
            resultDiv.innerHTML = '<div class="notification is-info">Testing API...</div>';
            
            try {
                const response = await fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6');
                const data = await response.json();
                
                if (data.success) {
                    resultDiv.innerHTML = `
                        <div class="notification is-success">
                            ✅ API Working! Found ${data.withdrawals.length} withdrawals
                        </div>
                        <pre>${JSON.stringify(data, null, 2)}</pre>
                    `;
                } else {
                    resultDiv.innerHTML = `
                        <div class="notification is-danger">
                            ❌ API Error: ${data.message}
                        </div>
                    `;
                }
            } catch (error) {
                resultDiv.innerHTML = `
                    <div class="notification is-danger">
                        ❌ Network Error: ${error.message}
                    </div>
                `;
            }
        }
        
        async function testInventoryItems() {
            const resultDiv = document.getElementById('inventoryResult');
            resultDiv.innerHTML = '<div class="notification is-info">Testing inventory items...</div>';
            
            try {
                const response = await fetch('controllers/InventoryWithdrawalController.php?action=inventory-items');
                const data = await response.json();
                
                if (data.success) {
                    resultDiv.innerHTML = `
                        <div class="notification is-success">
                            ✅ Inventory Items Working! Found ${data.items.length} items
                        </div>
                        <details>
                            <summary>View Items Data</summary>
                            <pre>${JSON.stringify(data, null, 2)}</pre>
                        </details>
                    `;
                } else {
                    resultDiv.innerHTML = `
                        <div class="notification is-danger">
                            ❌ Inventory API Error: ${data.message}
                        </div>
                    `;
                }
            } catch (error) {
                resultDiv.innerHTML = `
                    <div class="notification is-danger">
                        ❌ Inventory Network Error: ${error.message}
                    </div>
                `;
            }
        }
        
        function testPageElements() {
            const resultDiv = document.getElementById('domResult');
            const elements = [
                'withdrawalsGrid',
                'searchInput', 
                'statusFilter',
                'saleTypeFilter',
                'sortBy',
                'loadingSpinner',
                'emptyState',
                'pagination'
            ];
            
            let html = '<div class="notification is-info">Checking DOM elements...</div>';
            elements.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    html += `<div class="tag is-success">${id}: ✅ Found</div> `;
                } else {
                    html += `<div class="tag is-danger">${id}: ❌ Missing</div> `;
                }
            });
            
            resultDiv.innerHTML = html;
        }
        
        // Auto-run basic tests on page load
        window.addEventListener('DOMContentLoaded', () => {
            console.log('🔧 Withdrawals Debug Tool Loaded');
            
            // Check if we can access the main classes
            if (typeof WithdrawalManager !== 'undefined') {
                console.log('✅ WithdrawalManager class is available');
            } else {
                console.log('❌ WithdrawalManager class is not available');
            }
        });
    </script>
</body>
</html> 