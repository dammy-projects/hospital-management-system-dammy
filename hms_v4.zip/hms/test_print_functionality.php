<?php
// Test script for print functionality
require_once 'config/config.php';

echo "<h2>Print Functionality Test</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
    .button { background: #3273dc; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; text-decoration: none; display: inline-block; }
    .button:hover { background: #2366d1; }
    .button.success { background: #48c774; }
    .button.info { background: #3298dc; }
    .button.warning { background: #ffdd57; color: #363636; }
</style>";

echo "<div class='test-section'>";
echo "<h3>🖨️ Print Report Test</h3>";
echo "<p class='info'>Testing the print functionality with different report types and filters.</p>";

// Test data availability
try {
    $sql = "SELECT COUNT(*) as total FROM inventory_withdrawals";
    $result = $conn->query($sql);
    $totalWithdrawals = $result->fetch_assoc()['total'];
    
    if ($totalWithdrawals > 0) {
        echo "<p class='success'>✅ Found $totalWithdrawals withdrawals in database - Print functionality can be tested</p>";
    } else {
        echo "<p class='error'>❌ No withdrawals found in database - Print functionality cannot be tested</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Database error: " . $e->getMessage() . "</p>";
}

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>📊 Test Print Reports</h3>";
echo "<p>Click the buttons below to test different print report types:</p>";

echo "<div style='margin: 10px 0;'>";
echo "<a href='inventory_withdrawals.php' class='button success'>Go to Inventory Withdrawals Page</a>";
echo "<p class='info'>Use the print buttons on the actual page to test the functionality.</p>";
echo "</div>";

echo "<h4>Print Report Types Available:</h4>";
echo "<ul>";
echo "<li><strong>Print Filtered Report:</strong> Shows a table view of all filtered withdrawals with totals</li>";
echo "<li><strong>Print Summary:</strong> Shows statistics, breakdowns by status, and top customers</li>";
echo "<li><strong>Print Detailed Report:</strong> Shows each withdrawal with complete item breakdown</li>";
echo "</ul>";

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>🔧 Manual Testing Instructions</h3>";
echo "<ol>";
echo "<li>Go to the <a href='inventory_withdrawals.php'>Inventory Withdrawals page</a></li>";
echo "<li>Apply any filters you want (date range, search, status, etc.)</li>";
echo "<li>Click one of the print buttons in the 'Print & Export' section</li>";
echo "<li>A new window should open with a formatted report</li>";
echo "<li>The print dialog should appear automatically</li>";
echo "</ol>";

echo "<h4>Expected Results:</h4>";
echo "<ul>";
echo "<li>Report shows hospital header with title and date</li>";
echo "<li>Filter information is displayed (date range, search terms, etc.)</li>";
echo "<li>Data is properly formatted in tables</li>";
echo "<li>Philippine Peso (₱) currency is used throughout</li>";
echo "<li>Each customer's purchased items are detailed</li>";
echo "<li>Totals and summaries are calculated correctly</li>";
echo "</ul>";

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>📋 Sample Print Data Preview</h3>";

try {
    // Get sample data to show what will be printed
    $sql = "SELECT 
                w.withdrawal_id, 
                w.withdrawal_date, 
                w.customer_name, 
                w.sale_type, 
                w.payment_status, 
                w.status,
                w.amount_due,
                w.amount_paid
            FROM inventory_withdrawals w 
            ORDER BY w.withdrawal_date DESC 
            LIMIT 3";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        echo "<p class='info'>Sample data that will appear in print reports:</p>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
        echo "<tr style='background-color: #f0f0f0;'>";
        echo "<th>ID</th><th>Date</th><th>Customer</th><th>Sale Type</th><th>Status</th><th>Amount Due</th><th>Amount Paid</th>";
        echo "</tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>#{$row['withdrawal_id']}</td>";
            echo "<td>" . date('M d, Y H:i', strtotime($row['withdrawal_date'])) . "</td>";
            echo "<td>{$row['customer_name']}</td>";
            echo "<td>" . ucfirst($row['sale_type']) . "</td>";
            echo "<td>" . ucfirst($row['status']) . "</td>";
            echo "<td>₱" . number_format($row['amount_due'], 2) . "</td>";
            echo "<td>₱" . number_format($row['amount_paid'], 2) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Get sample items for detailed report preview
        $itemsSql = "SELECT 
                        w.withdrawal_id,
                        w.customer_name,
                        ii.item_name,
                        wi.quantity,
                        ii.price
                    FROM inventory_withdrawals w
                    JOIN inventory_withdrawal_items wi ON w.withdrawal_id = wi.withdrawal_id
                    JOIN inventory_items ii ON wi.item_id = ii.item_id
                    WHERE w.withdrawal_id = (SELECT MIN(withdrawal_id) FROM inventory_withdrawals)
                    LIMIT 5";
        
        $itemsResult = $conn->query($itemsSql);
        
        if ($itemsResult && $itemsResult->num_rows > 0) {
            echo "<h4>Sample Item Details (for Detailed Report):</h4>";
            echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
            echo "<tr style='background-color: #f0f0f0;'>";
            echo "<th>Withdrawal ID</th><th>Customer</th><th>Item</th><th>Quantity</th><th>Unit Price</th><th>Total</th>";
            echo "</tr>";
            
            while ($item = $itemsResult->fetch_assoc()) {
                $itemTotal = $item['quantity'] * $item['price'];
                echo "<tr>";
                echo "<td>#{$item['withdrawal_id']}</td>";
                echo "<td>{$item['customer_name']}</td>";
                echo "<td>{$item['item_name']}</td>";
                echo "<td>{$item['quantity']}</td>";
                echo "<td>₱" . number_format($item['price'], 2) . "</td>";
                echo "<td>₱" . number_format($itemTotal, 2) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error fetching sample data: " . $e->getMessage() . "</p>";
}

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>🔗 Navigation Links</h3>";
echo "<p>";
echo "<a href='inventory_withdrawals.php' class='button success'>Test Print Functionality</a>";
echo "<a href='test_date_range_filter.php' class='button info'>Test Date Filters</a>";
echo "<a href='fix_withdrawals_display.php' class='button warning'>Display Diagnostic</a>";
echo "</p>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>💡 Print Features Summary</h3>";
echo "<div style='background-color: #f0f8ff; padding: 15px; border-radius: 5px;'>";
echo "<h4>🎯 Key Features:</h4>";
echo "<ul>";
echo "<li><strong>Filter-based printing</strong> - Only prints data matching current filters</li>";
echo "<li><strong>Multiple report types</strong> - Filtered table, summary statistics, detailed breakdown</li>";
echo "<li><strong>Complete item details</strong> - Shows every item purchased by each customer</li>";
echo "<li><strong>Professional formatting</strong> - Hospital header, proper tables, totals</li>";
echo "<li><strong>Philippine Peso currency</strong> - All amounts shown in ₱</li>";
echo "<li><strong>Date range information</strong> - Shows applied filters in the report</li>";
echo "<li><strong>Automatic totals</strong> - Calculates grand totals and subtotals</li>";
echo "<li><strong>Print-optimized layout</strong> - Proper page breaks and formatting</li>";
echo "</ul>";
echo "</div>";
echo "</div>";
?> 