// Inventory Withdrawals Management JavaScript
class WithdrawalManager {
    constructor() {
        this.currentPage = 1;
        this.itemsPerPage = 6;
        this.totalPages = 1;
        this.currentWithdrawalId = null;
        this.searchTimer = null;
        this.inventoryItems = []; // Initialize as empty array
        this.itemCounter = 0;
        this.isInitialized = false;
        this.initRetryCount = 0;
        this.maxRetries = 5;
        
        this.init();
    }
    
    async init() {
        try {
            // Wait for DOM to be fully ready with retries
            await this.waitForDOM();
            
            // Additional check - ensure critical elements exist
            if (!this.checkCriticalElements()) {
                console.warn('Critical elements not found, retrying in 100ms...');
                if (this.initRetryCount < this.maxRetries) {
                    this.initRetryCount++;
                    setTimeout(() => this.init(), 100);
                    return;
                }
                console.error('Failed to initialize after maximum retries');
                return;
            }
            
            this.initializeEventListeners();
            await this.loadInventoryItems();
            await this.loadWithdrawals();
            
            this.isInitialized = true;
            console.log('WithdrawalManager initialized successfully');
        } catch (error) {
            console.error('Error during initialization:', error);
            if (this.initRetryCount < this.maxRetries) {
                this.initRetryCount++;
                setTimeout(() => this.init(), 200);
            }
        }
    }

    checkCriticalElements() {
        const criticalIds = [
            'withdrawalsGrid',
            'addWithdrawalBtn',
            'loadingSpinner',
            'emptyState'
        ];
        
        return criticalIds.every(id => {
            const element = document.getElementById(id);
            if (!element) {
                console.warn(`Critical element missing: ${id}`);
                return false;
            }
            return true;
        });
    }

    waitForDOM() {
        return new Promise((resolve) => {
            if (document.readyState === 'complete' || 
                (document.readyState === 'interactive' && document.body)) {
                resolve();
            } else {
                const checkReady = () => {
                    if (document.readyState === 'complete' || 
                        (document.readyState === 'interactive' && document.body)) {
                        resolve();
                    } else {
                        setTimeout(checkReady, 10);
                    }
                };
                checkReady();
            }
        });
    }

    initializeEventListeners() {
        // Helper function to safely add event listeners with retries
        const safeAddEventListener = (id, event, handler) => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener(event, handler);
                return true;
            } else {
                console.warn(`Element with ID '${id}' not found during event binding`);
                return false;
            }
        };

        // Helper function to safely add event listener with querySelector
        const safeAddEventListenerQuery = (selector, event, handler) => {
            const element = document.querySelector(selector);
            if (element) {
                element.addEventListener(event, handler);
                return true;
            } else {
                console.warn(`Element with selector '${selector}' not found during event binding`);
                return false;
            }
        };

        // Add Withdrawal Button
        safeAddEventListener('addWithdrawalBtn', 'click', () => {
            this.openModal();
        });

        // Modal Close Buttons
        safeAddEventListener('closeModal', 'click', () => {
            this.closeModal();
        });

        safeAddEventListener('cancelModal', 'click', () => {
            this.closeModal();
        });

        safeAddEventListener('closeViewModal', 'click', () => {
                this.closeViewModal();
        });

        safeAddEventListener('closeViewModalBtn', 'click', () => {
            this.closeViewModal();
        });

        safeAddEventListener('closeDeleteModal', 'click', () => {
                this.closeDeleteModal();
        });

        safeAddEventListener('cancelDelete', 'click', () => {
            this.closeDeleteModal();
        });

        // Save Withdrawal Button
        safeAddEventListener('saveWithdrawal', 'click', () => {
            this.saveWithdrawal();
        });

        // Delete Confirmation
        safeAddEventListener('confirmDelete', 'click', () => {
            this.deleteWithdrawal();
        });

        // Print Button
        safeAddEventListener('printFromViewBtn', 'click', () => {
            if (this.currentWithdrawalId) {
                this.printWithdrawal(this.currentWithdrawalId);
            }
        });

        // Search Input with Debounce
        safeAddEventListener('searchInput', 'input', (e) => {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(() => {
                this.currentPage = 1;
                this.loadWithdrawals();
            }, 300);
        });

        // Filter Dropdowns
        safeAddEventListener('statusFilter', 'change', () => {
            this.currentPage = 1;
            this.loadWithdrawals();
        });

        safeAddEventListener('saleTypeFilter', 'change', () => {
            this.currentPage = 1;
            this.loadWithdrawals();
        });

        safeAddEventListener('sortBy', 'change', () => {
            this.currentPage = 1;
            this.loadWithdrawals();
        });

        // Clear Filters Button
        safeAddEventListener('clearFilters', 'click', () => {
            this.clearFilters();
        });

        // Pagination
        safeAddEventListener('prevPage', 'click', () => {
            if (this.currentPage > 1) {
                this.currentPage--;
                this.loadWithdrawals();
            }
        });

        safeAddEventListener('nextPage', 'click', () => {
            if (this.currentPage < this.totalPages) {
                this.currentPage++;
                this.loadWithdrawals();
            }
        });

        // Add Item Button
        safeAddEventListener('addItemBtn', 'click', () => {
            this.addItemEntry();
        });

        // Auto-calculation event listeners
        safeAddEventListener('discountValue', 'input', () => {
            this.calculateTotals();
        });

        safeAddEventListener('discountType', 'change', () => {
            this.calculateTotals();
        });

        safeAddEventListener('amountPaid', 'input', () => {
            this.calculateTotals();
        });

        // Modal Background Click
        safeAddEventListenerQuery('#withdrawalModal .modal-background', 'click', () => {
            this.closeModal();
        });

        safeAddEventListenerQuery('#viewWithdrawalModal .modal-background', 'click', () => {
            this.closeViewModal();
        });

        safeAddEventListenerQuery('#deleteModal .modal-background', 'click', () => {
            this.closeDeleteModal();
        });
        
        console.log('Event listeners initialized');
    }

    calculateTotals() {
        try {
            // Calculate subtotal from all items
            let subtotal = 0;
            const itemEntries = document.querySelectorAll('.item-entry');
            
            itemEntries.forEach(entry => {
                const itemSelect = entry.querySelector('select[name="item_id"]');
                const quantityInput = entry.querySelector('input[name="quantity"]');
                
                if (itemSelect && quantityInput && itemSelect.value && quantityInput.value) {
                    const selectedItem = this.inventoryItems.find(item => item.item_id == itemSelect.value);
                    if (selectedItem) {
                        const quantity = parseInt(quantityInput.value) || 0;
                        const price = parseFloat(selectedItem.price) || 0;
                        subtotal += quantity * price;
                    }
                }
            });

            // Update subtotal display
            this.setElementValue('subtotal', `₱${subtotal.toFixed(2)}`);

            // Calculate discount
            const discountValue = parseFloat(this.getElementValue('discountValue')) || 0;
            const discountType = this.getElementValue('discountType') || 'percentage';
            
            let discountAmount = 0;
            if (discountValue > 0) {
                if (discountType === 'percentage') {
                    discountAmount = (subtotal * discountValue) / 100;
                } else {
                    discountAmount = discountValue;
                }
            }

            // Ensure discount doesn't exceed subtotal
            discountAmount = Math.min(discountAmount, subtotal);

            // Update discount amount display
            this.setElementValue('discountAmount', `-₱${discountAmount.toFixed(2)}`);

            // Calculate final amount due
            const totalAmountDue = subtotal - discountAmount;
            this.setElementValue('totalAmountDue', `₱${totalAmountDue.toFixed(2)}`);
            this.setElementValue('amountDue', totalAmountDue.toFixed(2)); // Hidden field for form submission

            // Calculate balance
            const amountPaid = parseFloat(this.getElementValue('amountPaid')) || 0;
            const balance = totalAmountDue - amountPaid;
            this.setElementValue('balance', `₱${balance.toFixed(2)}`);

            // Update balance color based on value
            const balanceInput = document.getElementById('balance');
            if (balanceInput) {
                balanceInput.classList.remove('has-text-success', 'has-text-danger', 'has-text-warning');
                if (balance === 0) {
                    balanceInput.classList.add('has-text-success');
                } else if (balance > 0) {
                    balanceInput.classList.add('has-text-danger');
                } else {
                    balanceInput.classList.add('has-text-warning');
                }
            }

        } catch (error) {
            console.error('Error calculating totals:', error);
        }
    }

    getElementValue(id) {
        try {
            const element = document.getElementById(id);
            return element && element.value !== undefined ? element.value : '';
        } catch (error) {
            console.warn(`Error accessing element ${id}:`, error);
            return '';
        }
    }

    setElementValue(id, value) {
        try {
            const element = document.getElementById(id);
            if (element) {
                element.value = value;
            }
        } catch (error) {
            console.warn(`Error setting element ${id}:`, error);
        }
    }
    
    async loadWithdrawals() {
        if (!this.isInitialized) {
            console.log('Manager not initialized yet, skipping loadWithdrawals');
            return;
        }

        this.showLoading();
        
        try {
            // Safely get values from DOM elements with additional protection
            const getElementValue = (id) => {
                try {
                    const element = document.getElementById(id);
                    return element && element.value !== undefined ? element.value : '';
                } catch (error) {
                    console.warn(`Error accessing element ${id}:`, error);
                    return '';
                }
            };

            const params = new URLSearchParams({
                action: 'list',
                page: this.currentPage,
                limit: this.itemsPerPage,
                search: getElementValue('searchInput'),
                status: getElementValue('statusFilter'),
                sale_type: getElementValue('saleTypeFilter'),
                sort: getElementValue('sortBy') || 'withdrawal_date'
            });
            
            const response = await fetch(`controllers/InventoryWithdrawalController.php?${params}`);
            const data = await response.json();

            if (data.success) {
                this.renderWithdrawals(data.withdrawals);
                this.renderPagination(data.pagination);
                this.hideLoading();
                
                if (data.withdrawals.length === 0) {
                    this.showEmptyState();
                } else {
                    this.hideEmptyState();
                }
            } else {
                this.showError(data.message);
                this.hideLoading();
            }
        } catch (error) {
            console.error('Error loading withdrawals:', error);
            this.showError('Failed to load withdrawals');
            this.hideLoading();
        }
    }

    renderWithdrawals(withdrawals) {
        const container = document.getElementById('withdrawalsGrid');
        if (!container) {
            console.error('withdrawalsGrid container not found');
            return;
        }
        
        container.innerHTML = '';
        
        withdrawals.forEach(withdrawal => {
            const card = this.createWithdrawalCard(withdrawal);
            container.appendChild(card);
        });
    }
    
    createWithdrawalCard(withdrawal) {
        const column = document.createElement('div');
        column.className = 'column';

        const statusClass = this.getStatusClass(withdrawal.status);
        const paymentStatusClass = this.getPaymentStatusClass(withdrawal.payment_status);

        // Calculate total amount
        const totalAmount = withdrawal.items.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * parseInt(item.quantity));
        }, 0);

        // Format date
        const formattedDate = this.formatDate(withdrawal.withdrawal_date);
        
        column.innerHTML = `
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <div class="is-flex is-align-items-center is-justify-content-center" style="width: 48px; height: 48px; background: #f5f5f5; border-radius: 6px;">
                                    <span class="icon is-large has-text-primary">
                                        <i class="fas fa-shopping-cart"></i>
                            </span>
                                </div>
                            </figure>
                            </div>
                        <div class="media-content">
                            <p class="title is-6">${this.escapeHtml(withdrawal.customer_name)}</p>
                            <p class="subtitle is-7">
                                <span class="status-badge ${statusClass}">${withdrawal.status}</span>
                                <span class="payment-status-badge ${paymentStatusClass} ml-2">${withdrawal.payment_status}</span>
                            </p>
                            </div>
                        </div>
                        
                    <div class="content withdrawal-details">
                        <p><strong>Date:</strong> ${formattedDate}</p>
                        <p><strong>Sale Type:</strong> ${withdrawal.sale_type.charAt(0).toUpperCase() + withdrawal.sale_type.slice(1)}</p>
                        <p><strong>Items:</strong> ${withdrawal.items.length} item(s)</p>
                        <p><strong>Total Amount:</strong> ₱${totalAmount.toFixed(2)}</p>
                    </div>
                </div>
                <footer class="card-footer">
                    <a class="card-footer-item" onclick="withdrawalManager.viewWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-eye"></i></span>
                        <span>View</span>
                    </a>
                    <a class="card-footer-item" onclick="withdrawalManager.editWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-edit"></i></span>
                        <span>Edit</span>
                    </a>
                    <a class="card-footer-item" onclick="withdrawalManager.printWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-print"></i></span>
                        <span>Print</span>
                    </a>
                    <a class="card-footer-item has-text-danger" onclick="withdrawalManager.confirmDelete(${withdrawal.withdrawal_id}, '${this.escapeHtml(withdrawal.customer_name)}')">
                        <span class="icon"><i class="fas fa-trash"></i></span>
                        <span>Delete</span>
                    </a>
                </footer>
            </div>
        `;
        
        return column;
    }
    
    getStatusClass(status) {
        switch (status) {
            case 'pending': return 'has-background-warning has-text-warning-dark';
            case 'approved': return 'has-background-info has-text-info-dark';
            case 'completed': return 'has-background-success has-text-success-dark';
            case 'cancelled': return 'has-background-danger has-text-danger-dark';
            default: return 'has-background-grey-light has-text-grey-dark';
        }
    }

    getPaymentStatusClass(paymentStatus) {
        switch (paymentStatus) {
            case 'paid': return 'has-background-success has-text-success-dark';
            case 'partial': return 'has-background-warning has-text-warning-dark';
            case 'unpaid': return 'has-background-danger has-text-danger-dark';
            default: return 'has-background-grey-light has-text-grey-dark';
        }
    }

    renderPagination(pagination) {
        const paginationContainer = document.getElementById('pagination');
        const paginationList = document.getElementById('paginationList');
        const prevPage = document.getElementById('prevPage');
        const nextPage = document.getElementById('nextPage');
        
        if (!paginationContainer || !paginationList || !prevPage || !nextPage) {
            console.error('Pagination elements not found');
            return;
        }
        
        this.totalPages = pagination.total_pages;
        this.currentPage = pagination.current_page;

        if (pagination.total_pages <= 1) {
            paginationContainer.style.display = 'none';
            return;
        }

        paginationContainer.style.display = 'flex';

        // Update navigation buttons
        prevPage.disabled = pagination.current_page === 1;
        nextPage.disabled = pagination.current_page === pagination.total_pages;

        // Clear existing page buttons
        paginationList.innerHTML = '';
        
        // Generate page buttons
        for (let i = 1; i <= pagination.total_pages; i++) {
            const li = document.createElement('li');
            const button = document.createElement('a');
            button.className = 'pagination-link';
            button.textContent = i;
            
            if (i === pagination.current_page) {
                button.classList.add('is-current');
            }
            
            button.addEventListener('click', () => {
                this.goToPage(i);
            });
            
            li.appendChild(button);
            paginationList.appendChild(li);
        }
    }

    goToPage(page) {
        this.currentPage = page;
        this.loadWithdrawals();
    }

    async loadInventoryItems() {
        try {
            const response = await fetch('controllers/InventoryWithdrawalController.php?action=inventory-items');
            const data = await response.json();

            if (data.success) {
                this.inventoryItems = data.items || [];
            } else {
                console.error('Failed to load inventory items:', data.message);
                this.inventoryItems = [];
            }
        } catch (error) {
            console.error('Error loading inventory items:', error);
            this.inventoryItems = [];
        }
    }

    openModal(withdrawal = null) {
        // Wait for inventory items to load if they haven't yet
        if (this.inventoryItems.length === 0) {
            this.loadInventoryItems().then(() => {
                this.openModal(withdrawal);
            });
            return;
        }

        const modal = document.getElementById('withdrawalModal');
        const modalTitle = document.getElementById('modalTitle');
        
        if (!modal || !modalTitle) {
            console.error('Modal elements not found');
            return;
        }

        this.currentWithdrawalId = withdrawal ? withdrawal.withdrawal_id : null;
        modalTitle.textContent = withdrawal ? 'Edit Withdrawal' : 'New Withdrawal';

        if (withdrawal) {
            this.populateForm(withdrawal);
        } else {
            this.clearForm();
            // Add one empty item entry by default
            this.addItemEntry();
        }

        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
    }

    clearForm() {
        // Helper function to safely set element values
        const setElementValue = (id, value) => {
            const element = document.getElementById(id);
            if (element) {
                element.value = value;
            }
        };

        setElementValue('withdrawalId', '');
        setElementValue('customerName', '');
        setElementValue('saleType', 'retail');
        setElementValue('status', 'pending');
        setElementValue('withdrawalDate', new Date().toISOString().slice(0, 16));
        setElementValue('paymentStatus', 'unpaid');
        setElementValue('amountDue', '0.00');
        setElementValue('amountPaid', '0.00');

        // Clear discount and calculation fields
        setElementValue('discountValue', '0');
        setElementValue('discountType', 'percentage');
        setElementValue('subtotal', '₱0.00');
        setElementValue('discountAmount', '-₱0.00');
        setElementValue('totalAmountDue', '₱0.00');
        setElementValue('balance', '₱0.00');

        // Clear items container
        const itemsContainer = document.getElementById('itemsContainer');
        if (itemsContainer) {
            itemsContainer.innerHTML = '';
        }
        this.itemCounter = 0;
        
        // Trigger calculation to reset displays
        this.calculateTotals();
    }
    
    closeModal() {
        const modal = document.getElementById('withdrawalModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        }
    }

    populateForm(withdrawal) {
        const setElementValue = (id, value) => {
            const element = document.getElementById(id);
            if (element) {
                element.value = value;
            }
        };

        setElementValue('withdrawalId', withdrawal.withdrawal_id);
        setElementValue('customerName', withdrawal.customer_name);
        setElementValue('saleType', withdrawal.sale_type);
        setElementValue('status', withdrawal.status);
        setElementValue('withdrawalDate', withdrawal.withdrawal_date.replace(' ', 'T'));
        setElementValue('paymentStatus', withdrawal.payment_status);
        setElementValue('amountDue', withdrawal.amount_due);
        setElementValue('amountPaid', withdrawal.amount_paid);

        // Handle discount fields (default to 0 if not present)
        setElementValue('discountValue', withdrawal.discount_value || '0');
        setElementValue('discountType', withdrawal.discount_type || 'percentage');

        // Clear and populate items
        const itemsContainer = document.getElementById('itemsContainer');
        if (itemsContainer) {
            itemsContainer.innerHTML = '';
        }
        this.itemCounter = 0;

        // Add items
        if (withdrawal.items && withdrawal.items.length > 0) {
            withdrawal.items.forEach(item => {
                this.addItemEntry(item);
            });
        } else {
            this.addItemEntry();
        }
        
        // Trigger calculations after populating form
        setTimeout(() => {
            this.calculateTotals();
        }, 100);
    }

    addItemEntry(item = null) {
        if (this.inventoryItems.length === 0) {
            this.showError('Inventory items not loaded. Please try again.');
            return;
        }

        const itemsContainer = document.getElementById('itemsContainer');
        if (!itemsContainer) {
            console.error('Items container not found');
            return;
        }

        const entryId = `item_${this.itemCounter++}`;
        const itemEntry = document.createElement('div');
        itemEntry.className = 'item-entry';
        itemEntry.id = entryId;

        // Find the item in inventory if editing
        const selectedItem = item ? this.inventoryItems.find(invItem => invItem.item_name === item.item_name) : null;
        
        itemEntry.innerHTML = `
            <button type="button" class="remove-item-btn" onclick="withdrawalManager.removeItemEntry('${entryId}')">
                    <i class="fas fa-times"></i>
                </button>
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Item *</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select name="item_id" required>
                                    <option value="">Select an item</option>
                                    ${this.inventoryItems.map(invItem => `
                                        <option value="${invItem.item_id}" ${selectedItem && selectedItem.item_id === invItem.item_id ? 'selected' : ''}>
                                            ${this.escapeHtml(invItem.item_name)} - ₱${parseFloat(invItem.price).toFixed(2)} (Stock: ${invItem.quantity_in_stock})
                                        </option>
                                    `).join('')}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-3">
                    <div class="field">
                        <label class="label">Quantity *</label>
                        <div class="control">
                            <input class="input" type="number" name="quantity" min="1" value="${item ? item.quantity : '1'}" required />
                        </div>
                    </div>
                </div>
                <div class="column is-3">
                    <div class="field">
                        <label class="label">Price</label>
                        <div class="control">
                            <input class="input" type="text" name="price" value="${selectedItem ? '₱' + parseFloat(selectedItem.price).toFixed(2) : '₱0.00'}" readonly />
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        itemsContainer.appendChild(itemEntry);

        // Add event listener for item selection change
        const itemSelect = itemEntry.querySelector('select[name="item_id"]');
        const priceInput = itemEntry.querySelector('input[name="price"]');
        const quantityInput = itemEntry.querySelector('input[name="quantity"]');
        
        if (itemSelect && priceInput) {
            itemSelect.addEventListener('change', (e) => {
                const selectedItemId = e.target.value;
                const selectedInventoryItem = this.inventoryItems.find(invItem => invItem.item_id == selectedItemId);
                
                if (selectedInventoryItem) {
                    priceInput.value = '₱' + parseFloat(selectedInventoryItem.price).toFixed(2);
            } else {
                    priceInput.value = '₱0.00';
                }
                
                // Trigger calculation when item changes
                this.calculateTotals();
            });
        }
        
        if (quantityInput) {
            quantityInput.addEventListener('input', () => {
                // Trigger calculation when quantity changes
                this.calculateTotals();
            });
        }
    }
    
    removeItemEntry(entryId) {
        const entry = document.getElementById(entryId);
        if (entry) {
            entry.remove();
        }
    }
    
    async saveWithdrawal() {
        const form = document.getElementById('withdrawalForm');
        if (!form) {
            this.showError('Form not found');
            return;
        }
        
        const formData = new FormData(form);
        const withdrawalId = document.getElementById('withdrawalId').value;
        
        // Collect items data
        const itemsContainer = document.getElementById('itemsContainer');
        const itemEntries = itemsContainer.querySelectorAll('.item-entry');
        const items = [];

        for (const entry of itemEntries) {
            const itemId = entry.querySelector('select[name="item_id"]').value;
            const quantity = entry.querySelector('input[name="quantity"]').value;
            
            if (itemId && quantity && parseInt(quantity) > 0) {
                items.push({
                    item_id: itemId,
                    quantity: parseInt(quantity)
                });
            }
        }

        if (items.length === 0) {
            this.showError('Please add at least one item');
            return;
        }

        const data = {
            action: withdrawalId ? 'update' : 'create',
            withdrawal_id: withdrawalId,
            customer_name: formData.get('customerName'),
            sale_type: formData.get('saleType'),
            status: formData.get('status'),
            withdrawal_date: formData.get('withdrawalDate'),
            payment_status: formData.get('paymentStatus'),
            amount_due: formData.get('amountDue'),
            amount_paid: formData.get('amountPaid'),
            discount_value: this.getElementValue('discountValue') || '0',
            discount_type: this.getElementValue('discountType') || 'percentage',
            items: items
        };

        try {
            const response = await fetch('controllers/InventoryWithdrawalController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                this.closeModal();
                this.loadWithdrawals();
            } else {
                this.showError(result.message);
            }
        } catch (error) {
            console.error('Error saving withdrawal:', error);
            this.showError('Failed to save withdrawal');
        }
    }

    async editWithdrawal(withdrawalId) {
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                this.openModal(data.withdrawal);
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal:', error);
            this.showError('Failed to load withdrawal');
        }
    }

    async viewWithdrawal(withdrawalId) {
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                this.currentWithdrawalId = withdrawalId;
                this.showWithdrawalDetails(data.withdrawal);
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal:', error);
            this.showError('Failed to load withdrawal');
        }
    }

    showWithdrawalDetails(withdrawal) {
        const modal = document.getElementById('viewWithdrawalModal');
        const detailsContainer = document.getElementById('withdrawalDetails');
        
        if (!modal || !detailsContainer) {
            console.error('View modal elements not found');
            return;
        }

        const statusClass = this.getStatusClass(withdrawal.status);
        const paymentStatusClass = this.getPaymentStatusClass(withdrawal.payment_status);
        const formattedDate = this.formatDate(withdrawal.withdrawal_date);

        // Calculate total amount
        const totalAmount = withdrawal.items.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * parseInt(item.quantity));
        }, 0);

        // Generate items table
        const itemsTable = withdrawal.items.map(item => {
            const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
            return `
                <tr>
                    <td>${this.escapeHtml(item.item_name)}</td>
                    <td>${item.quantity}</td>
                    <td>₱${parseFloat(item.price).toFixed(2)}</td>
                    <td>₱${itemTotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        detailsContainer.innerHTML = `
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Customer Name</label>
                        <div class="box">${this.escapeHtml(withdrawal.customer_name)}</div>
                    </div>
                </div>
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Withdrawal Date</label>
                        <div class="box">${formattedDate}</div>
                    </div>
                </div>
            </div>

            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Sale Type</label>
                        <div class="box">${withdrawal.sale_type.charAt(0).toUpperCase() + withdrawal.sale_type.slice(1)}</div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Status</label>
                        <div class="box">
                            <span class="status-badge ${statusClass}">${withdrawal.status}</span>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Payment Status</label>
                        <div class="box">
                            <span class="payment-status-badge ${paymentStatusClass}">${withdrawal.payment_status}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Calculation Display -->
            <div class="box has-background-light">
                <h5 class="title is-6 has-text-primary">
                    <span class="icon">
                        <i class="fas fa-calculator"></i>
                    </span>
                    Payment Breakdown
                </h5>
            
            <div class="columns">
                    <div class="column is-3">
                    <div class="field">
                            <label class="label">Subtotal</label>
                            <div class="box">₱${totalAmount.toFixed(2)}</div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Discount</label>
                            <div class="box">
                                ${withdrawal.discount_value && parseFloat(withdrawal.discount_value) > 0 ? 
                                    `${withdrawal.discount_value}${withdrawal.discount_type === 'percentage' ? '%' : ' ₱'}` : 
                                    'No discount'}
                </div>
                        </div>
                    </div>
                    <div class="column is-3">
                    <div class="field">
                            <label class="label">Discount Amount</label>
                            <div class="box has-text-danger">
                                ${withdrawal.discount_value && parseFloat(withdrawal.discount_value) > 0 ? 
                                    `-₱${this.calculateDiscountAmount(totalAmount, withdrawal.discount_value, withdrawal.discount_type).toFixed(2)}` : 
                                    '-₱0.00'}
                        </div>
                    </div>
                </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Final Amount</label>
                            <div class="box has-text-weight-bold has-text-primary">₱${parseFloat(withdrawal.amount_due).toFixed(2)}</div>
                    </div>
                </div>
            </div>
            
                <div class="columns">
                    <div class="column is-6">
                <div class="field">
                            <label class="label">Amount Paid</label>
                            <div class="box">₱${parseFloat(withdrawal.amount_paid).toFixed(2)}</div>
                    </div>
                </div>
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Balance</label>
                            <div class="box has-text-weight-bold ${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)) === 0 ? 'has-text-success' : 'has-text-danger'}">
                                ₱${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)).toFixed(2)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="field">
                <label class="label">Withdrawal Items</label>
                <table class="table is-fullwidth items-table">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${itemsTable}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3">Total Amount</th>
                            <th>₱${totalAmount.toFixed(2)}</th>
                                </tr>
                    </tfoot>
                    </table>
            </div>
        `;

        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
    }
    
    closeViewModal() {
        const modal = document.getElementById('viewWithdrawalModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        }
    }

    confirmDelete(withdrawalId, customerName) {
        const modal = document.getElementById('deleteModal');
        const deleteInfo = document.getElementById('deleteWithdrawalInfo');
        
        if (!modal || !deleteInfo) {
            console.error('Delete modal elements not found');
            return;
        }

        this.currentWithdrawalId = withdrawalId;
        deleteInfo.textContent = `Withdrawal for ${customerName}`;
        
        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
    }
    
    closeDeleteModal() {
        const modal = document.getElementById('deleteModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        }
    }
    
    async deleteWithdrawal() {
        if (!this.currentWithdrawalId) {
            this.showError('No withdrawal selected');
            return;
        }

        try {
            const response = await fetch('controllers/InventoryWithdrawalController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'delete',
                    withdrawal_id: this.currentWithdrawalId
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                this.closeDeleteModal();
                this.loadWithdrawals();
            } else {
                this.showError(result.message);
            }
        } catch (error) {
            console.error('Error deleting withdrawal:', error);
            this.showError('Failed to delete withdrawal');
        }
    }

    async printWithdrawal(withdrawalId) {
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                const printContent = this.generatePrintContent(data.withdrawal);
                const printArea = document.getElementById('withdrawalPrintArea');
                if (printArea) {
                    printArea.innerHTML = printContent;
                    printArea.style.display = 'block';
                    window.print();
                    printArea.style.display = 'none';
                }
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal for printing:', error);
            this.showError('Failed to load withdrawal for printing');
        }
    }

    generatePrintContent(withdrawal) {
        const formattedDate = this.formatDate(withdrawal.withdrawal_date);
        const currentDate = new Date().toLocaleDateString();
        
        // Calculate total amount
        const totalAmount = withdrawal.items.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * parseInt(item.quantity));
        }, 0);

        // Generate items table
        const itemsTable = withdrawal.items.map(item => {
            const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
            return `
                <tr>
                    <td>${this.escapeHtml(item.item_name)}</td>
                    <td>${item.quantity}</td>
                    <td>₱${parseFloat(item.price).toFixed(2)}</td>
                    <td>₱${itemTotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        return `
            <div class="print-header">
                <h1 class="print-title">Hospital Management System</h1>
                <p class="print-subtitle">Inventory Withdrawal Receipt</p>
            </div>

            <div class="print-section">
                <h3>Customer Information</h3>
                <div class="print-grid">
                    <div><strong>Customer Name:</strong> ${this.escapeHtml(withdrawal.customer_name)}</div>
                    <div><strong>Date:</strong> ${formattedDate}</div>
                    <div><strong>Sale Type:</strong> ${withdrawal.sale_type.charAt(0).toUpperCase() + withdrawal.sale_type.slice(1)}</div>
                    <div><strong>Status:</strong> ${withdrawal.status}</div>
                </div>
            </div>

            <div class="print-section">
                <h3>Items Withdrawn</h3>
                <table class="print-items-table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsTable}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3">Total Amount</th>
                            <th>₱${totalAmount.toFixed(2)}</th>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="print-section">
                <h3>Payment Information</h3>
                <div class="print-grid">
                    <div><strong>Amount Due:</strong> ₱${parseFloat(withdrawal.amount_due).toFixed(2)}</div>
                    <div><strong>Amount Paid:</strong> ₱${parseFloat(withdrawal.amount_paid).toFixed(2)}</div>
                    <div><strong>Balance:</strong> ₱${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)).toFixed(2)}</div>
                    <div><strong>Payment Status:</strong> ${withdrawal.payment_status}</div>
                </div>
            </div>

            <div class="print-footer">
                <p>Printed on: ${currentDate}</p>
                <p>Thank you for your business!</p>
            </div>
        `;
    }

    clearFilters() {
        const setElementValue = (id, value) => {
            const element = document.getElementById(id);
            if (element) {
                element.value = value;
            }
        };

        setElementValue('searchInput', '');
        setElementValue('statusFilter', '');
        setElementValue('saleTypeFilter', '');
        setElementValue('sortBy', 'withdrawal_date');
        
        this.currentPage = 1;
        this.loadWithdrawals();
    }
    
    showLoading() {
        const spinner = document.getElementById('loadingSpinner');
        const container = document.getElementById('withdrawalsContainer');
        
        if (spinner) spinner.style.display = 'block';
        if (container) container.style.display = 'none';
    }
    
    hideLoading() {
        const spinner = document.getElementById('loadingSpinner');
        const container = document.getElementById('withdrawalsContainer');
        
        if (spinner) spinner.style.display = 'none';
        if (container) container.style.display = 'block';
    }
    
    showEmptyState() {
        const emptyState = document.getElementById('emptyState');
        if (emptyState) emptyState.style.display = 'block';
    }
    
    hideEmptyState() {
        const emptyState = document.getElementById('emptyState');
        if (emptyState) emptyState.style.display = 'none';
    }

    showSuccess(message) {
        this.showNotification(message, 'is-success');
    }

    showError(message) {
        this.showNotification(message, 'is-danger');
    }

    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type} is-fixed`;
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.style.minWidth = '300px';
        notification.innerHTML = `
            <button class="delete"></button>
            ${message}
        `;
        
        document.body.appendChild(notification);
        
        // Add click handler to close button
        const closeButton = notification.querySelector('.delete');
        closeButton.addEventListener('click', () => {
            notification.remove();
        });
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
    
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    calculateDiscountAmount(subtotal, discountValue, discountType) {
        let discountAmount = 0;
        if (discountValue > 0) {
            if (discountType === 'percentage') {
                discountAmount = (subtotal * discountValue) / 100;
            } else {
                discountAmount = discountValue;
            }
        }
        return discountAmount;
    }
}

// Initialize the withdrawal manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.withdrawalManager = new WithdrawalManager();
}); 
