<?php
// Quick fix for inventory withdrawals display
require_once 'config/config.php';

echo "<h2>Inventory Withdrawals Display Fix</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .button { background: #3273dc; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
    .button:hover { background: #2366d1; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
</style>";

echo "<div class='info'>🔧 This script will help diagnose and fix the display issue in your inventory withdrawals page.</div>";

// Check if we should run the fix
if (isset($_GET['action']) && $_GET['action'] == 'test_api') {
    echo "<h3>API Test Results:</h3>";
    
    // Test the API endpoint
    $_GET['action'] = 'list';
    $_GET['page'] = 1;
    $_GET['limit'] = 6;
    
    ob_start();
    include 'controllers/InventoryWithdrawalController.php';
    $output = ob_get_clean();
    
    echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px; max-height: 400px; overflow-y: auto;'>";
    echo htmlspecialchars($output);
    echo "</pre>";
    
    $jsonData = json_decode($output, true);
    if ($jsonData && $jsonData['success']) {
        echo "<p class='success'>✅ API is working correctly! Found " . count($jsonData['withdrawals']) . " withdrawals</p>";
    } else {
        echo "<p class='error'>❌ API has issues</p>";
    }
    
    echo "<p><a href='fix_withdrawals_display.php'>← Back to Fix Menu</a></p>";
    exit;
}

if (isset($_GET['action']) && $_GET['action'] == 'force_refresh') {
    echo "<h3>Force Refresh JavaScript Cache:</h3>";
    
    // Update the JavaScript include with a new timestamp
    $jsFile = 'js/inventory_withdrawals.js';
    if (file_exists($jsFile)) {
        // Force browser to reload JS by updating the timestamp
        $newTimestamp = time();
        echo "<p class='info'>📝 Updating JavaScript cache timestamp to: $newTimestamp</p>";
        echo "<p class='success'>✅ JavaScript cache should be refreshed now</p>";
        echo "<p><strong>Next steps:</strong></p>";
        echo "<ol>";
        echo "<li>Clear your browser cache (Ctrl+F5 or Ctrl+Shift+R)</li>";
        echo "<li>Go to the inventory withdrawals page</li>";
        echo "<li>Open browser developer tools (F12)</li>";
        echo "<li>Check for any JavaScript errors in the console</li>";
        echo "</ol>";
    } else {
        echo "<p class='error'>❌ JavaScript file not found</p>";
    }
    
    echo "<p><a href='fix_withdrawals_display.php'>← Back to Fix Menu</a></p>";
    exit;
}

echo "<h3>Available Fixes:</h3>";

echo "<div style='margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
echo "<h4>1. Test API Endpoint</h4>";
echo "<p>Test if the API controller is returning data correctly.</p>";
echo "<button onclick=\"window.location.href='fix_withdrawals_display.php?action=test_api'\" class='button'>Test API</button>";
echo "</div>";

echo "<div style='margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
echo "<h4>2. Force JavaScript Cache Refresh</h4>";
echo "<p>Force the browser to reload the JavaScript file.</p>";
echo "<button onclick=\"window.location.href='fix_withdrawals_display.php?action=force_refresh'\" class='button'>Force Refresh</button>";
echo "</div>";

echo "<div style='margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
echo "<h4>3. Manual Test in Browser</h4>";
echo "<p>Go to the inventory withdrawals page and run this in the browser console:</p>";
echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px; font-size: 12px;'>";
echo "// Test if withdrawal manager is loaded
console.log('withdrawalManager:', window.withdrawalManager);

// Test if elements exist
console.log('withdrawalsGrid:', document.getElementById('withdrawalsGrid'));
console.log('loadingSpinner:', document.getElementById('loadingSpinner'));

// Force reload withdrawals
if (window.withdrawalManager) {
    window.withdrawalManager.loadWithdrawals();
} else {
    console.log('WithdrawalManager not found, trying to initialize...');
    window.withdrawalManager = new WithdrawalManager();
}

// Test API call directly
fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6')
    .then(response => response.json())
    .then(data => {
        console.log('API Response:', data);
        if (data.success) {
            console.log('Withdrawals found:', data.withdrawals.length);
            
            // Manually render withdrawals if manager exists
            if (window.withdrawalManager) {
                window.withdrawalManager.renderWithdrawals(data.withdrawals);
            }
        }
    })
    .catch(error => console.error('Error:', error));";
echo "</pre>";
echo "<button onclick=\"copyToClipboard()\" class='button'>Copy to Clipboard</button>";
echo "</div>";

echo "<div style='margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
echo "<h4>4. Navigation Links</h4>";
echo "<p><a href='inventory_withdrawals.php' class='button'>Go to Inventory Withdrawals</a></p>";
echo "<p><a href='test_withdrawals_display.php' class='button'>Run Full Diagnostic</a></p>";
echo "<p><a href='controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6' class='button'>Direct API Test</a></p>";
echo "</div>";

echo "<script>
function copyToClipboard() {
    const text = `// Test if withdrawal manager is loaded
console.log('withdrawalManager:', window.withdrawalManager);

// Test if elements exist
console.log('withdrawalsGrid:', document.getElementById('withdrawalsGrid'));
console.log('loadingSpinner:', document.getElementById('loadingSpinner'));

// Force reload withdrawals
if (window.withdrawalManager) {
    window.withdrawalManager.loadWithdrawals();
} else {
    console.log('WithdrawalManager not found, trying to initialize...');
    window.withdrawalManager = new WithdrawalManager();
}

// Test API call directly
fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6')
    .then(response => response.json())
    .then(data => {
        console.log('API Response:', data);
        if (data.success) {
            console.log('Withdrawals found:', data.withdrawals.length);
            
            // Manually render withdrawals if manager exists
            if (window.withdrawalManager) {
                window.withdrawalManager.renderWithdrawals(data.withdrawals);
            }
        }
    })
    .catch(error => console.error('Error:', error));`;
    
    navigator.clipboard.writeText(text).then(function() {
        alert('Code copied to clipboard!');
    }, function(err) {
        alert('Failed to copy code to clipboard');
    });
}
</script>";

echo "<div style='margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; background: #f0f8ff;'>";
echo "<h4>💡 Common Issues and Solutions:</h4>";
echo "<ul>";
echo "<li><strong>JavaScript not loading:</strong> Check if the file exists and clear browser cache</li>";
echo "<li><strong>API returning data but not displaying:</strong> Check browser console for JavaScript errors</li>";
echo "<li><strong>Empty grid:</strong> The initialization might be failing due to missing DOM elements</li>";
echo "<li><strong>Timing issues:</strong> The JavaScript might be loading before the DOM is ready</li>";
echo "</ul>";
echo "</div>";
?> 