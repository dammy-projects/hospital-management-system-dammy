<?php
// Test script to diagnose controller API issues
echo "<h2>Controller API Diagnostic Test</h2>";

// Test 1: Direct controller access
echo "<h3>1. Testing Direct Controller Access</h3>";
echo "<div id='test1'>";
echo "<button onclick='testDirectAccess()'>Test Direct Access</button>";
echo "<div id='result1'></div>";
echo "</div>";

// Test 2: Test inventory-items action
echo "<h3>2. Testing Inventory Items API</h3>";
echo "<div id='test2'>";
echo "<button onclick='testInventoryItems()'>Test Inventory Items</button>";
echo "<div id='result2'></div>";
echo "</div>";

// Test 3: Test with different actions
echo "<h3>3. Testing All Available Actions</h3>";
echo "<div id='test3'>";
echo "<button onclick='testAllActions()'>Test All Actions</button>";
echo "<div id='result3'></div>";
echo "</div>";

// Test 4: Check if file exists
echo "<h3>4. File Existence Check</h3>";
$controllerPath = 'controllers/InventoryWithdrawalController.php';
if (file_exists($controllerPath)) {
    echo "<p style='color: green;'>✅ Controller file exists: $controllerPath</p>";
    echo "<p>File size: " . filesize($controllerPath) . " bytes</p>";
    echo "<p>Last modified: " . date('Y-m-d H:i:s', filemtime($controllerPath)) . "</p>";
} else {
    echo "<p style='color: red;'>❌ Controller file NOT found: $controllerPath</p>";
}

// Test 5: Check for PHP syntax errors
echo "<h3>5. PHP Syntax Check</h3>";
if (file_exists($controllerPath)) {
    $output = [];
    $return_var = 0;
    exec("php -l $controllerPath 2>&1", $output, $return_var);
    
    if ($return_var === 0) {
        echo "<p style='color: green;'>✅ No syntax errors found</p>";
    } else {
        echo "<p style='color: red;'>❌ Syntax errors found:</p>";
        echo "<pre>" . implode("\n", $output) . "</pre>";
    }
}

// Test 6: Manual API test
echo "<h3>6. Manual API Test Form</h3>";
echo "<form id='manualTest' onsubmit='return testManualAPI(event)'>";
echo "<label>Action: <input type='text' name='action' value='inventory-items' /></label><br><br>";
echo "<button type='submit'>Test API Call</button>";
echo "</form>";
echo "<div id='manualResult'></div>";

?>

<script>
function testDirectAccess() {
    const resultDiv = document.getElementById('result1');
    resultDiv.innerHTML = '<p>Testing...</p>';
    
    fetch('controllers/InventoryWithdrawalController.php')
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML = `<p style='color: green;'>✅ Controller accessible</p><pre>${data.substring(0, 200)}...</pre>`;
        })
        .catch(error => {
            resultDiv.innerHTML = `<p style='color: red;'>❌ Error: ${error.message}</p>`;
        });
}

function testInventoryItems() {
    const resultDiv = document.getElementById('result2');
    resultDiv.innerHTML = '<p>Testing...</p>';
    
    fetch('controllers/InventoryWithdrawalController.php?action=inventory-items')
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML = `<p style='color: green;'>✅ Response received</p><pre>${data}</pre>`;
        })
        .catch(error => {
            resultDiv.innerHTML = `<p style='color: red;'>❌ Error: ${error.message}</p>`;
        });
}

function testAllActions() {
    const resultDiv = document.getElementById('result3');
    resultDiv.innerHTML = '<p>Testing...</p>';
    
    const actions = ['list', 'inventory-items', 'get', 'invalid-action'];
    let results = [];
    
    Promise.all(actions.map(action => 
        fetch(`controllers/InventoryWithdrawalController.php?action=${action}`)
            .then(response => response.text())
            .then(data => ({action, success: true, data}))
            .catch(error => ({action, success: false, error: error.message}))
    )).then(responses => {
        let html = '<table border="1" style="border-collapse: collapse; width: 100%;">';
        html += '<tr><th>Action</th><th>Status</th><th>Response</th></tr>';
        
        responses.forEach(resp => {
            const status = resp.success ? '✅ Success' : '❌ Error';
            const response = resp.success ? resp.data.substring(0, 100) + '...' : resp.error;
            html += `<tr><td>${resp.action}</td><td>${status}</td><td><pre>${response}</pre></td></tr>`;
        });
        
        html += '</table>';
        resultDiv.innerHTML = html;
    });
}

function testManualAPI(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const action = formData.get('action');
    const resultDiv = document.getElementById('manualResult');
    
    resultDiv.innerHTML = '<p>Testing...</p>';
    
    fetch(`controllers/InventoryWithdrawalController.php?action=${action}`)
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML = `<p style='color: green;'>✅ Response for action "${action}":</p><pre>${data}</pre>`;
        })
        .catch(error => {
            resultDiv.innerHTML = `<p style='color: red;'>❌ Error: ${error.message}</p>`;
        });
    
    return false;
}
</script>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2, h3 { color: #333; }
button { background: #007cba; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
button:hover { background: #005a87; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; max-height: 200px; overflow-y: auto; }
table { margin: 10px 0; }
th, td { padding: 8px; border: 1px solid #ccc; }
th { background-color: #f0f0f0; }
input { padding: 5px; margin: 5px; }
label { display: inline-block; margin: 5px 0; }
</style> 