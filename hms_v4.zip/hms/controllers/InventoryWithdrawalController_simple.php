<?php
// Simplified controller to fix "Invalid action specified" error
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/config.php';
ob_start();

class InventoryWithdrawalController {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function handleRequest() {
        $action = $_GET['action'] ?? $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'inventory-items':
                    $this->getInventoryItems();
                    break;
                case 'list':
                    $this->listWithdrawals();
                    break;
                case 'get':
                    $this->getWithdrawal();
                    break;
                case 'create':
                    $this->createWithdrawal();
                    break;
                default:
                    $this->sendResponse(false, 'Invalid action specified: ' . $action);
            }
        } catch (Exception $e) {
            $this->sendResponse(false, 'Server error: ' . $e->getMessage());
        }
    }
    
    private function getInventoryItems() {
        try {
            $sql = "SELECT item_id, item_name, quantity_in_stock, unit, price, reorder_level 
                    FROM inventory_items 
                    WHERE status = 'active' 
                    ORDER BY item_name";
            
            $result = $this->conn->query($sql);
            $items = [];
            
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $items[] = $row;
                }
            }
            
            $this->sendResponse(true, 'Inventory items retrieved successfully', ['items' => $items]);
        } catch (Exception $e) {
            $this->sendResponse(false, 'Failed to load inventory items: ' . $e->getMessage());
        }
    }
    
    private function listWithdrawals() {
        try {
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = max(1, min(50, intval($_GET['limit'] ?? 6)));
            $offset = ($page - 1) * $limit;
            
            // Get total count
            $countSql = "SELECT COUNT(*) as total FROM inventory_withdrawals";
            $countResult = $this->conn->query($countSql);
            $totalRecords = $countResult->fetch_assoc()['total'];
            $totalPages = ceil($totalRecords / $limit);
            
            // Get withdrawals (basic fields only)
            $sql = "SELECT withdrawal_id, withdrawal_date, customer_name, sale_type, 
                           payment_status, amount_due, amount_paid, status 
                    FROM inventory_withdrawals 
                    ORDER BY withdrawal_date DESC 
                    LIMIT ? OFFSET ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('ii', $limit, $offset);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $withdrawals = [];
            while ($row = $result->fetch_assoc()) {
                // Get withdrawal items
                $itemsSql = "SELECT iwi.quantity, ii.item_name, ii.price 
                            FROM inventory_withdrawal_items iwi 
                            JOIN inventory_items ii ON iwi.item_id = ii.item_id 
                            WHERE iwi.withdrawal_id = ?";
                $itemsStmt = $this->conn->prepare($itemsSql);
                $itemsStmt->bind_param('i', $row['withdrawal_id']);
                $itemsStmt->execute();
                $itemsResult = $itemsStmt->get_result();
                
                $items = [];
                while ($item = $itemsResult->fetch_assoc()) {
                    $items[] = $item;
                }
                
                $row['items'] = $items;
                $withdrawals[] = $row;
            }
            
            $pagination = [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_records' => $totalRecords,
                'records_per_page' => $limit
            ];
            
            $this->sendResponse(true, 'Withdrawals retrieved successfully', [
                'withdrawals' => $withdrawals,
                'pagination' => $pagination
            ]);
            
        } catch (Exception $e) {
            $this->sendResponse(false, 'Failed to load withdrawals: ' . $e->getMessage());
        }
    }
    
    private function getWithdrawal() {
        try {
            $withdrawalId = intval($_GET['id'] ?? 0);
            
            if ($withdrawalId <= 0) {
                $this->sendResponse(false, 'Valid withdrawal ID is required');
                return;
            }
            
            $sql = "SELECT withdrawal_id, withdrawal_date, customer_name, sale_type, 
                           payment_status, amount_due, amount_paid, status 
                    FROM inventory_withdrawals 
                    WHERE withdrawal_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('i', $withdrawalId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $this->sendResponse(false, 'Withdrawal not found');
                return;
            }
            
            $withdrawal = $result->fetch_assoc();
            
            // Get withdrawal items
            $itemsSql = "SELECT iwi.quantity, iwi.item_id, ii.item_name, ii.price 
                        FROM inventory_withdrawal_items iwi 
                        JOIN inventory_items ii ON iwi.item_id = ii.item_id 
                        WHERE iwi.withdrawal_id = ?";
            $itemsStmt = $this->conn->prepare($itemsSql);
            $itemsStmt->bind_param('i', $withdrawalId);
            $itemsStmt->execute();
            $itemsResult = $itemsStmt->get_result();
            
            $items = [];
            while ($item = $itemsResult->fetch_assoc()) {
                $items[] = $item;
            }
            
            $withdrawal['items'] = $items;
            
            $this->sendResponse(true, 'Withdrawal retrieved successfully', ['withdrawal' => $withdrawal]);
            
        } catch (Exception $e) {
            $this->sendResponse(false, 'Failed to load withdrawal: ' . $e->getMessage());
        }
    }
    
    private function createWithdrawal() {
        try {
            $customerName = trim($_POST['customer_name'] ?? '');
            $saleType = trim($_POST['sale_type'] ?? 'retail');
            $paymentStatus = trim($_POST['payment_status'] ?? 'unpaid');
            $amountDue = floatval($_POST['amount_due'] ?? 0);
            $amountPaid = floatval($_POST['amount_paid'] ?? 0);
            $status = trim($_POST['status'] ?? 'pending');
            $withdrawalDate = trim($_POST['withdrawal_date'] ?? '');
            $items = json_decode($_POST['items'] ?? '[]', true);
            
            // Basic validation
            if (empty($customerName) || empty($withdrawalDate) || empty($items)) {
                $this->sendResponse(false, 'Missing required fields');
                return;
            }
            
            $this->conn->begin_transaction();
            
            // Insert withdrawal (basic fields only)
            $sql = "INSERT INTO inventory_withdrawals (withdrawal_date, customer_name, sale_type, 
                                                      payment_status, amount_due, amount_paid, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('ssssdds', $withdrawalDate, $customerName, $saleType, 
                              $paymentStatus, $amountDue, $amountPaid, $status);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to create withdrawal');
            }
            
            $withdrawalId = $this->conn->insert_id;
            
            // Insert withdrawal items
            foreach ($items as $item) {
                $itemId = intval($item['item_id'] ?? 0);
                $quantity = intval($item['quantity'] ?? 0);
                
                if ($itemId > 0 && $quantity > 0) {
                    $itemSql = "INSERT INTO inventory_withdrawal_items (withdrawal_id, item_id, quantity) VALUES (?, ?, ?)";
                    $itemStmt = $this->conn->prepare($itemSql);
                    $itemStmt->bind_param('iii', $withdrawalId, $itemId, $quantity);
                    $itemStmt->execute();
                }
            }
            
            $this->conn->commit();
            $this->sendResponse(true, 'Withdrawal created successfully', ['withdrawal_id' => $withdrawalId]);
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->sendResponse(false, 'Failed to create withdrawal: ' . $e->getMessage());
        }
    }
    
    private function sendResponse($success, $message, $data = null) {
        ob_clean();
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if ($data !== null) {
            $response = array_merge($response, $data);
        }
        
        echo json_encode($response);
        exit;
    }
}

// Initialize and handle request
try {
    $controller = new InventoryWithdrawalController($conn);
    $controller->handleRequest();
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Controller error: ' . $e->getMessage()]);
}
?> 