<?php
// Temporary backup controller that works without discount fields
// Use this if database update fails

error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/config.php';

ob_start();

class InventoryWithdrawalController {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'list':
                    $this->listWithdrawals();
                    break;
                case 'get':
                    $this->getWithdrawal();
                    break;
                case 'create':
                    $this->createWithdrawal();
                    break;
                case 'update':
                    $this->updateWithdrawal();
                    break;
                case 'delete':
                    $this->deleteWithdrawal();
                    break;
                case 'inventory-items':
                    $this->getInventoryItems();
                    break;
                default:
                    $this->sendResponse(false, 'Invalid action specified');
            }
        } catch (Exception $e) {
            error_log("Inventory Withdrawal Controller Error: " . $e->getMessage());
            $this->sendResponse(false, 'An error occurred: ' . $e->getMessage());
        }
    }
    
    private function createWithdrawal() {
        $customerName = trim($_POST['customer_name'] ?? '');
        $saleType = trim($_POST['sale_type'] ?? 'retail');
        $paymentStatus = trim($_POST['payment_status'] ?? 'unpaid');
        $amountDue = floatval($_POST['amount_due'] ?? 0);
        $amountPaid = floatval($_POST['amount_paid'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');
        $status = trim($_POST['status'] ?? 'pending');
        $withdrawalDate = trim($_POST['withdrawal_date'] ?? '');
        $items = json_decode($_POST['items'] ?? '[]', true);
        
        // Validation
        if (empty($customerName)) {
            $this->sendResponse(false, 'Customer name is required');
            return;
        }
        
        if (empty($withdrawalDate)) {
            $this->sendResponse(false, 'Withdrawal date is required');
            return;
        }
        
        if (empty($items) || !is_array($items)) {
            $this->sendResponse(false, 'At least one item is required');
            return;
        }
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Insert withdrawal WITHOUT discount fields
            $sql = "INSERT INTO inventory_withdrawals (withdrawal_date, notes, customer_name, sale_type, 
                                                      payment_status, amount_due, amount_paid, performed_by, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($sql);
            $performedBy = $_SESSION['user_id'] ?? null;
            $stmt->bind_param('sssssdids', $withdrawalDate, $notes, $customerName, $saleType, 
                              $paymentStatus, $amountDue, $amountPaid, $performedBy, $status);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to create withdrawal');
            }
            
            $withdrawalId = $this->conn->insert_id;
            
            // Insert withdrawal items
            foreach ($items as $item) {
                $itemId = intval($item['item_id'] ?? 0);
                $quantity = intval($item['quantity'] ?? 0);
                
                if ($itemId <= 0 || $quantity <= 0) {
                    throw new Exception('Invalid item or quantity');
                }
                
                $itemSql = "INSERT INTO inventory_withdrawal_items (withdrawal_id, item_id, quantity) VALUES (?, ?, ?)";
                $itemStmt = $this->conn->prepare($itemSql);
                $itemStmt->bind_param('iii', $withdrawalId, $itemId, $quantity);
                
                if (!$itemStmt->execute()) {
                    throw new Exception('Failed to add withdrawal item');
                }
            }
            
            $this->conn->commit();
            $this->sendResponse(true, 'Withdrawal created successfully', ['withdrawal_id' => $withdrawalId]);
            
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    private function getInventoryItems() {
        $sql = "SELECT item_id, item_name, quantity_in_stock, unit, price, reorder_level 
                FROM inventory_items 
                WHERE status = 'active' 
                ORDER BY item_name";
        
        $result = $this->conn->query($sql);
        $items = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $row;
            }
        }
        
        $this->sendResponse(true, 'Inventory items retrieved successfully', ['items' => $items]);
    }
    
    private function sendResponse($success, $message, $data = null) {
        ob_clean();
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if ($data !== null) {
            $response = array_merge($response, $data);
        }
        
        echo json_encode($response);
        exit;
    }
}

// Initialize and handle request
try {
    $controller = new InventoryWithdrawalController($conn);
    $controller->handleRequest();
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?> 