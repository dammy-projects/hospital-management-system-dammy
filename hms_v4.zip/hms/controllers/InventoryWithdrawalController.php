<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once __DIR__ . '/../config/config.php';

// Start output buffering to catch any unwanted output
ob_start();

class InventoryWithdrawalController {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'list':
                    $this->listWithdrawals();
                    break;
                case 'get':
                    $this->getWithdrawal();
                    break;
                case 'create':
                    $this->createWithdrawal();
                    break;
                case 'update':
                    $this->updateWithdrawal();
                    break;
                case 'delete':
                    $this->deleteWithdrawal();
                    break;
                case 'inventory-items':
                    $this->getInventoryItems();
                    break;
                default:
                    $this->sendResponse(false, 'Invalid action specified');
            }
        } catch (Exception $e) {
            error_log("Inventory Withdrawal Controller Error: " . $e->getMessage());
            $this->sendResponse(false, 'An error occurred: ' . $e->getMessage());
        }
    }
    
    private function listWithdrawals() {
        $page = max(1, intval($_GET['page'] ?? 1));
        $limit = max(1, min(50, intval($_GET['limit'] ?? 6)));
        $offset = ($page - 1) * $limit;
        
        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $saleType = trim($_GET['sale_type'] ?? '');
        $sort = trim($_GET['sort'] ?? 'withdrawal_date');
        $startDate = trim($_GET['start_date'] ?? '');
        $endDate = trim($_GET['end_date'] ?? '');
        
        // Validate sort field
        $allowedSorts = ['withdrawal_date', 'customer_name', 'amount_due', 'status'];
        if (!in_array($sort, $allowedSorts)) {
            $sort = 'withdrawal_date';
        }
        
        // Build WHERE clause
        $whereConditions = [];
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $whereConditions[] = "customer_name LIKE ?";
            $searchParam = "%{$search}%";
            $params[] = $searchParam;
            $types .= 's';
        }
        
        if (!empty($status)) {
            $whereConditions[] = "status = ?";
            $params[] = $status;
            $types .= 's';
        }
        
        if (!empty($saleType)) {
            $whereConditions[] = "sale_type = ?";
            $params[] = $saleType;
            $types .= 's';
        }
        
        // Date range filtering
        if (!empty($startDate)) {
            $whereConditions[] = "DATE(withdrawal_date) >= ?";
            $params[] = $startDate;
            $types .= 's';
        }
        
        if (!empty($endDate)) {
            $whereConditions[] = "DATE(withdrawal_date) <= ?";
            $params[] = $endDate;
            $types .= 's';
        }
        
        $whereClause = '';
        if (!empty($whereConditions)) {
            $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM inventory_withdrawals {$whereClause}";
        $countStmt = $this->conn->prepare($countSql);
        
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        
        $countStmt->execute();
        $countResult = $countStmt->get_result();
        $totalRecords = $countResult->fetch_assoc()['total'];
        $totalPages = ceil($totalRecords / $limit);
        
        // Get withdrawals
        $sql = "SELECT withdrawal_id, withdrawal_date, customer_name, sale_type, 
                       payment_status, amount_due, amount_paid, discount_value, discount_type, performed_by, status 
                FROM inventory_withdrawals 
                {$whereClause} 
                ORDER BY {$sort} DESC 
                LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($sql);
        
        $allParams = $params;
        $allTypes = $types;
        $allParams[] = $limit;
        $allParams[] = $offset;
        $allTypes .= 'ii';
        
        if (!empty($allParams)) {
            $stmt->bind_param($allTypes, ...$allParams);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $withdrawals = [];
        while ($row = $result->fetch_assoc()) {
            // Get withdrawal items
            $itemsSql = "SELECT iwi.quantity, ii.item_name, ii.price 
                        FROM inventory_withdrawal_items iwi 
                        JOIN inventory_items ii ON iwi.item_id = ii.item_id 
                        WHERE iwi.withdrawal_id = ?";
            $itemsStmt = $this->conn->prepare($itemsSql);
            $itemsStmt->bind_param('i', $row['withdrawal_id']);
            $itemsStmt->execute();
            $itemsResult = $itemsStmt->get_result();
            
            $items = [];
            while ($item = $itemsResult->fetch_assoc()) {
                $items[] = $item;
            }
            
            $row['items'] = $items;
            $withdrawals[] = $row;
        }
        
        $this->sendResponse(true, 'Withdrawals retrieved successfully', [
            'withdrawals' => $withdrawals,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_records' => $totalRecords,
                'records_per_page' => $limit
            ]
        ]);
    }
    
    private function getWithdrawal() {
        $withdrawalId = intval($_GET['id'] ?? 0);
        
        if ($withdrawalId <= 0) {
            $this->sendResponse(false, 'Valid withdrawal ID is required');
            return;
        }
        
        $sql = "SELECT withdrawal_id, withdrawal_date, customer_name, sale_type, 
                       payment_status, amount_due, amount_paid, discount_value, discount_type, performed_by, status 
                FROM inventory_withdrawals 
                WHERE withdrawal_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $withdrawalId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $this->sendResponse(false, 'Withdrawal not found');
            return;
        }
        
        $withdrawal = $result->fetch_assoc();
        
        // Get withdrawal items
        $itemsSql = "SELECT iwi.quantity, iwi.item_id, ii.item_name, ii.price 
                    FROM inventory_withdrawal_items iwi 
                    JOIN inventory_items ii ON iwi.item_id = ii.item_id 
                    WHERE iwi.withdrawal_id = ?";
        $itemsStmt = $this->conn->prepare($itemsSql);
        $itemsStmt->bind_param('i', $withdrawalId);
        $itemsStmt->execute();
        $itemsResult = $itemsStmt->get_result();
        
        $items = [];
        while ($item = $itemsResult->fetch_assoc()) {
            $items[] = $item;
        }
        
        $withdrawal['items'] = $items;
        
        $this->sendResponse(true, 'Withdrawal retrieved successfully', [
            'withdrawal' => $withdrawal
        ]);
    }
    
    private function createWithdrawal() {
        $customerName = trim($_POST['customer_name'] ?? '');
        $saleType = trim($_POST['sale_type'] ?? 'retail');
        $paymentStatus = trim($_POST['payment_status'] ?? 'unpaid');
        $amountDue = floatval($_POST['amount_due'] ?? 0);
        $amountPaid = floatval($_POST['amount_paid'] ?? 0);
        $discountValue = floatval($_POST['discount_value'] ?? 0);
        $discountType = trim($_POST['discount_type'] ?? 'percentage');
        $status = trim($_POST['status'] ?? 'pending');
        $withdrawalDate = trim($_POST['withdrawal_date'] ?? '');
        $items = json_decode($_POST['items'] ?? '[]', true);
        
        // Validation
        if (empty($customerName)) {
            $this->sendResponse(false, 'Customer name is required');
            return;
        }
        
        if (empty($withdrawalDate)) {
            $this->sendResponse(false, 'Withdrawal date is required');
            return;
        }
        
        if (empty($items) || !is_array($items)) {
            $this->sendResponse(false, 'At least one item is required');
            return;
        }
        
        // Validate enum values
        $allowedSaleTypes = ['retail', 'wholesale'];
        if (!in_array($saleType, $allowedSaleTypes)) {
            $this->sendResponse(false, 'Invalid sale type');
            return;
        }
        
        $allowedPaymentStatuses = ['unpaid', 'partial', 'paid'];
        if (!in_array($paymentStatus, $allowedPaymentStatuses)) {
            $this->sendResponse(false, 'Invalid payment status');
            return;
        }
        
        $allowedStatuses = ['pending', 'approved', 'completed', 'cancelled'];
        if (!in_array($status, $allowedStatuses)) {
            $this->sendResponse(false, 'Invalid status');
            return;
        }
        
        $allowedDiscountTypes = ['percentage', 'fixed'];
        if (!in_array($discountType, $allowedDiscountTypes)) {
            $this->sendResponse(false, 'Invalid discount type');
            return;
        }
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Insert withdrawal
            $sql = "INSERT INTO inventory_withdrawals (withdrawal_date, customer_name, sale_type, 
                                                      payment_status, amount_due, amount_paid, discount_value, discount_type, performed_by, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($sql);
            $performedBy = $_SESSION['user_id'] ?? null;
            $stmt->bind_param('ssssdddssi', $withdrawalDate, $customerName, $saleType, 
                              $paymentStatus, $amountDue, $amountPaid, $discountValue, $discountType, $performedBy, $status);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to create withdrawal');
            }
            
            $withdrawalId = $this->conn->insert_id;
            
            // Insert withdrawal items
            foreach ($items as $item) {
                $itemId = intval($item['item_id'] ?? 0);
                $quantity = intval($item['quantity'] ?? 0);
                
                if ($itemId <= 0 || $quantity <= 0) {
                    throw new Exception('Invalid item or quantity');
                }
                
                // Check stock availability
                $stockSql = "SELECT quantity_in_stock FROM inventory_items WHERE item_id = ?";
                $stockStmt = $this->conn->prepare($stockSql);
                $stockStmt->bind_param('i', $itemId);
                $stockStmt->execute();
                $stockResult = $stockStmt->get_result();
                
                if ($stockResult->num_rows === 0) {
                    throw new Exception('Item not found');
                }
                
                $stockRow = $stockResult->fetch_assoc();
                if ($stockRow['quantity_in_stock'] < $quantity) {
                    throw new Exception('Insufficient stock for item ID: ' . $itemId);
                }
                
                // Insert withdrawal item
                $itemSql = "INSERT INTO inventory_withdrawal_items (withdrawal_id, item_id, quantity) 
                           VALUES (?, ?, ?)";
                $itemStmt = $this->conn->prepare($itemSql);
                $itemStmt->bind_param('iii', $withdrawalId, $itemId, $quantity);
                
                if (!$itemStmt->execute()) {
                    throw new Exception('Failed to add withdrawal item');
                }
                
                // Update inventory if withdrawal is completed
                if ($status === 'completed') {
                    $updateSql = "UPDATE inventory_items SET quantity_in_stock = quantity_in_stock - ? WHERE item_id = ?";
                    $updateStmt = $this->conn->prepare($updateSql);
                    $updateStmt->bind_param('ii', $quantity, $itemId);
                    
                    if (!$updateStmt->execute()) {
                        throw new Exception('Failed to update inventory');
                    }
                    
                    // Record inventory movement
                    $movementSql = "INSERT INTO inventory_movements (item_id, movement_type, quantity, movement_date, notes, performed_by) 
                                   VALUES (?, 'out', ?, NOW(), ?, ?)";
                    $movementStmt = $this->conn->prepare($movementSql);
                    $movementNotes = "Withdrawal #{$withdrawalId} for {$customerName}";
                    $movementStmt->bind_param('iisi', $itemId, $quantity, $movementNotes, $performedBy);
                    $movementStmt->execute();
                }
            }
            
            $this->conn->commit();
            
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Created withdrawal ID: {$withdrawalId} for {$customerName}");
            
            $this->sendResponse(true, 'Withdrawal created successfully', [
                'withdrawal_id' => $withdrawalId
            ]);
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->sendResponse(false, $e->getMessage());
        }
    }
    
    private function updateWithdrawal() {
        $withdrawalId = intval($_POST['withdrawal_id'] ?? 0);
        $customerName = trim($_POST['customer_name'] ?? '');
        $saleType = trim($_POST['sale_type'] ?? 'retail');
        $paymentStatus = trim($_POST['payment_status'] ?? 'unpaid');
        $amountDue = floatval($_POST['amount_due'] ?? 0);
        $amountPaid = floatval($_POST['amount_paid'] ?? 0);
        $discountValue = floatval($_POST['discount_value'] ?? 0);
        $discountType = trim($_POST['discount_type'] ?? 'percentage');
        $status = trim($_POST['status'] ?? 'pending');
        $withdrawalDate = trim($_POST['withdrawal_date'] ?? '');
        $items = json_decode($_POST['items'] ?? '[]', true);
        
        if ($withdrawalId <= 0) {
            $this->sendResponse(false, 'Valid withdrawal ID is required');
            return;
        }
        
        // Validation
        if (empty($customerName)) {
            $this->sendResponse(false, 'Customer name is required');
            return;
        }
        
        if (empty($withdrawalDate)) {
            $this->sendResponse(false, 'Withdrawal date is required');
            return;
        }
        
        if (empty($items) || !is_array($items)) {
            $this->sendResponse(false, 'At least one item is required');
            return;
        }
        
        // Validate enum values
        $allowedSaleTypes = ['retail', 'wholesale'];
        if (!in_array($saleType, $allowedSaleTypes)) {
            $this->sendResponse(false, 'Invalid sale type');
            return;
        }
        
        $allowedPaymentStatuses = ['unpaid', 'partial', 'paid'];
        if (!in_array($paymentStatus, $allowedPaymentStatuses)) {
            $this->sendResponse(false, 'Invalid payment status');
            return;
        }
        
        $allowedStatuses = ['pending', 'approved', 'completed', 'cancelled'];
        if (!in_array($status, $allowedStatuses)) {
            $this->sendResponse(false, 'Invalid status');
            return;
        }
        
        $allowedDiscountTypes = ['percentage', 'fixed'];
        if (!in_array($discountType, $allowedDiscountTypes)) {
            $this->sendResponse(false, 'Invalid discount type');
            return;
        }
        
        // Check if withdrawal exists
        $checkSql = "SELECT status FROM inventory_withdrawals WHERE withdrawal_id = ?";
        $checkStmt = $this->conn->prepare($checkSql);
        $checkStmt->bind_param('i', $withdrawalId);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows === 0) {
            $this->sendResponse(false, 'Withdrawal not found');
            return;
        }
        
        $currentStatus = $checkResult->fetch_assoc()['status'];
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Update withdrawal
            $sql = "UPDATE inventory_withdrawals SET 
                    withdrawal_date = ?, customer_name = ?, sale_type = ?, 
                    payment_status = ?, amount_due = ?, amount_paid = ?, discount_value = ?, discount_type = ?, status = ? 
                    WHERE withdrawal_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('ssssddsssi', $withdrawalDate, $customerName, $saleType, 
                              $paymentStatus, $amountDue, $amountPaid, $discountValue, $discountType, $status, $withdrawalId);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update withdrawal');
            }
            
            // If status changed from completed to something else, restore inventory
            if ($currentStatus === 'completed' && $status !== 'completed') {
                $restoreSql = "SELECT iwi.item_id, iwi.quantity 
                              FROM inventory_withdrawal_items iwi 
                              WHERE iwi.withdrawal_id = ?";
                $restoreStmt = $this->conn->prepare($restoreSql);
                $restoreStmt->bind_param('i', $withdrawalId);
                $restoreStmt->execute();
                $restoreResult = $restoreStmt->get_result();
                
                while ($restoreRow = $restoreResult->fetch_assoc()) {
                    $updateSql = "UPDATE inventory_items SET quantity_in_stock = quantity_in_stock + ? WHERE item_id = ?";
                    $updateStmt = $this->conn->prepare($updateSql);
                    $updateStmt->bind_param('ii', $restoreRow['quantity'], $restoreRow['item_id']);
                    $updateStmt->execute();
                }
            }
            
            // Delete existing withdrawal items
            $deleteSql = "DELETE FROM inventory_withdrawal_items WHERE withdrawal_id = ?";
            $deleteStmt = $this->conn->prepare($deleteSql);
            $deleteStmt->bind_param('i', $withdrawalId);
            $deleteStmt->execute();
            
            // Insert new withdrawal items
            foreach ($items as $item) {
                $itemId = intval($item['item_id'] ?? 0);
                $quantity = intval($item['quantity'] ?? 0);
                
                if ($itemId <= 0 || $quantity <= 0) {
                    throw new Exception('Invalid item or quantity');
                }
                
                // Check stock availability if completing withdrawal
                if ($status === 'completed') {
                    $stockSql = "SELECT quantity_in_stock FROM inventory_items WHERE item_id = ?";
                    $stockStmt = $this->conn->prepare($stockSql);
                    $stockStmt->bind_param('i', $itemId);
                    $stockStmt->execute();
                    $stockResult = $stockStmt->get_result();
                    
                    if ($stockResult->num_rows === 0) {
                        throw new Exception('Item not found');
                    }
                    
                    $stockRow = $stockResult->fetch_assoc();
                    if ($stockRow['quantity_in_stock'] < $quantity) {
                        throw new Exception('Insufficient stock for item ID: ' . $itemId);
                    }
                }
                
                // Insert withdrawal item
                $itemSql = "INSERT INTO inventory_withdrawal_items (withdrawal_id, item_id, quantity) 
                           VALUES (?, ?, ?)";
                $itemStmt = $this->conn->prepare($itemSql);
                $itemStmt->bind_param('iii', $withdrawalId, $itemId, $quantity);
                
                if (!$itemStmt->execute()) {
                    throw new Exception('Failed to add withdrawal item');
                }
                
                // Update inventory if withdrawal is completed
                if ($status === 'completed') {
                    $updateSql = "UPDATE inventory_items SET quantity_in_stock = quantity_in_stock - ? WHERE item_id = ?";
                    $updateStmt = $this->conn->prepare($updateSql);
                    $updateStmt->bind_param('ii', $quantity, $itemId);
                    
                    if (!$updateStmt->execute()) {
                        throw new Exception('Failed to update inventory');
                    }
                    
                    // Record inventory movement
                    $movementSql = "INSERT INTO inventory_movements (item_id, movement_type, quantity, movement_date, notes, performed_by) 
                                   VALUES (?, 'out', ?, NOW(), ?, ?)";
                    $movementStmt = $this->conn->prepare($movementSql);
                    $movementNotes = "Updated withdrawal #{$withdrawalId} for {$customerName}";
                    $performedBy = $_SESSION['user_id'] ?? null;
                    $movementStmt->bind_param('iisi', $itemId, $quantity, $movementNotes, $performedBy);
                    $movementStmt->execute();
                }
            }
            
            $this->conn->commit();
            
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Updated withdrawal ID: {$withdrawalId} for {$customerName}");
            
            $this->sendResponse(true, 'Withdrawal updated successfully');
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->sendResponse(false, $e->getMessage());
        }
    }
    
    private function deleteWithdrawal() {
        $withdrawalId = intval($_POST['withdrawal_id'] ?? $_GET['id'] ?? 0);
        
        if ($withdrawalId <= 0) {
            $this->sendResponse(false, 'Valid withdrawal ID is required');
            return;
        }
        
        // Check if withdrawal exists
        $checkSql = "SELECT customer_name, status FROM inventory_withdrawals WHERE withdrawal_id = ?";
        $checkStmt = $this->conn->prepare($checkSql);
        $checkStmt->bind_param('i', $withdrawalId);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows === 0) {
            $this->sendResponse(false, 'Withdrawal not found');
            return;
        }
        
        $withdrawal = $checkResult->fetch_assoc();
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // If withdrawal was completed, restore inventory
            if ($withdrawal['status'] === 'completed') {
                $restoreSql = "SELECT iwi.item_id, iwi.quantity 
                              FROM inventory_withdrawal_items iwi 
                              WHERE iwi.withdrawal_id = ?";
                $restoreStmt = $this->conn->prepare($restoreSql);
                $restoreStmt->bind_param('i', $withdrawalId);
                $restoreStmt->execute();
                $restoreResult = $restoreStmt->get_result();
                
                while ($restoreRow = $restoreResult->fetch_assoc()) {
                    $updateSql = "UPDATE inventory_items SET quantity_in_stock = quantity_in_stock + ? WHERE item_id = ?";
                    $updateStmt = $this->conn->prepare($updateSql);
                    $updateStmt->bind_param('ii', $restoreRow['quantity'], $restoreRow['item_id']);
                    $updateStmt->execute();
                    
                    // Record inventory movement
                    $movementSql = "INSERT INTO inventory_movements (item_id, movement_type, quantity, movement_date, notes, performed_by) 
                                   VALUES (?, 'in', ?, NOW(), ?, ?)";
                    $movementStmt = $this->conn->prepare($movementSql);
                    $movementNotes = "Restored from deleted withdrawal #{$withdrawalId}";
                    $performedBy = $_SESSION['user_id'] ?? null;
                    $movementStmt->bind_param('iisi', $restoreRow['item_id'], $restoreRow['quantity'], $movementNotes, $performedBy);
                    $movementStmt->execute();
                }
            }
            
            // Delete withdrawal items first (due to foreign key constraint)
            $deleteItemsSql = "DELETE FROM inventory_withdrawal_items WHERE withdrawal_id = ?";
            $deleteItemsStmt = $this->conn->prepare($deleteItemsSql);
            $deleteItemsStmt->bind_param('i', $withdrawalId);
            $deleteItemsStmt->execute();
            
            // Delete withdrawal
            $deleteSql = "DELETE FROM inventory_withdrawals WHERE withdrawal_id = ?";
            $deleteStmt = $this->conn->prepare($deleteSql);
            $deleteStmt->bind_param('i', $withdrawalId);
            
            if (!$deleteStmt->execute()) {
                throw new Exception('Failed to delete withdrawal');
            }
            
            $this->conn->commit();
            
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Deleted withdrawal ID: {$withdrawalId} for {$withdrawal['customer_name']}");
            
            $this->sendResponse(true, 'Withdrawal deleted successfully');
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->sendResponse(false, $e->getMessage());
        }
    }
    
    private function getInventoryItems() {
        $sql = "SELECT item_id, item_name, quantity_in_stock, price, unit 
                FROM inventory_items 
                WHERE status = 'active' AND quantity_in_stock > 0 
                ORDER BY item_name";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->get_result();
        
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        
        $this->sendResponse(true, 'Inventory items retrieved successfully', [
            'items' => $items
        ]);
    }
    
    private function logAction($userId, $action) {
        $sql = "INSERT INTO system_logs (user_id, action, log_timestamp) VALUES (?, ?, NOW())";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('is', $userId, $action);
            $stmt->execute();
    }
    
    private function sendResponse($success, $message, $data = null) {
        // Clear any unwanted output
        ob_clean();
        
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if ($data !== null) {
            $response = array_merge($response, $data);
        }
        
        echo json_encode($response);
        exit;
    }
}

// Check authentication
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    ob_end_clean();
    header('Content-Type: application/json');
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Initialize controller
try {
    ob_end_clean();
    header('Content-Type: application/json');
    $controller = new InventoryWithdrawalController($conn);
    $controller->handleRequest();
} catch (Exception $e) {
    ob_end_clean();
    header('Content-Type: application/json');
    error_log("InventoryWithdrawal Controller Fatal Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'System error: ' . $e->getMessage()
    ]);
} 