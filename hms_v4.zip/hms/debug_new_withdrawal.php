<?php
// Debug script for new withdrawal functionality
require_once 'config/config.php';

echo "<h2>Debug Script - New Withdrawal Functionality</h2>";

echo "<h3>1. Database Connection Test</h3>";
if ($conn->connect_error) {
    echo "<p style='color: red;'>❌ Database connection failed: " . $conn->connect_error . "</p>";
} else {
    echo "<p style='color: green;'>✅ Database connection successful</p>";
}

echo "<h3>2. Check inventory_withdrawals Table Structure</h3>";
try {
    $result = $conn->query("DESCRIBE inventory_withdrawals");
    if ($result) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0; width: 100%;'>";
        echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        
        $hasDiscountValue = false;
        $hasDiscountType = false;
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($row['Field']) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($row['Type']) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($row['Null']) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($row['Key']) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($row['Default']) . "</td>";
            echo "</tr>";
            
            if ($row['Field'] === 'discount_value') $hasDiscountValue = true;
            if ($row['Field'] === 'discount_type') $hasDiscountType = true;
        }
        echo "</table>";
        
        if ($hasDiscountValue && $hasDiscountType) {
            echo "<p style='color: green;'>✅ Discount fields are present in the database</p>";
        } else {
            echo "<p style='color: red;'>❌ Discount fields are missing! You need to run the database update.</p>";
            echo "<p><strong>Solution:</strong> <a href='update_database.php' target='_blank'>Click here to run the database update script</a></p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error checking table structure: " . $e->getMessage() . "</p>";
}

echo "<h3>3. Check Inventory Items</h3>";
try {
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory_items WHERE status = 'active'");
    $row = $result->fetch_assoc();
    $itemCount = $row['count'];
    
    if ($itemCount > 0) {
        echo "<p style='color: green;'>✅ Found {$itemCount} active inventory items</p>";
        
        // Show first 5 items
        $items = $conn->query("SELECT item_id, item_name, quantity_in_stock, price FROM inventory_items WHERE status = 'active' LIMIT 5");
        echo "<h4>Sample inventory items:</h4>";
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr style='background-color: #f0f0f0;'><th>ID</th><th>Name</th><th>Stock</th><th>Price</th></tr>";
        while ($item = $items->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . $item['item_id'] . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($item['item_name']) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . $item['quantity_in_stock'] . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>₱" . number_format($item['price'], 2) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red;'>❌ No active inventory items found. You need to add some items first.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error checking inventory items: " . $e->getMessage() . "</p>";
}

echo "<h3>4. Test API Endpoint</h3>";
echo "<div id='apiTestResult'></div>";

echo "<h3>5. JavaScript Console Check</h3>";
echo "<p>Open your browser's Developer Tools (F12) and check the Console tab for any JavaScript errors.</p>";
echo "<p>Common issues to look for:</p>";
echo "<ul>";
echo "<li>Network errors when loading inventory items</li>";
echo "<li>'Element not found' warnings</li>";
echo "<li>API response errors</li>";
echo "</ul>";

echo "<h3>6. Quick Actions</h3>";
echo "<p><a href='inventory_withdrawals.php' target='_blank' style='background: #007cba; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Go to Inventory Withdrawals Page</a></p>";
echo "<p><a href='update_database.php' target='_blank' style='background: #46b450; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Run Database Update</a></p>";

$conn->close();
?>

<script>
// Test API endpoint
fetch('controllers/InventoryWithdrawalController.php?action=inventory-items')
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('apiTestResult');
        if (data.success) {
            resultDiv.innerHTML = `<p style='color: green;'>✅ API endpoint working! Found ${data.items.length} items</p>`;
        } else {
            resultDiv.innerHTML = `<p style='color: red;'>❌ API error: ${data.message}</p>`;
        }
    })
    .catch(error => {
        const resultDiv = document.getElementById('apiTestResult');
        resultDiv.innerHTML = `<p style='color: red;'>❌ API request failed: ${error.message}</p>`;
    });
</script>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2, h3, h4 { color: #333; }
table { width: 100%; max-width: 800px; }
th { background-color: #f0f0f0; padding: 8px; }
td { padding: 5px; border: 1px solid #ccc; }
ul { margin: 10px 0; }
li { margin: 5px 0; }
</style> 