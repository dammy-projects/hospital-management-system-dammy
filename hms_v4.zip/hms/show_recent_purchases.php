<?php
// Show recent purchases (inventory withdrawals)
require_once 'config/config.php';

echo "<h2>Recent Purchases (Inventory Withdrawals)</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    table { border-collapse: collapse; width: 100%; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
    .status-completed { color: green; font-weight: bold; }
    .status-pending { color: orange; font-weight: bold; }
    .status-cancelled { color: red; font-weight: bold; }
    .amount { text-align: right; }
    .summary { background-color: #f9f9f9; padding: 15px; margin: 10px 0; border-radius: 5px; }
</style>";

try {
    // Get recent withdrawals with customer and item details
    $sql = "SELECT 
                w.withdrawal_id,
                w.withdrawal_date,
                w.customer_name,
                w.sale_type,
                w.payment_status,
                w.amount_due,
                w.amount_paid,
                w.discount_value,
                w.discount_type,
                w.status,
                COUNT(wi.withdrawal_item_id) as total_items
            FROM inventory_withdrawals w
            LEFT JOIN inventory_withdrawal_items wi ON w.withdrawal_id = wi.withdrawal_id
            GROUP BY w.withdrawal_id
            ORDER BY w.withdrawal_date DESC
            LIMIT 20";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<div class='summary'>";
        echo "<h3>📊 Summary</h3>";
        echo "<p><strong>Total Recent Withdrawals:</strong> " . $result->num_rows . "</p>";
        echo "</div>";
        
        echo "<h3>💳 Recent Withdrawals/Purchases</h3>";
        echo "<table>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Date</th>";
        echo "<th>Customer</th>";
        echo "<th>Sale Type</th>";
        echo "<th>Items</th>";
        echo "<th>Amount Due</th>";
        echo "<th>Amount Paid</th>";
        echo "<th>Discount</th>";
        echo "<th>Payment Status</th>";
        echo "<th>Status</th>";
        echo "</tr>";
        
        // Reset result pointer
        $result->data_seek(0);
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>#{$row['withdrawal_id']}</td>";
            echo "<td>" . date('M d, Y H:i', strtotime($row['withdrawal_date'])) . "</td>";
            echo "<td>{$row['customer_name']}</td>";
            echo "<td>" . ucfirst($row['sale_type']) . "</td>";
            echo "<td>{$row['total_items']} items</td>";
            echo "<td class='amount'>₱" . number_format($row['amount_due'], 2) . "</td>";
            echo "<td class='amount'>₱" . number_format($row['amount_paid'], 2) . "</td>";
            
            // Display discount
            if ($row['discount_value'] > 0) {
                if ($row['discount_type'] == 'percentage') {
                    echo "<td class='amount'>{$row['discount_value']}%</td>";
                } else {
                    echo "<td class='amount'>₱" . number_format($row['discount_value'], 2) . "</td>";
                }
            } else {
                echo "<td class='amount'>-</td>";
            }
            
            echo "<td class='status-{$row['payment_status']}'>" . ucfirst($row['payment_status']) . "</td>";
            echo "<td class='status-{$row['status']}'>" . ucfirst($row['status']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show detailed items for recent withdrawals
        echo "<h3>📦 Detailed Items in Recent Withdrawals</h3>";
        
        $detailSql = "SELECT 
                        w.withdrawal_id,
                        w.withdrawal_date,
                        w.customer_name,
                        ii.item_name,
                        wi.quantity,
                        ii.price,
                        ii.unit,
                        (wi.quantity * ii.price) as total_item_cost
                    FROM inventory_withdrawals w
                    JOIN inventory_withdrawal_items wi ON w.withdrawal_id = wi.withdrawal_id
                    JOIN inventory_items ii ON wi.item_id = ii.item_id
                    ORDER BY w.withdrawal_date DESC, w.withdrawal_id DESC
                    LIMIT 50";
        
        $detailResult = $conn->query($detailSql);
        
        if ($detailResult->num_rows > 0) {
            echo "<table>";
            echo "<tr>";
            echo "<th>Withdrawal ID</th>";
            echo "<th>Date</th>";
            echo "<th>Customer</th>";
            echo "<th>Item</th>";
            echo "<th>Quantity</th>";
            echo "<th>Unit Price</th>";
            echo "<th>Total</th>";
            echo "</tr>";
            
            while ($detail = $detailResult->fetch_assoc()) {
                echo "<tr>";
                echo "<td>#{$detail['withdrawal_id']}</td>";
                echo "<td>" . date('M d, Y', strtotime($detail['withdrawal_date'])) . "</td>";
                echo "<td>{$detail['customer_name']}</td>";
                echo "<td>{$detail['item_name']}</td>";
                echo "<td>{$detail['quantity']} {$detail['unit']}</td>";
                echo "<td class='amount'>₱" . number_format($detail['price'], 2) . "</td>";
                echo "<td class='amount'>₱" . number_format($detail['total_item_cost'], 2) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // Show inventory movements
        echo "<h3>📈 Recent Inventory Movements</h3>";
        
        $movementSql = "SELECT 
                          im.movement_id,
                          im.movement_date,
                          im.movement_type,
                          im.quantity,
                          im.notes,
                          ii.item_name
                      FROM inventory_movements im
                      JOIN inventory_items ii ON im.item_id = ii.item_id
                      ORDER BY im.movement_date DESC
                      LIMIT 20";
        
        $movementResult = $conn->query($movementSql);
        
        if ($movementResult->num_rows > 0) {
            echo "<table>";
            echo "<tr>";
            echo "<th>Movement ID</th>";
            echo "<th>Date</th>";
            echo "<th>Type</th>";
            echo "<th>Item</th>";
            echo "<th>Quantity</th>";
            echo "<th>Notes</th>";
            echo "</tr>";
            
            while ($movement = $movementResult->fetch_assoc()) {
                $typeClass = $movement['movement_type'] == 'in' ? 'status-completed' : 'status-cancelled';
                $typeSymbol = $movement['movement_type'] == 'in' ? '↑' : '↓';
                
                echo "<tr>";
                echo "<td>#{$movement['movement_id']}</td>";
                echo "<td>" . date('M d, Y H:i', strtotime($movement['movement_date'])) . "</td>";
                echo "<td class='{$typeClass}'>{$typeSymbol} " . strtoupper($movement['movement_type']) . "</td>";
                echo "<td>{$movement['item_name']}</td>";
                echo "<td>{$movement['quantity']}</td>";
                echo "<td>{$movement['notes']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // Show current inventory levels
        echo "<h3>📊 Current Inventory Levels</h3>";
        
        $inventorySql = "SELECT 
                           ii.item_id,
                           ii.item_name,
                           ii.quantity_in_stock,
                           ii.reorder_level,
                           ii.unit,
                           ii.price,
                           ic.category_name,
                           CASE 
                               WHEN ii.quantity_in_stock <= ii.reorder_level THEN 'Low Stock'
                               WHEN ii.quantity_in_stock > ii.reorder_level * 2 THEN 'Good Stock'
                               ELSE 'Normal Stock'
                           END as stock_status
                       FROM inventory_items ii
                       JOIN inventory_categories ic ON ii.category_id = ic.category_id
                       WHERE ii.status = 'active'
                       ORDER BY ii.quantity_in_stock ASC, ii.item_name ASC";
        
        $inventoryResult = $conn->query($inventorySql);
        
        if ($inventoryResult->num_rows > 0) {
            echo "<table>";
            echo "<tr>";
            echo "<th>Item ID</th>";
            echo "<th>Item Name</th>";
            echo "<th>Category</th>";
            echo "<th>Current Stock</th>";
            echo "<th>Reorder Level</th>";
            echo "<th>Unit Price</th>";
            echo "<th>Stock Status</th>";
            echo "</tr>";
            
            while ($inventory = $inventoryResult->fetch_assoc()) {
                $statusClass = '';
                switch($inventory['stock_status']) {
                    case 'Low Stock':
                        $statusClass = 'status-cancelled';
                        break;
                    case 'Good Stock':
                        $statusClass = 'status-completed';
                        break;
                    default:
                        $statusClass = 'status-pending';
                }
                
                echo "<tr>";
                echo "<td>#{$inventory['item_id']}</td>";
                echo "<td>{$inventory['item_name']}</td>";
                echo "<td>{$inventory['category_name']}</td>";
                echo "<td>{$inventory['quantity_in_stock']} {$inventory['unit']}</td>";
                echo "<td>{$inventory['reorder_level']} {$inventory['unit']}</td>";
                echo "<td class='amount'>₱" . number_format($inventory['price'], 2) . "</td>";
                echo "<td class='{$statusClass}'>{$inventory['stock_status']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } else {
        echo "<p>No recent withdrawals found.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<p><a href='inventory_withdrawals.php'>← Back to Inventory Withdrawals</a></p>";
?> 