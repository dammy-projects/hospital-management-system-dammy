<?php
// Test script for date range filtering
require_once 'config/config.php';

echo "<h2>Date Range Filter Test</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    table { border-collapse: collapse; width: 100%; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .info { color: blue; }
    .button { background: #3273dc; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
</style>";

echo "<div class='test-section'>";
echo "<h3>📅 Date Range Filter Test</h3>";

// Test different date ranges
$testCases = [
    ['name' => 'All data', 'start_date' => '', 'end_date' => ''],
    ['name' => 'June 30, 2025', 'start_date' => '2025-06-30', 'end_date' => '2025-06-30'],
    ['name' => 'January 2024', 'start_date' => '2024-01-01', 'end_date' => '2024-01-31'],
    ['name' => 'From June 2025', 'start_date' => '2025-06-01', 'end_date' => ''],
    ['name' => 'Until January 2024', 'start_date' => '', 'end_date' => '2024-01-31'],
];

foreach ($testCases as $test) {
    echo "<h4>Testing: {$test['name']}</h4>";
    
    // Simulate the controller request
    $_GET['action'] = 'list';
    $_GET['page'] = 1;
    $_GET['limit'] = 10;
    $_GET['start_date'] = $test['start_date'];
    $_GET['end_date'] = $test['end_date'];
    
    try {
        ob_start();
        include 'controllers/InventoryWithdrawalController.php';
        $output = ob_get_clean();
        
        $data = json_decode($output, true);
        
        if ($data && $data['success']) {
            echo "<p class='success'>✅ Found {$data['pagination']['total_records']} withdrawals</p>";
            
            if (!empty($data['withdrawals'])) {
                echo "<table style='font-size: 12px;'>";
                echo "<tr><th>ID</th><th>Date</th><th>Customer</th><th>Status</th></tr>";
                
                foreach ($data['withdrawals'] as $withdrawal) {
                    echo "<tr>";
                    echo "<td>#{$withdrawal['withdrawal_id']}</td>";
                    echo "<td>{$withdrawal['withdrawal_date']}</td>";
                    echo "<td>{$withdrawal['customer_name']}</td>";
                    echo "<td>{$withdrawal['status']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        } else {
            echo "<p class='error'>❌ API Error: " . ($data['message'] ?? 'Unknown error') . "</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Exception: " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
}

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>🧪 Interactive Date Range Test</h3>";
echo "<form method='GET' action='test_date_range_filter.php'>";
echo "<p>";
echo "<label>Start Date: <input type='date' name='test_start_date' value='" . ($_GET['test_start_date'] ?? '') . "'></label>";
echo "&nbsp;&nbsp;";
echo "<label>End Date: <input type='date' name='test_end_date' value='" . ($_GET['test_end_date'] ?? '') . "'></label>";
echo "&nbsp;&nbsp;";
echo "<button type='submit' class='button'>Test Filter</button>";
echo "</p>";
echo "</form>";

if (isset($_GET['test_start_date']) || isset($_GET['test_end_date'])) {
    echo "<h4>Custom Test Results:</h4>";
    
    $_GET['action'] = 'list';
    $_GET['page'] = 1;
    $_GET['limit'] = 20;
    $_GET['start_date'] = $_GET['test_start_date'] ?? '';
    $_GET['end_date'] = $_GET['test_end_date'] ?? '';
    
    try {
        ob_start();
        include 'controllers/InventoryWithdrawalController.php';
        $output = ob_get_clean();
        
        $data = json_decode($output, true);
        
        if ($data && $data['success']) {
            echo "<p class='success'>✅ Found {$data['pagination']['total_records']} withdrawals</p>";
            
            if (!empty($data['withdrawals'])) {
                echo "<table>";
                echo "<tr><th>ID</th><th>Date</th><th>Customer</th><th>Sale Type</th><th>Status</th></tr>";
                
                foreach ($data['withdrawals'] as $withdrawal) {
                    echo "<tr>";
                    echo "<td>#{$withdrawal['withdrawal_id']}</td>";
                    echo "<td>{$withdrawal['withdrawal_date']}</td>";
                    echo "<td>{$withdrawal['customer_name']}</td>";
                    echo "<td>{$withdrawal['sale_type']}</td>";
                    echo "<td>{$withdrawal['status']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='info'>No withdrawals found for the selected date range.</p>";
            }
        } else {
            echo "<p class='error'>❌ API Error: " . ($data['message'] ?? 'Unknown error') . "</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Exception: " . $e->getMessage() . "</p>";
    }
}

echo "</div>";

echo "<div class='test-section'>";
echo "<h3>🔗 Navigation</h3>";
echo "<p><a href='inventory_withdrawals.php' class='button'>Go to Inventory Withdrawals</a></p>";
echo "<p><a href='fix_withdrawals_display.php' class='button'>Display Fix Tool</a></p>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>📊 Database Date Range Summary</h3>";
try {
    $sql = "SELECT 
                MIN(DATE(withdrawal_date)) as earliest_date,
                MAX(DATE(withdrawal_date)) as latest_date,
                COUNT(*) as total_withdrawals
            FROM inventory_withdrawals";
    
    $result = $conn->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        echo "<p><strong>Earliest withdrawal:</strong> {$row['earliest_date']}</p>";
        echo "<p><strong>Latest withdrawal:</strong> {$row['latest_date']}</p>";
        echo "<p><strong>Total withdrawals:</strong> {$row['total_withdrawals']}</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Error getting date summary: " . $e->getMessage() . "</p>";
}
echo "</div>";
?> 