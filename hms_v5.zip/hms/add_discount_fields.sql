-- Add discount fields to inventory_withdrawals table
USE hospital;

ALTER TABLE inventory_withdrawals 
ADD COLUMN discount_value DECIMAL(10,2) DEFAULT 0.00 AFTER amount_paid,
ADD COLUMN discount_type ENUM('percentage','fixed') DEFAULT 'percentage' AFTER discount_value;

-- Verify the changes
DESCRIBE inventory_withdrawals; 