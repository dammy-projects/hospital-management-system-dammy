<?php
require_once 'includes/header.php';

// Get basic statistics
$stats = [];

// Count patients
$patient_sql = "SELECT COUNT(*) as count FROM patients WHERE status = 'active'";
$patient_result = $conn->query($patient_sql);
$stats['patients'] = $patient_result->fetch_assoc()['count'];

// Count doctors
$doctor_sql = "SELECT COUNT(*) as count FROM doctors WHERE status = 'active'";
$doctor_result = $conn->query($doctor_sql);
$stats['doctors'] = $doctor_result->fetch_assoc()['count'];

// Count today's appointments
$appointment_sql = "SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = CURDATE()";
$appointment_result = $conn->query($appointment_sql);
$stats['appointments_today'] = $appointment_result->fetch_assoc()['count'];

// Count pending appointments
$pending_sql = "SELECT COUNT(*) as count FROM appointments WHERE status = 'scheduled'";
$pending_result = $conn->query($pending_sql);
$stats['pending_appointments'] = $pending_result->fetch_assoc()['count'];

// Get low stock items
$low_stock_sql = "SELECT ii.*, ic.category_name 
                  FROM inventory_items ii 
                  LEFT JOIN inventory_categories ic ON ii.category_id = ic.category_id 
                  WHERE ii.quantity_in_stock <= ii.reorder_level 
                  AND ii.status = 'active' 
                  ORDER BY ii.quantity_in_stock ASC 
                  LIMIT 10";
$low_stock_result = $conn->query($low_stock_sql);
$low_stock_count = $low_stock_result ? $low_stock_result->num_rows : 0;

// Get upcoming appointments (next 7 days)
$upcoming_appointments_sql = "SELECT a.*, 
                              CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) AS patient_name,
                              CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) AS doctor_name,
                              p.contact_number as patient_phone,
                              d.contact_number as doctor_phone
                              FROM appointments a 
                              LEFT JOIN patients p ON a.patient_id = p.patient_id 
                              LEFT JOIN doctors d ON a.doctor_id = d.doctor_id 
                              WHERE a.status = 'scheduled' 
                              AND a.appointment_date >= NOW() 
                              AND a.appointment_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)
                              ORDER BY a.appointment_date ASC 
                              LIMIT 10";
$upcoming_appointments_result = $conn->query($upcoming_appointments_sql);
$upcoming_count = $upcoming_appointments_result ? $upcoming_appointments_result->num_rows : 0;

// Get today's appointments
$today_appointments_sql = "SELECT a.*, 
                          CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) AS patient_name,
                          CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) AS doctor_name,
                          p.contact_number as patient_phone,
                          d.contact_number as doctor_phone
                          FROM appointments a 
                          LEFT JOIN patients p ON a.patient_id = p.patient_id 
                          LEFT JOIN doctors d ON a.doctor_id = d.doctor_id 
                          WHERE a.status = 'scheduled' 
                          AND DATE(a.appointment_date) = CURDATE()
                          ORDER BY a.appointment_date ASC";
$today_appointments_result = $conn->query($today_appointments_sql);
$today_count = $today_appointments_result ? $today_appointments_result->num_rows : 0;

// Get recent activity
$activity_sql = "SELECT sl.*, u.full_name 
               FROM system_logs sl 
               LEFT JOIN users u ON sl.user_id = u.user_id 
               ORDER BY sl.log_timestamp DESC 
               LIMIT 10";
$activity_result = $conn->query($activity_sql);

// Get recent appointments
$recent_appt_sql = "SELECT a.*, 
                    CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) AS patient_name,
                    CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) AS doctor_name 
                    FROM appointments a 
                    LEFT JOIN patients p ON a.patient_id = p.patient_id 
                    LEFT JOIN doctors d ON a.doctor_id = d.doctor_id 
                    ORDER BY a.appointment_date DESC 
                    LIMIT 5";
$recent_appt_result = $conn->query($recent_appt_sql);
?>

<div class="container">
    <section class="section">
        <div class="columns">
            <div class="column">
                <h1 class="title">
                    Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!
                </h1>
                <p class="subtitle">
                    Hospital Management System Dashboard
                </p>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="columns is-multiline">
            <div class="column is-3">
                <div class="card">
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">
                                <span class="icon is-large has-text-info">
                                    <i class="fas fa-user-injured fa-2x"></i>
                                </span>
                            </div>
                            <div class="media-content">
                                <p class="title is-4"><?php echo $stats['patients']; ?></p>
                                <p class="subtitle is-6">Active Patients</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="column is-3">
                <div class="card">
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">
                                <span class="icon is-large has-text-success">
                                    <i class="fas fa-user-md fa-2x"></i>
                                </span>
                            </div>
                            <div class="media-content">
                                <p class="title is-4"><?php echo $stats['doctors']; ?></p>
                                <p class="subtitle is-6">Active Doctors</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="column is-3">
                <div class="card">
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">
                                <span class="icon is-large has-text-warning">
                                    <i class="fas fa-calendar-check fa-2x"></i>
                                </span>
                            </div>
                            <div class="media-content">
                                <p class="title is-4"><?php echo $stats['appointments_today']; ?></p>
                                <p class="subtitle is-6">Today's Appointments</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="column is-3">
                <div class="card">
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">
                                <span class="icon is-large has-text-danger">
                                    <i class="fas fa-clock fa-2x"></i>
                                </span>
                            </div>
                            <div class="media-content">
                                <p class="title is-4"><?php echo $stats['pending_appointments']; ?></p>
                                <p class="subtitle is-6">Pending Appointments</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs Navigation -->
        <div class="tabs is-centered is-boxed">
            <ul>
                <li class="is-active">
                    <a href="#overview">
                        <span class="icon is-small">
                            <i class="fas fa-home"></i>
                        </span>
                        <span>Overview</span>
                    </a>
                </li>
                <li>
                    <a href="#appointments">
                        <span class="icon is-small">
                            <i class="fas fa-calendar-check"></i>
                        </span>
                        <span>Appointments</span>
                    </a>
                </li>
                <li>
                    <a href="#inventory">
                        <span class="icon is-small">
                            <i class="fas fa-boxes"></i>
                        </span>
                        <span>Inventory</span>
                    </a>
                </li>
                <li>
                    <a href="#activity">
                        <span class="icon is-small">
                            <i class="fas fa-history"></i>
                        </span>
                        <span>Activity</span>
                    </a>
                </li>
                <li>
                    <a href="#quick-actions">
                        <span class="icon is-small">
                            <i class="fas fa-bolt"></i>
                        </span>
                        <span>Quick Actions</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
            <!-- Overview Tab -->
            <div id="overview" class="tab-pane is-active">
                <div class="columns">
                    <div class="column">
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-chart-line"></i>
                                    </span>
                                    System Overview
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <div class="columns is-multiline">
                                        <div class="column is-6">
                                            <h5 class="title is-5">Today's Summary</h5>
                                            <ul>
                                                <li><strong>Appointments Today:</strong> <?php echo $stats['appointments_today']; ?></li>
                                                <li><strong>Pending Appointments:</strong> <?php echo $stats['pending_appointments']; ?></li>
                                                <li><strong>Active Patients:</strong> <?php echo $stats['patients']; ?></li>
                                                <li><strong>Active Doctors:</strong> <?php echo $stats['doctors']; ?></li>
                                            </ul>
                                        </div>
                                        <div class="column is-6">
                                            <h5 class="title is-5">Alerts</h5>
                                            <ul>
                                                <?php if ($low_stock_count > 0): ?>
                                                    <li class="has-text-warning">
                                                        <span class="icon">
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                        </span>
                                                        <strong>Low Stock:</strong> <?php echo $low_stock_count; ?> items need reordering
                                                    </li>
                                                <?php endif; ?>
                                                <?php if ($upcoming_count > 0): ?>
                                                    <li class="has-text-info">
                                                        <span class="icon">
                                                            <i class="fas fa-calendar-check"></i>
                                                        </span>
                                                        <strong>Upcoming:</strong> <?php echo $upcoming_count; ?> appointments in next 7 days
                                                    </li>
                                                <?php endif; ?>
                                                <?php if ($today_count > 0): ?>
                                                    <li class="has-text-success">
                                                        <span class="icon">
                                                            <i class="fas fa-calendar-day"></i>
                                                        </span>
                                                        <strong>Today:</strong> <?php echo $today_count; ?> appointments scheduled
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Appointments Tab -->
            <div id="appointments" class="tab-pane">
                <div class="columns">
                    <div class="column">
                        <!-- Today's Appointments -->
                        <?php if ($today_count > 0): ?>
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-calendar-day"></i>
                                    </span>
                                    Today's Appointments
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <?php if ($today_appointments_result && $today_appointments_result->num_rows > 0): ?>
                                        <table class="table is-fullwidth">
                                            <thead>
                                                <tr>
                                                    <th>Patient</th>
                                                    <th>Doctor</th>
                                                    <th>Time</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($appt = $today_appointments_result->fetch_assoc()): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($appt['patient_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo htmlspecialchars($appt['doctor_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo date('g:i A', strtotime($appt['appointment_date'])); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($appt['status'])); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p class="has-text-grey">No appointments scheduled for today.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Upcoming Appointments -->
                        <?php if ($upcoming_count > 0): ?>
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-calendar-week"></i>
                                    </span>
                                    Upcoming Appointments (Next 7 Days)
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <?php if ($upcoming_appointments_result && $upcoming_appointments_result->num_rows > 0): ?>
                                        <table class="table is-fullwidth">
                                            <thead>
                                                <tr>
                                                    <th>Patient</th>
                                                    <th>Doctor</th>
                                                    <th>Date/Time</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($appt = $upcoming_appointments_result->fetch_assoc()): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($appt['patient_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo htmlspecialchars($appt['doctor_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo date('M j, Y g:i A', strtotime($appt['appointment_date'])); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($appt['status'])); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p class="has-text-grey">No upcoming appointments found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Inventory Tab -->
            <div id="inventory" class="tab-pane">
                <div class="columns">
                    <div class="column">
                        <?php if ($low_stock_count > 0): ?>
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-exclamation-triangle"></i>
                                    </span>
                                    Low Stock Items
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <?php if ($low_stock_result && $low_stock_result->num_rows > 0): ?>
                                        <table class="table is-fullwidth">
                                            <thead>
                                                <tr>
                                                    <th>Item Name</th>
                                                    <th>Category</th>
                                                    <th>Current Stock</th>
                                                    <th>Reorder Level</th>
                                                    <th>Unit</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($item = $low_stock_result->fetch_assoc()): ?>
                                                    <tr class="<?php echo $item['quantity_in_stock'] == 0 ? 'has-background-danger-light' : 'has-background-warning-light'; ?>">
                                                        <td>
                                                            <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                                                            <?php if ($item['serial_number']): ?>
                                                                <br><small class="has-text-grey"><?php echo htmlspecialchars($item['serial_number']); ?></small>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($item['category_name'] ?? 'Uncategorized'); ?></td>
                                                        <td>
                                                            <span class="tag <?php echo $item['quantity_in_stock'] == 0 ? 'is-danger' : 'is-warning'; ?> is-medium">
                                                                <?php echo $item['quantity_in_stock']; ?>
                                                            </span>
                                                        </td>
                                                        <td><?php echo $item['reorder_level']; ?></td>
                                                        <td><?php echo htmlspecialchars($item['unit'] ?? 'N/A'); ?></td>
                                                        <td>
                                                            <?php if ($item['quantity_in_stock'] == 0): ?>
                                                                <span class="tag is-danger">Out of Stock</span>
                                                            <?php else: ?>
                                                                <span class="tag is-warning">Low Stock</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p class="has-text-grey">No low stock items found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="notification is-success">
                            <span class="icon">
                                <i class="fas fa-check-circle"></i>
                            </span>
                            All inventory items are well-stocked!
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Activity Tab -->
            <div id="activity" class="tab-pane">
                <div class="columns">
                    <div class="column">
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-history"></i>
                                    </span>
                                    Recent System Activity
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <?php if ($activity_result && $activity_result->num_rows > 0): ?>
                                        <table class="table is-fullwidth">
                                            <thead>
                                                <tr>
                                                    <th>User</th>
                                                    <th>Action</th>
                                                    <th>Time</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($row = $activity_result->fetch_assoc()): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($row['full_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo htmlspecialchars($row['action']); ?></td>
                                                        <td><?php echo date('M j, Y g:i A', strtotime($row['log_timestamp'])); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p class="has-text-grey">No recent activity found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-calendar-alt"></i>
                                    </span>
                                    Recent Appointments
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="content">
                                    <?php if ($recent_appt_result && $recent_appt_result->num_rows > 0): ?>
                                        <table class="table is-fullwidth">
                                            <thead>
                                                <tr>
                                                    <th>Patient</th>
                                                    <th>Doctor</th>
                                                    <th>Date/Time</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($row = $recent_appt_result->fetch_assoc()): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($row['patient_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo htmlspecialchars($row['doctor_name'] ?? 'Unknown'); ?></td>
                                                        <td><?php echo date('M j, Y g:i A', strtotime($row['appointment_date'])); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p class="has-text-grey">No recent appointments found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions Tab -->
            <div id="quick-actions" class="tab-pane">
                <div class="columns">
                    <div class="column">
                        <div class="card">
                            <header class="card-header">
                                <p class="card-header-title">
                                    <span class="icon">
                                        <i class="fas fa-bolt"></i>
                                    </span>
                                    Quick Actions
                                </p>
                            </header>
                            <div class="card-content">
                                <div class="columns is-multiline">
                                    <div class="column is-3">
                                        <a href="patients.php" class="button is-info is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-user-plus"></i>
                                            </span>
                                            <span>Add Patient</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="appointments.php" class="button is-success is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-calendar-plus"></i>
                                            </span>
                                            <span>New Appointment</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="prescriptions.php" class="button is-warning is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-prescription-bottle-alt"></i>
                                            </span>
                                            <span>Prescriptions</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="billing.php" class="button is-danger is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                            </span>
                                            <span>Billing</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="inventory.php" class="button is-primary is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-boxes"></i>
                                            </span>
                                            <span>Inventory</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="medical_records.php" class="button is-link is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-notes-medical"></i>
                                            </span>
                                            <span>Medical Records</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="reports.php" class="button is-dark is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-chart-bar"></i>
                                            </span>
                                            <span>Reports</span>
                                        </a>
                                    </div>
                                    <div class="column is-3">
                                        <a href="users.php" class="button is-light is-fullwidth">
                                            <span class="icon">
                                                <i class="fas fa-users"></i>
                                            </span>
                                            <span>Users</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabs = document.querySelectorAll('.tabs li');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all tabs and panes
            tabs.forEach(t => t.classList.remove('is-active'));
            tabPanes.forEach(p => p.classList.remove('is-active'));
            
            // Add active class to clicked tab
            this.classList.add('is-active');
            
            // Show corresponding tab pane
            const targetId = this.querySelector('a').getAttribute('href').substring(1);
            document.getElementById(targetId).classList.add('is-active');
        });
    });
});
</script>

<style>
.tab-content {
    margin-top: 1rem;
}

.tab-pane {
    display: none;
}

.tab-pane.is-active {
    display: block;
}

.tabs.is-boxed li.is-active a {
    background-color: #3273dc;
    border-color: #3273dc;
    color: white;
}
</style> 