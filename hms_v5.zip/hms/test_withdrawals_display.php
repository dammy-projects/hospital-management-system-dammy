<?php
// Test script to diagnose inventory withdrawals display issue
require_once 'config/config.php';

echo "<h2>Inventory Withdrawals Display Diagnostic</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { color: green; }
    .error { color: red; }
    .warning { color: orange; }
    .info { color: blue; }
</style>";

echo "<div class='test-section'>";
echo "<h3>1. Database Connection Test</h3>";
if (isset($conn) && $conn) {
    echo "<p class='success'>✅ Database connected successfully</p>";
} else {
    echo "<p class='error'>❌ Database connection failed</p>";
    exit;
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>2. API Controller Test</h3>";
try {
    // Test the controller API endpoint directly
    $_GET['action'] = 'list';
    $_GET['page'] = 1;
    $_GET['limit'] = 6;
    
    // Capture the controller output
    ob_start();
    include 'controllers/InventoryWithdrawalController.php';
    $output = ob_get_clean();
    
    echo "<p class='info'>📡 API Controller Response:</p>";
    echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px; max-height: 400px; overflow-y: auto;'>";
    echo htmlspecialchars($output);
    echo "</pre>";
    
    // Try to decode JSON response
    $jsonData = json_decode($output, true);
    if ($jsonData) {
        echo "<p class='success'>✅ Valid JSON response received</p>";
        echo "<p class='info'>Data structure:</p>";
        echo "<pre>" . print_r($jsonData, true) . "</pre>";
    } else {
        echo "<p class='error'>❌ Invalid JSON response</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Controller error: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>3. Direct Database Query Test</h3>";
try {
    $sql = "SELECT 
                withdrawal_id, 
                withdrawal_date, 
                customer_name, 
                sale_type, 
                payment_status, 
                amount_due, 
                amount_paid, 
                status 
            FROM inventory_withdrawals 
            ORDER BY withdrawal_date DESC 
            LIMIT 5";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        echo "<p class='success'>✅ Found " . $result->num_rows . " withdrawals</p>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Date</th><th>Customer</th><th>Sale Type</th><th>Payment Status</th><th>Status</th></tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>#" . $row['withdrawal_id'] . "</td>";
            echo "<td>" . $row['withdrawal_date'] . "</td>";
            echo "<td>" . $row['customer_name'] . "</td>";
            echo "<td>" . $row['sale_type'] . "</td>";
            echo "<td>" . $row['payment_status'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='warning'>⚠️ No withdrawals found in database</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ Database query error: " . $e->getMessage() . "</p>";
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>4. File Existence Check</h3>";
$files = [
    'inventory_withdrawals.php',
    'js/inventory_withdrawals.js',
    'controllers/InventoryWithdrawalController.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        echo "<p class='success'>✅ $file exists</p>";
    } else {
        echo "<p class='error'>❌ $file missing</p>";
    }
}
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>5. JavaScript Console Test</h3>";
echo "<p class='info'>📋 Copy and paste this JavaScript into your browser console on the inventory_withdrawals.php page:</p>";
echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px;'>";
echo "console.log('Testing withdrawal display...');
console.log('withdrawalManager:', window.withdrawalManager);
console.log('withdrawalsGrid element:', document.getElementById('withdrawalsGrid'));
console.log('loadingSpinner element:', document.getElementById('loadingSpinner'));
console.log('emptyState element:', document.getElementById('emptyState'));

// Test API call directly
fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6')
    .then(response => response.json())
    .then(data => {
        console.log('API Response:', data);
        if (data.success) {
            console.log('Withdrawals found:', data.withdrawals.length);
            console.log('First withdrawal:', data.withdrawals[0]);
        } else {
            console.log('API Error:', data.message);
        }
    })
    .catch(error => {
        console.error('Fetch Error:', error);
    });";
echo "</pre>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h3>6. Quick Fix Test</h3>";
echo "<p class='info'>🔧 Testing if withdrawals can be manually loaded:</p>";
echo "<button onclick='testManualLoad()' class='button'>Test Manual Load</button>";
echo "<div id='manualTestResult' style='margin-top: 10px;'></div>";
echo "</div>";

echo "<script>
function testManualLoad() {
    const resultDiv = document.getElementById('manualTestResult');
    resultDiv.innerHTML = 'Loading...';
    
    fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resultDiv.innerHTML = '<p style=\"color: green;\">✅ API call successful! Found ' + data.withdrawals.length + ' withdrawals</p>';
                resultDiv.innerHTML += '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
            } else {
                resultDiv.innerHTML = '<p style=\"color: red;\">❌ API Error: ' + data.message + '</p>';
            }
        })
        .catch(error => {
            resultDiv.innerHTML = '<p style=\"color: red;\">❌ Fetch Error: ' + error.message + '</p>';
        });
}
</script>";

echo "<div class='test-section'>";
echo "<h3>7. Navigation Links</h3>";
echo "<p><a href='inventory_withdrawals.php'>🔗 Go to Inventory Withdrawals Page</a></p>";
echo "<p><a href='show_recent_purchases.php'>🔗 View Recent Purchases (HTML)</a></p>";
echo "<p><a href='controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6'>🔗 Direct API Test</a></p>";
echo "</div>";
?> 