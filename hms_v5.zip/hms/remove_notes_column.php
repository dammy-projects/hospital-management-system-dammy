<?php
// Optional script to remove the notes column from inventory_withdrawals table
require_once 'config/config.php';

echo "<h2>Remove Notes Column - Database Cleanup</h2>";

try {
    // Check if notes column exists
    $checkQuery = "SHOW COLUMNS FROM inventory_withdrawals LIKE 'notes'";
    $result = $conn->query($checkQuery);
    
    if ($result->num_rows > 0) {
        echo "<p style='color: orange;'>⚠️ Notes column found in database.</p>";
        
        // Show confirmation form
        if (!isset($_POST['confirm_removal'])) {
            echo "<div style='background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 15px 0; border-radius: 5px;'>";
            echo "<h3>⚠️ Warning</h3>";
            echo "<p>This will permanently remove the 'notes' column from the inventory_withdrawals table.</p>";
            echo "<p><strong>This action cannot be undone!</strong></p>";
            echo "<p>Any existing notes data will be lost.</p>";
            echo "</div>";
            
            echo "<form method='POST'>";
            echo "<button type='submit' name='confirm_removal' value='yes' style='background: #dc3545; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;'>Yes, Remove Notes Column</button> ";
            echo "<a href='inventory_withdrawals.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;'>Cancel</a>";
            echo "</form>";
        } else {
            // Remove the column
            $sql = "ALTER TABLE inventory_withdrawals DROP COLUMN notes";
            
            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green;'>✅ Notes column successfully removed from database!</p>";
            } else {
                echo "<p style='color: red;'>❌ Error removing notes column: " . $conn->error . "</p>";
            }
        }
    } else {
        echo "<p style='color: green;'>✅ Notes column is not present in the database!</p>";
    }
    
    // Show current table structure
    echo "<h3>Current inventory_withdrawals table structure:</h3>";
    $structureQuery = "DESCRIBE inventory_withdrawals";
    $structureResult = $conn->query($structureQuery);
    
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0; width: 100%;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $structureResult->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p><a href='inventory_withdrawals.php' style='background: #007cba; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Back to Inventory Withdrawals</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

$conn->close();
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2, h3 { color: #333; }
table { width: 100%; max-width: 800px; }
th { background-color: #f0f0f0; padding: 8px; }
td { padding: 5px; border: 1px solid #ccc; }
</style> 