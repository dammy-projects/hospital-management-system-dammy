// Fixed Inventory Withdrawals Management JavaScript
console.log('Loading inventory withdrawals JavaScript...');

class WithdrawalManager {
    constructor() {
        this.currentPage = 1;
        this.itemsPerPage = window.withdrawalConfig?.itemsPerPage || 6;
        this.totalPages = 1;
        this.currentWithdrawalId = null;
        this.searchTimer = null;
        this.inventoryItems = [];
        this.itemCounter = 0;
        this.isInitialized = false;
        this.isLoadingInventory = false;
        
        console.log('WithdrawalManager constructor called');
        console.log('Items per page set to:', this.itemsPerPage);
        this.initializeWhenReady();
    }

    initializeWhenReady() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    async init() {
        console.log('Initializing WithdrawalManager...');
        
        try {
            // Check if required elements exist
            const requiredElements = ['withdrawalsGrid', 'loadingSpinner', 'emptyState'];
            const missingElements = requiredElements.filter(id => !document.getElementById(id));
            
            if (missingElements.length > 0) {
                console.error('Missing required elements:', missingElements);
                setTimeout(() => this.init(), 100); // Retry in 100ms
                return;
            }
            
            this.initializeEventListeners();
            await this.loadInventoryItems();
            await this.loadWithdrawals();
            
            this.isInitialized = true;
            console.log('WithdrawalManager initialized successfully');
        } catch (error) {
            console.error('Error during initialization:', error);
            // Retry once after 500ms
            setTimeout(() => this.init(), 500);
        }
    }

    initializeEventListeners() {
        console.log('Initializing event listeners...');
        
        // Helper function to safely add event listeners
        const addListener = (id, event, handler) => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener(event, handler);
                console.log(`Added listener for ${id}`);
            } else {
                console.warn(`Element ${id} not found`);
            }
        };

        // Main buttons
        addListener('addWithdrawalBtn', 'click', () => this.openModal());
        addListener('closeModal', 'click', () => this.closeModal());
        // Fix: Ensure only one saveWithdrawal listener
        const saveBtn = document.getElementById('saveWithdrawal');
        if (saveBtn) {
            saveBtn.replaceWith(saveBtn.cloneNode(true)); // Remove all old listeners
            const newSaveBtn = document.getElementById('saveWithdrawal');
            newSaveBtn.addEventListener('click', () => this.saveWithdrawal());
            console.log('Added single listener for saveWithdrawal');
        }
        
        // Debug the addItemBtn element
        const addItemBtn = document.getElementById('addItemBtn');
        console.log('Add Item Button found:', !!addItemBtn);
        if (addItemBtn) {
            addItemBtn.addEventListener('click', () => {
                console.log('Add Item Button clicked!');
                this.addItemEntry();
            });
        } else {
            console.error('Add Item Button not found!');
        }
        
        // Fallback: Use event delegation for dynamically created buttons
        document.addEventListener('click', (e) => {
            if (e.target && e.target.id === 'addItemBtn') {
                console.log('Add Item Button clicked via delegation!');
                this.addItemEntry();
            }
        });

        // Search and filters
        addListener('searchInput', 'input', (e) => this.debounceSearch(e.target.value));
        addListener('statusFilter', 'change', () => this.loadWithdrawals());
        addListener('saleTypeFilter', 'change', () => this.loadWithdrawals());
        addListener('sortBy', 'change', () => this.loadWithdrawals());
        addListener('clearFilters', 'click', () => this.clearFilters());

        // Date range filters
        addListener('startDate', 'change', () => this.loadWithdrawals());
        addListener('endDate', 'change', () => this.loadWithdrawals());
        addListener('quickDateFilter', 'change', (e) => this.applyQuickDateFilter(e.target.value));
        addListener('applyDateFilter', 'click', () => this.loadWithdrawals());
        addListener('clearDateFilter', 'click', () => this.clearDateFilter());

        // Print and export buttons
        addListener('printFilteredReport', 'click', () => this.printFilteredReport());
        addListener('printSummary', 'click', () => this.printSummaryReport());
        addListener('printDetailedReport', 'click', () => this.printDetailedReport());

        // View modal
        addListener('closeViewModal', 'click', () => this.closeViewModal());
        addListener('closeViewModalBtn', 'click', () => this.closeViewModal());

        // View modal background click
        const viewModalBackground = document.querySelector('#viewWithdrawalModal .modal-background');
        if (viewModalBackground) {
            viewModalBackground.addEventListener('click', () => this.closeViewModal());
        }

        // Delete modal
        addListener('closeDeleteModal', 'click', () => this.closeDeleteModal());
        addListener('cancelDelete', 'click', () => this.closeDeleteModal());
        addListener('confirmDelete', 'click', () => this.deleteWithdrawal());

        // Pagination
        addListener('prevPage', 'click', () => this.goToPage(this.currentPage - 1));
        addListener('nextPage', 'click', () => this.goToPage(this.currentPage + 1));

        // Calculation events
        addListener('discountValue', 'input', () => this.calculateTotals());
        addListener('discountType', 'change', () => this.calculateTotals());
        addListener('amountPaid', 'input', () => this.calculateTotals());
        
        // Add event listeners for item-related calculations
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('item-select') || 
                e.target.classList.contains('item-quantity') || 
                e.target.classList.contains('item-price')) {
                this.calculateTotals();
            }
        });
        
        document.addEventListener('input', (e) => {
            if (e.target.classList.contains('item-quantity') || 
                e.target.classList.contains('item-price')) {
                this.calculateTotals();
            }
        });

        // Withdrawal modal background click
        const withdrawalModalBackground = document.querySelector('#withdrawalModal .modal-background');
        if (withdrawalModalBackground) {
            withdrawalModalBackground.addEventListener('click', () => this.closeModal());
        }
    }

    debounceSearch(searchValue) {
        clearTimeout(this.searchTimer);
        this.searchTimer = setTimeout(() => {
            this.loadWithdrawals();
        }, 300);
    }

    async loadWithdrawals() {
        console.log('Loading withdrawals...');
        
        this.showLoading();
        
        try {
            const params = new URLSearchParams({
                action: 'list',
                page: this.currentPage,
                limit: this.itemsPerPage,
                search: this.getElementValue('searchInput'),
                status: this.getElementValue('statusFilter'),
                sale_type: this.getElementValue('saleTypeFilter'),
                sort: this.getElementValue('sortBy') || 'withdrawal_date',
                start_date: this.getElementValue('startDate'),
                end_date: this.getElementValue('endDate')
            });

            console.log('Fetching with params:', params.toString());
            
            const response = await fetch(`controllers/InventoryWithdrawalController.php?${params}`);
            const data = await response.json();

            console.log('API Response:', data);

            if (data.success) {
                this.renderWithdrawals(data.withdrawals);
                this.renderPagination(data.pagination);
                this.updateReportInfo(data.pagination);
                this.hideLoading();
                
                if (data.withdrawals.length === 0) {
                    this.showEmptyState();
                } else {
                    this.hideEmptyState();
                }
            } else {
                console.error('Failed to load withdrawals:', data.message);
                this.showError(data.message);
                this.hideLoading();
                this.showEmptyState();
            }
        } catch (error) {
            console.error('Error loading withdrawals:', error);
            this.showError('Failed to load withdrawals');
            this.hideLoading();
            this.showEmptyState();
        }
    }

    renderWithdrawals(withdrawals) {
        const grid = document.getElementById('withdrawalsGrid');
        if (!grid) {
            console.error('Withdrawals grid not found');
            return;
        }
        
        grid.innerHTML = '';

        if (!withdrawals || withdrawals.length === 0) {
            grid.innerHTML = '<div class="column is-12"><p class="has-text-centered">No withdrawals found</p></div>';
            return;
        }
        
        withdrawals.forEach(withdrawal => {
            const card = this.createWithdrawalCard(withdrawal);
            grid.appendChild(card);
        });
    }

    createWithdrawalCard(withdrawal) {
        const card = document.createElement('div');
        card.className = 'column is-4';

        const statusClass = this.getStatusClass(withdrawal.status);
        const paymentStatusClass = this.getPaymentStatusClass(withdrawal.payment_status);

        // Calculate total items
        const totalItems = withdrawal.items ? withdrawal.items.reduce((sum, item) => sum + parseInt(item.quantity), 0) : 0;
        
        card.innerHTML = `
            <div class="card">
                <header class="card-header">
                    <p class="card-header-title">
                        ${this.escapeHtml(withdrawal.customer_name)}
                    </p>
                    <div class="card-header-icon">
                        <span class="tag ${statusClass}">${withdrawal.status}</span>
                    </div>
                </header>
                <div class="card-content">
                    <div class="content">
                        <div class="columns is-multiline">
                            <div class="column is-6">
                                <small class="has-text-grey">Date</small>
                                <p class="has-text-weight-medium">${this.formatDate(withdrawal.withdrawal_date)}</p>
                                </div>
                            <div class="column is-6">
                                <small class="has-text-grey">Sale Type</small>
                                <p class="has-text-weight-medium">${withdrawal.sale_type}</p>
                        </div>
                            <div class="column is-6">
                                <small class="has-text-grey">Amount Due</small>
                                <p class="has-text-weight-medium">₱${parseFloat(withdrawal.amount_due).toFixed(2)}</p>
                            </div>
                            <div class="column is-6">
                                <small class="has-text-grey">Payment Status</small>
                                <p class="has-text-weight-medium">
                                    <span class="tag ${paymentStatusClass}">${withdrawal.payment_status}</span>
                            </p>
                        </div>
                            <div class="column is-6">
                                <small class="has-text-grey">Items</small>
                                <p class="has-text-weight-medium">${totalItems} items</p>
                    </div>
                            <div class="column is-6">
                                <small class="has-text-grey">Performed By</small>
                                <p class="has-text-weight-medium">${this.escapeHtml(withdrawal.performed_by || 'N/A')}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="card-footer">
                    <a class="card-footer-item" onclick="window.withdrawalManager.viewWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-eye"></i></span>
                        <span>View</span>
                    </a>
                    <a class="card-footer-item" onclick="window.withdrawalManager.editWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-edit"></i></span>
                        <span>Edit</span>
                    </a>
                    <a class="card-footer-item" onclick="window.withdrawalManager.printWithdrawal(${withdrawal.withdrawal_id})">
                        <span class="icon"><i class="fas fa-print"></i></span>
                        <span>Print</span>
                    </a>
                    <a class="card-footer-item" onclick="window.withdrawalManager.confirmDelete(${withdrawal.withdrawal_id}, '${this.escapeHtml(withdrawal.customer_name)}')">
                        <span class="icon"><i class="fas fa-trash"></i></span>
                        <span>Delete</span>
                    </a>
                </footer>
            </div>
        `;

        return card;
    }

    getStatusClass(status) {
        const statusClasses = {
            'pending': 'is-warning',
            'approved': 'is-info',
            'completed': 'is-success',
            'cancelled': 'is-danger'
        };
        return statusClasses[status] || 'is-light';
    }

    getPaymentStatusClass(paymentStatus) {
        const paymentStatusClasses = {
            'unpaid': 'is-danger',
            'partial': 'is-warning',
            'paid': 'is-success'
        };
        return paymentStatusClasses[paymentStatus] || 'is-light';
    }

    getElementValue(id) {
        const element = document.getElementById(id);
        return element ? element.value : '';
    }

    setElementValue(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.value = value;
        }
    }

    showLoading() {
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
            spinner.style.display = 'block';
        }
    }

    hideLoading() {
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
            spinner.style.display = 'none';
        }
    }

    showEmptyState() {
        const emptyState = document.getElementById('emptyState');
        if (emptyState) {
            emptyState.style.display = 'block';
        }
    }

    hideEmptyState() {
        const emptyState = document.getElementById('emptyState');
        if (emptyState) {
            emptyState.style.display = 'none';
        }
    }

        showError(message) {
        console.error('Error:', message);
        // Use system notification only
        if (typeof showNotification === 'function') {
            showNotification('error', message);
        }
    }

    showSuccess(message) {
        console.log('Success:', message);
        // Use system notification only
        if (typeof showNotification === 'function') {
            showNotification('success', message);
        }
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async loadInventoryItems() {
        console.log('Loading inventory items...');
        try {
            const response = await fetch('controllers/InventoryItemController.php?action=getItems&limit=1000');
            const data = await response.json();

            console.log('API Response:', data);

            if (data.success) {
                // Handle different possible response structures
                if (data.data && data.data.items) {
                    this.inventoryItems = data.data.items;
                } else if (data.items) {
                    this.inventoryItems = data.items;
                } else if (data.data) {
                    this.inventoryItems = data.data;
                } else {
                    this.inventoryItems = [];
                }
                console.log('Inventory items loaded:', this.inventoryItems.length);
            } else {
                console.error('Failed to load inventory items:', data.message);
                this.inventoryItems = [];
            }
        } catch (error) {
            console.error('Error loading inventory items:', error);
            this.inventoryItems = [];
        }
    }

    async openModal(isEdit = false, withdrawal = null) {
        console.log('Opening modal...');
        const modal = document.getElementById('withdrawalModal');
        if (modal) {
            modal.classList.add('is-active');
            document.body.classList.add('modal-open');

            // Add or get hidden withdrawalId input
            let withdrawalIdInput = document.getElementById('withdrawalId');
            if (!withdrawalIdInput) {
                withdrawalIdInput = document.createElement('input');
                withdrawalIdInput.type = 'hidden';
                withdrawalIdInput.id = 'withdrawalId';
                withdrawalIdInput.name = 'withdrawalId';
                const form = document.getElementById('withdrawalForm');
                if (form) form.appendChild(withdrawalIdInput);
            }

            if (isEdit && withdrawal) {
                this.currentWithdrawalId = withdrawal.withdrawal_id;
                withdrawalIdInput.value = withdrawal.withdrawal_id;
            } else {
                this.currentWithdrawalId = null;
                withdrawalIdInput.value = '';
            }
            // Remove status dropdown if present
            const statusField = document.getElementById('statusField');
            if (statusField) statusField.style.display = 'none';
            
            // Update modal title
            const modalTitle = document.getElementById('modalTitle');
            if (modalTitle) {
                modalTitle.textContent = isEdit ? 'Edit Withdrawal' : 'New Withdrawal';
            }
            
            // Set default values
            this.setElementValue('withdrawalDate', new Date().toISOString().slice(0, 16));
            this.setElementValue('status', 'pending');
            this.setElementValue('saleType', 'retail');
            this.setElementValue('paymentStatus', 'unpaid');
            this.setElementValue('discountValue', '0');
            this.setElementValue('discountType', 'percentage');
            this.setElementValue('amountPaid', '0');
            
            // Clear items container
            const itemsContainer = document.getElementById('itemsContainer');
            if (itemsContainer) {
                itemsContainer.innerHTML = '';
            }
            
            // Reset item counter
            this.itemCounter = 0;
            
            // Refresh inventory items to get latest stock levels
            console.log('Refreshing inventory items for latest stock levels...');
            await this.loadInventoryItems();
            
            // Initialize calculations
            this.calculateTotals();
            
            // Ensure addItemBtn event listener is set up
            setTimeout(() => {
                const addItemBtn = document.getElementById('addItemBtn');
                console.log('Add Item Button in modal found:', !!addItemBtn);
                if (addItemBtn) {
                    // Remove existing listeners to avoid duplicates
                    const newBtn = addItemBtn.cloneNode(true);
                    addItemBtn.parentNode.replaceChild(newBtn, addItemBtn);
                    
                    newBtn.addEventListener('click', () => {
                        console.log('Add Item Button clicked from modal!');
                        this.addItemEntry();
                    });
                }
            }, 100);
        }
    }

    closeModal() {
        console.log('Closing modal...');
        const modal = document.getElementById('withdrawalModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
            
            // Clear form data
            const form = document.getElementById('withdrawalForm');
            if (form) {
                form.reset();
            }
            
            // Clear items container
            const itemsContainer = document.getElementById('itemsContainer');
            if (itemsContainer) {
                itemsContainer.innerHTML = '';
            }
            
            // Reset item counter
            this.itemCounter = 0;
            
            // Reset current withdrawal ID
            this.currentWithdrawalId = null;
        }
    }

    async saveWithdrawal() {
        console.log('Saving withdrawal...');
        // Validate form
        const customerName = this.getElementValue('customerName');
        const withdrawalDate = this.getElementValue('withdrawalDate');
        const withdrawalIdInput = document.getElementById('withdrawalId');
        const withdrawalId = withdrawalIdInput ? withdrawalIdInput.value : '';
        const isEdit = withdrawalId !== '';
        // Collect items data
        const items = [];
        const itemEntries = document.querySelectorAll('.item-entry');
        for (const entry of itemEntries) {
            const itemSelect = entry.querySelector('.item-select');
            const quantityInput = entry.querySelector('.item-quantity');
            const priceInput = entry.querySelector('.item-price');
            if (!itemSelect || !quantityInput || !priceInput) {
                console.log('Early return: Missing item entry elements');
                continue;
            }
            const itemId = itemSelect.value;
            const quantity = parseInt(quantityInput.value);
            const price = parseFloat(priceInput.value);
            if (!itemId || quantity <= 0 || price <= 0) {
                console.log('Early return: Invalid item details', { itemId, quantity, price });
                this.showError('Please fill in all item details correctly');
                return;
            }
            // Check stock availability
            const selectedItem = this.inventoryItems.find(item => item.id == itemId);
            if (!selectedItem) {
                console.log('Early return: Selected item not found', { itemId });
                this.showError('Selected item not found');
                return;
            }
            if (selectedItem.quantity_in_stock < quantity) {
                console.log('Early return: Insufficient stock', { itemId, quantity, available: selectedItem.quantity_in_stock });
                this.showError(`Insufficient stock for ${selectedItem.item_name}. Available: ${selectedItem.quantity_in_stock}`);
                return;
            }
            items.push({
                item_id: itemId,
                quantity: quantity,
                price: price
            });
        }
        if (!customerName.trim()) {
            console.log('Early return: Customer name is empty');
            this.showError('Customer name is required');
            return;
        }
        if (!withdrawalDate) {
            console.log('Early return: Withdrawal date is empty');
            this.showError('Withdrawal date is required');
            return;
        }
        if (items.length === 0) {
            console.log('Early return: No items added');
            this.showError('At least one item is required');
            return;
        }
        // ... rest of method ...
        // Prepare form data
        const formData = new FormData();
        formData.append('action', isEdit ? 'update' : 'create');
        if (isEdit) {
            formData.append('withdrawal_id', withdrawalId);
        }
        formData.append('status', 'completed');
        formData.append('customer_name', customerName);
        formData.append('withdrawal_date', withdrawalDate);
        formData.append('sale_type', this.getElementValue('saleType'));
        formData.append('payment_status', this.getElementValue('paymentStatus'));
        formData.append('amount_due', this.getElementValue('amountDue'));
        formData.append('amount_paid', this.getElementValue('amountPaid'));
        formData.append('discount_value', this.getElementValue('discountValue'));
        formData.append('discount_type', this.getElementValue('discountType'));
        formData.append('items', JSON.stringify(items));
        // If editing, show confirmation modal before proceeding
        if (isEdit) {
            this.showUpdateConfirmModal(() => this._doSaveWithdrawal(formData));
            return;
        }
        await this._doSaveWithdrawal(formData);
    }

    async _doSaveWithdrawal(formData) {
        try {
            const response = await fetch('controllers/InventoryWithdrawalController.php', {
                method: 'POST',
                body: formData
            });
            console.log('Response received:', response.status);
            const responseText = await response.text();
            console.log('Raw response text:', responseText);
            let data;
            try {
                data = JSON.parse(responseText);
                console.log('Parsed response data:', data);
            } catch (parseError) {
                console.error('Failed to parse JSON response:', parseError);
                console.error('Raw response was:', responseText);
                this.showError('Invalid server response');
                return;
            }
            if (data.success) {
                // Show notification modal only for update
                const isEdit = formData.get('action') === 'update';
                if (isEdit) {
                    this.showNotificationModal('Withdrawal updated successfully.');
                }
                this.showSuccess(data.message);
                this.closeModal();
                this.loadWithdrawals();
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error saving withdrawal:', error);
            this.showError('Failed to save withdrawal');
        }
    }

    showNotificationModal(message) {
        let modal = document.getElementById('notificationModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'modal';
            modal.id = 'notificationModal';
            modal.innerHTML = `
                <div class="modal-background"></div>
                <div class="modal-card">
                    <header class="modal-card-head">
                        <p class="modal-card-title">Notification</p>
                        <button class="delete" aria-label="close" id="closeNotificationModal"></button>
                    </header>
                    <section class="modal-card-body">
                        <div class="content">
                            <p id="notificationMessage"></p>
                        </div>
                    </section>
                    <footer class="modal-card-foot">
                        <button class="button is-primary" id="closeNotificationBtn">Close</button>
                    </footer>
                </div>`;
            document.body.appendChild(modal);
        }
        document.getElementById('notificationMessage').textContent = message;
        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
        document.getElementById('closeNotificationModal').onclick = () => {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        };
        document.getElementById('closeNotificationBtn').onclick = () => {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        };
    }

    addItemEntry() {
        console.log('=== ADD ITEM ENTRY CALLED ===');
        console.log('Available inventory items:', this.inventoryItems ? this.inventoryItems.length : 'undefined');
        
        const itemsContainer = document.getElementById('itemsContainer');
        if (!itemsContainer) {
            console.error('Items container not found');
            return;
        }
        
        console.log('Items container found:', itemsContainer);
        
        this.itemCounter++;
        const entryId = `item_${this.itemCounter}`;
        
        // Check if inventory items are loaded
        if (!this.inventoryItems || this.inventoryItems.length === 0) {
            console.warn('No inventory items available, loading them now...');
            
            // Prevent infinite recursion by checking if we're already loading
            if (this.isLoadingInventory) {
                console.log('Already loading inventory items, please wait...');
                return;
            }
            
            this.isLoadingInventory = true;
            this.loadInventoryItems().then(() => {
                this.isLoadingInventory = false;
                console.log('Inventory items loaded, retrying addItemEntry...');
                // Only retry if we actually got items
                if (this.inventoryItems && this.inventoryItems.length > 0) {
                    this.addItemEntry();
                } else {
                    console.error('Failed to load inventory items, cannot create item entry');
                }
            }).catch(() => {
                this.isLoadingInventory = false;
                console.error('Failed to load inventory items');
            });
            return;
        }
        
        console.log('Creating item entry with ID:', entryId);
        
        const itemEntry = document.createElement('div');
        itemEntry.className = 'item-entry';
        itemEntry.id = entryId;
        
        // Filter items with stock > 0 and create options with stock info
        const availableItems = this.inventoryItems.filter(item => item.quantity_in_stock > 0);
        const itemOptions = availableItems.map(item => 
            `<option value="${item.id}" data-price="${item.price}" data-stock="${item.quantity_in_stock}">${this.escapeHtml(item.item_name)} (Stock: ${item.quantity_in_stock})</option>`
        ).join('');
        
        console.log('Generated options count:', itemOptions.length);
        
        itemEntry.innerHTML = `
            <button type="button" class="remove-item-btn" onclick="window.withdrawalManager.removeItemEntry('${entryId}')">
                <i class="fas fa-times"></i>
            </button>
            
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Item Name *</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select class="item-select" required>
                                    <option value="">Select an item</option>
                                    ${itemOptions}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Quantity *</label>
                        <div class="control">
                            <input class="input item-quantity" type="number" min="1" value="1" required />
                        </div>
                        <p class="help stock-info" style="display: none; color: #ff3860;"></p>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Unit Price (₱)</label>
                        <div class="control">
                            <input class="input item-price" type="number" step="0.01" min="0" readonly />
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Total (₱)</label>
                        <div class="control">
                            <input class="input item-total" type="text" value="₱0.00" readonly />
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        itemsContainer.appendChild(itemEntry);
        console.log('Item entry added to container');
        
        // Add event listeners for auto-calculation and stock validation
        const itemSelect = itemEntry.querySelector('.item-select');
        const quantityInput = itemEntry.querySelector('.item-quantity');
        const priceInput = itemEntry.querySelector('.item-price');
        const stockInfo = itemEntry.querySelector('.stock-info');
        
        console.log('Found elements:', {
            itemSelect: !!itemSelect,
            quantityInput: !!quantityInput,
            priceInput: !!priceInput,
            stockInfo: !!stockInfo
        });
        
        // Item selection change
        itemSelect.addEventListener('change', () => {
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            if (selectedOption && selectedOption.value) {
                const price = parseFloat(selectedOption.dataset.price) || 0;
                const stock = parseInt(selectedOption.dataset.stock) || 0;
                
                priceInput.value = price.toFixed(2);
                quantityInput.max = stock;
                
                // Show stock info
                if (stockInfo) {
                    stockInfo.textContent = `Available stock: ${stock}`;
                    stockInfo.style.display = 'block';
                    stockInfo.style.color = '#00d1b2';
                }
                
                this.calculateItemTotal(itemEntry);
                this.calculateTotals();
            } else {
                priceInput.value = '';
                quantityInput.max = '';
                if (stockInfo) {
                    stockInfo.style.display = 'none';
                }
                this.calculateItemTotal(itemEntry);
                this.calculateTotals();
            }
        });
        
        // Quantity change with stock validation
        quantityInput.addEventListener('input', () => {
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            if (selectedOption && selectedOption.value) {
                const stock = parseInt(selectedOption.dataset.stock) || 0;
                const quantity = parseInt(quantityInput.value) || 0;
                
                if (quantity > stock) {
                    if (stockInfo) {
                        stockInfo.textContent = `Insufficient stock! Available: ${stock}`;
                        stockInfo.style.color = '#ff3860';
                        stockInfo.style.display = 'block';
                    }
                    quantityInput.classList.add('is-danger');
                } else {
                    if (stockInfo) {
                        stockInfo.textContent = `Available stock: ${stock}`;
                        stockInfo.style.color = '#00d1b2';
                        stockInfo.style.display = 'block';
                    }
                    quantityInput.classList.remove('is-danger');
                }
            }
            
            this.calculateItemTotal(itemEntry);
            this.calculateTotals();
        });
        
        // Price change (if manually editable)
        priceInput.addEventListener('input', () => {
            this.calculateItemTotal(itemEntry);
            this.calculateTotals();
        });
        
        console.log('Item entry added successfully:', entryId);
    }

    calculateItemTotal(itemEntry) {
        const quantityInput = itemEntry.querySelector('.item-quantity');
        const priceInput = itemEntry.querySelector('.item-price');
        const totalInput = itemEntry.querySelector('.item-total');
        
        if (quantityInput && priceInput && totalInput) {
            const quantity = parseFloat(quantityInput.value) || 0;
            const price = parseFloat(priceInput.value) || 0;
            const total = quantity * price;
            totalInput.value = `₱${total.toFixed(2)}`;
        }
    }

    removeItemEntry(entryId) {
        console.log('Removing item entry:', entryId);
        const itemEntry = document.getElementById(entryId);
        if (itemEntry) {
            itemEntry.remove();
            this.calculateTotals();
        }
    }

    async viewWithdrawal(withdrawalId) {
        console.log('Viewing withdrawal:', withdrawalId);
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                this.currentWithdrawalId = withdrawalId;
                this.showWithdrawalDetails(data.withdrawal);
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal:', error);
            this.showError('Failed to load withdrawal');
        }
    }

    showWithdrawalDetails(withdrawal) {
        const modal = document.getElementById('viewWithdrawalModal');
        const detailsContainer = document.getElementById('withdrawalDetails');
        
        if (!modal || !detailsContainer) {
            console.error('View modal elements not found');
            return;
        }

        const statusClass = this.getStatusClass(withdrawal.status);
        const paymentStatusClass = this.getPaymentStatusClass(withdrawal.payment_status);
        const formattedDate = this.formatDate(withdrawal.withdrawal_date);

        // Calculate total amount
        const totalAmount = withdrawal.items.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * parseInt(item.quantity));
        }, 0);

        // Generate items table
        const itemsTable = withdrawal.items.map(item => {
            const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
            return `
                <tr>
                    <td>${this.escapeHtml(item.item_name)}</td>
                    <td>${item.quantity}</td>
                    <td>₱${parseFloat(item.price).toFixed(2)}</td>
                    <td>₱${itemTotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        detailsContainer.innerHTML = `
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Customer Name</label>
                        <div class="box">${this.escapeHtml(withdrawal.customer_name)}</div>
                    </div>
                </div>
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Withdrawal Date</label>
                        <div class="box">${formattedDate}</div>
                    </div>
                </div>
            </div>

            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Sale Type</label>
                        <div class="box">${withdrawal.sale_type.charAt(0).toUpperCase() + withdrawal.sale_type.slice(1)}</div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Status</label>
                        <div class="box">
                            <span class="status-badge ${statusClass}">${withdrawal.status}</span>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Payment Status</label>
                        <div class="box">
                            <span class="payment-status-badge ${paymentStatusClass}">${withdrawal.payment_status}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Calculation Display -->
            <div class="box has-background-light">
                <h5 class="title is-6 has-text-primary">
                    <span class="icon">
                        <i class="fas fa-calculator"></i>
                    </span>
                    Payment Breakdown
                </h5>
            
                <div class="columns">
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Subtotal</label>
                            <div class="box">₱${totalAmount.toFixed(2)}</div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Discount</label>
                            <div class="box">
                                ${withdrawal.discount_value && parseFloat(withdrawal.discount_value) > 0 ? 
                                    `${withdrawal.discount_value}${withdrawal.discount_type === 'percentage' ? '%' : ' ₱'}` : 
                                    'No discount'}
                            </div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Discount Amount</label>
                            <div class="box has-text-danger">
                                ${withdrawal.discount_value && parseFloat(withdrawal.discount_value) > 0 ? 
                                    `-₱${this.calculateDiscountAmount(totalAmount, withdrawal.discount_value, withdrawal.discount_type).toFixed(2)}` : 
                                    '-₱0.00'}
                            </div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Final Amount</label>
                            <div class="box has-text-weight-bold has-text-primary">₱${parseFloat(withdrawal.amount_due).toFixed(2)}</div>
                        </div>
                    </div>
                </div>
            
                <div class="columns">
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Amount Paid</label>
                            <div class="box">₱${parseFloat(withdrawal.amount_paid).toFixed(2)}</div>
                        </div>
                    </div>
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Balance</label>
                            <div class="box has-text-weight-bold ${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)) === 0 ? 'has-text-success' : 'has-text-danger'}">
                                ₱${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)).toFixed(2)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="field">
                <label class="label">Withdrawal Items</label>
                <table class="table is-fullwidth items-table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsTable}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3">Total Amount</th>
                            <th>₱${totalAmount.toFixed(2)}</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        `;

        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
        // Only attach close listener to the footer close button
        const closeFooterBtn = document.getElementById('closeViewModalBtn');
        if (closeFooterBtn) closeFooterBtn.onclick = this.closeViewModal.bind(this);
    }

    async editWithdrawal(withdrawalId) {
        console.log('Editing withdrawal:', withdrawalId);
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                this.currentWithdrawalId = withdrawalId;
                // Call openModal in edit mode and pass withdrawal
                this.openModal(true, data.withdrawal);
                this.loadWithdrawalForEdit(data.withdrawal);
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal for editing:', error);
            this.showError('Failed to load withdrawal for editing');
        }
    }

    loadWithdrawalForEdit(withdrawal) {
        console.log('Loading withdrawal for edit:', withdrawal);
        
        // Open modal
        const modal = document.getElementById('withdrawalModal');
        if (modal) {
            modal.classList.add('is-active');
            document.body.classList.add('modal-open');
        }
        
        // Update modal title
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
            modalTitle.textContent = 'Edit Withdrawal';
        }
        
        // Populate form fields
        this.setElementValue('customerName', withdrawal.customer_name);
        this.setElementValue('withdrawalDate', withdrawal.withdrawal_date);
        this.setElementValue('saleType', withdrawal.sale_type);
        this.setElementValue('paymentStatus', withdrawal.payment_status);
        this.setElementValue('discountValue', withdrawal.discount_value || '0');
        this.setElementValue('discountType', withdrawal.discount_type || 'percentage');
        this.setElementValue('amountPaid', withdrawal.amount_paid || '0');
        
        // Remove status dropdown if present
        const statusField = document.getElementById('statusField');
        if (statusField) statusField.style.display = 'none';
        
        // Clear existing items
        const itemsContainer = document.getElementById('itemsContainer');
        if (itemsContainer) {
            itemsContainer.innerHTML = '';
        }
        
        // Reset item counter
        this.itemCounter = 0;
        
        // Load withdrawal items
        if (withdrawal.items && withdrawal.items.length > 0) {
            withdrawal.items.forEach(item => {
                this.addItemEntryForEdit(item);
            });
        }
        
        // Calculate totals
        this.calculateTotals();
    }

    addItemEntryForEdit(item) {
        console.log('Adding item entry for edit:', item);
        
        this.itemCounter++;
        const entryId = `item_${this.itemCounter}`;
        
        const itemsContainer = document.getElementById('itemsContainer');
        if (!itemsContainer) {
            console.error('Items container not found');
            return;
        }
        
        // Filter items with stock > 0 and create options with stock info
        const availableItems = this.inventoryItems.filter(invItem => invItem.quantity_in_stock > 0);
        const itemOptions = availableItems.map(invItem => 
            `<option value="${invItem.id}" data-price="${invItem.price}" data-stock="${invItem.quantity_in_stock}" ${invItem.id == item.item_id ? 'selected' : ''}>${this.escapeHtml(invItem.item_name)} (Stock: ${invItem.quantity_in_stock})</option>`
        ).join('');
        
        const itemEntry = document.createElement('div');
        itemEntry.className = 'item-entry';
        itemEntry.id = entryId;
        
        itemEntry.innerHTML = `
            <button type="button" class="remove-item-btn" onclick="window.withdrawalManager.removeItemEntry('${entryId}')">
                <i class="fas fa-times"></i>
            </button>
            
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Item Name *</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select class="item-select" required>
                                    <option value="">Select an item</option>
                                    ${itemOptions}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Quantity *</label>
                        <div class="control">
                            <input class="input item-quantity" type="number" min="1" value="${item.quantity}" required />
                        </div>
                        <p class="help stock-info" style="display: none; color: #ff3860;"></p>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Unit Price (₱)</label>
                        <div class="control">
                            <input class="input item-price" type="number" step="0.01" min="0" value="${item.price}" readonly />
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Total (₱)</label>
                        <div class="control">
                            <input class="input item-total" type="text" value="₱${(item.quantity * item.price).toFixed(2)}" readonly />
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        itemsContainer.appendChild(itemEntry);
        
        // Add event listeners for auto-calculation and stock validation
        const itemSelect = itemEntry.querySelector('.item-select');
        const quantityInput = itemEntry.querySelector('.item-quantity');
        const priceInput = itemEntry.querySelector('.item-price');
        const stockInfo = itemEntry.querySelector('.stock-info');
        
        // Item selection change
        itemSelect.addEventListener('change', () => {
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            if (selectedOption && selectedOption.value) {
                const price = parseFloat(selectedOption.dataset.price) || 0;
                const stock = parseInt(selectedOption.dataset.stock) || 0;
                
                priceInput.value = price.toFixed(2);
                quantityInput.max = stock;
                
                // Show stock info
                if (stockInfo) {
                    stockInfo.textContent = `Available stock: ${stock}`;
                    stockInfo.style.display = 'block';
                    stockInfo.style.color = '#00d1b2';
                }
                
                this.calculateItemTotal(itemEntry);
                this.calculateTotals();
            } else {
                priceInput.value = '';
                quantityInput.max = '';
                if (stockInfo) {
                    stockInfo.style.display = 'none';
                }
                this.calculateItemTotal(itemEntry);
                this.calculateTotals();
            }
        });
        
        // Quantity change with stock validation
        quantityInput.addEventListener('input', () => {
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            if (selectedOption && selectedOption.value) {
                const stock = parseInt(selectedOption.dataset.stock) || 0;
                const quantity = parseInt(quantityInput.value) || 0;
                
                if (quantity > stock) {
                    if (stockInfo) {
                        stockInfo.textContent = `Insufficient stock! Available: ${stock}`;
                        stockInfo.style.color = '#ff3860';
                        stockInfo.style.display = 'block';
                    }
                    quantityInput.classList.add('is-danger');
                } else {
                    if (stockInfo) {
                        stockInfo.textContent = `Available stock: ${stock}`;
                        stockInfo.style.color = '#00d1b2';
                        stockInfo.style.display = 'block';
                    }
                    quantityInput.classList.remove('is-danger');
                }
            }
            
            this.calculateItemTotal(itemEntry);
            this.calculateTotals();
        });
        
        // Price change (if manually editable)
        priceInput.addEventListener('input', () => {
            this.calculateItemTotal(itemEntry);
            this.calculateTotals();
        });
        
        console.log('Item entry added for edit:', entryId);
    }

    async printWithdrawal(withdrawalId) {
        console.log('Printing withdrawal:', withdrawalId);
        try {
            const response = await fetch(`controllers/InventoryWithdrawalController.php?action=get&id=${withdrawalId}`);
            const data = await response.json();

            if (data.success) {
                this.generateORReceipt(data.withdrawal);
            } else {
                this.showError(data.message);
            }
        } catch (error) {
            console.error('Error loading withdrawal for printing:', error);
            this.showError('Failed to load withdrawal for printing');
        }
    }

    generateORReceipt(withdrawal) {
        const printArea = document.getElementById('withdrawalPrintArea');
        if (!printArea) {
            console.error('Print area not found');
            return;
        }

        const statusClass = this.getStatusClass(withdrawal.status);
        const paymentStatusClass = this.getPaymentStatusClass(withdrawal.payment_status);
        const formattedDate = this.formatDate(withdrawal.withdrawal_date);
        const currentDate = new Date().toLocaleDateString('en-PH');
        const currentTime = new Date().toLocaleTimeString('en-PH');

        // Calculate totals
        const totalAmount = withdrawal.items.reduce((sum, item) => {
            return sum + (parseFloat(item.price) * parseInt(item.quantity));
        }, 0);

        const discountAmount = this.calculateDiscountAmount(totalAmount, withdrawal.discount_value || 0, withdrawal.discount_type || 'fixed');
        const finalAmount = parseFloat(withdrawal.amount_due);
        const amountPaid = parseFloat(withdrawal.amount_paid);
        const balance = finalAmount - amountPaid;

        // Generate items table
        const itemsTable = withdrawal.items.map(item => {
            const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
            return `
                <tr>
                    <td style="border: 1px solid #000; padding: 5px; text-align: left; font-size: 11px;">${this.escapeHtml(item.item_name)}</td>
                    <td style="border: 1px solid #000; padding: 5px; text-align: center; font-size: 11px;">${item.quantity}</td>
                    <td style="border: 1px solid #000; padding: 5px; text-align: right; font-size: 11px;">₱${parseFloat(item.price).toFixed(2)}</td>
                    <td style="border: 1px solid #000; padding: 5px; text-align: right; font-size: 11px;">₱${itemTotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        printArea.innerHTML = `
            <div style="font-family: Arial, sans-serif; max-width: 80mm; margin: 0 auto; padding: 10px;">
                <!-- Header -->
                <div style="text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px;">
                    <h1 style="margin: 0; font-size: 18px; font-weight: bold;">OFFICIAL RECEIPT</h1>
                    <p style="margin: 5px 0; font-size: 14px; font-weight: bold;">HOSPITAL MANAGEMENT SYSTEM</p>
                    <p style="margin: 5px 0; font-size: 12px;">Inventory Withdrawal</p>
                </div>

                <!-- Receipt Details -->
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Receipt No:</span>
                        <span style="font-size: 12px;">${withdrawal.withdrawal_id}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Date:</span>
                        <span style="font-size: 12px;">${formattedDate}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Time:</span>
                        <span style="font-size: 12px;">${currentTime}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Customer:</span>
                        <span style="font-size: 12px;">${this.escapeHtml(withdrawal.customer_name)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Sale Type:</span>
                        <span style="font-size: 12px;">${withdrawal.sale_type.charAt(0).toUpperCase() + withdrawal.sale_type.slice(1)}</span>
                    </div>
                </div>

                <!-- Items Table -->
                <div style="margin-bottom: 15px;">
                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px;">
                        <thead>
                            <tr>
                                <th style="border: 1px solid #000; padding: 5px; text-align: left; font-size: 11px; background-color: #f0f0f0;">Item</th>
                                <th style="border: 1px solid #000; padding: 5px; text-align: center; font-size: 11px; background-color: #f0f0f0;">Qty</th>
                                <th style="border: 1px solid #000; padding: 5px; text-align: right; font-size: 11px; background-color: #f0f0f0;">Price</th>
                                <th style="border: 1px solid #000; padding: 5px; text-align: right; font-size: 11px; background-color: #f0f0f0;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsTable}
                        </tbody>
                    </table>
                </div>

                <!-- Payment Summary -->
                <div style="border-top: 1px solid #000; padding-top: 10px; margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-size: 12px;">Subtotal:</span>
                        <span style="font-size: 12px;">₱${totalAmount.toFixed(2)}</span>
                    </div>
                    ${withdrawal.discount_value && parseFloat(withdrawal.discount_value) > 0 ? `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="font-size: 12px;">Discount (${withdrawal.discount_value}${withdrawal.discount_type === 'percentage' ? '%' : '₱'}):</span>
                            <span style="font-size: 12px; color: #ff0000;">-₱${discountAmount.toFixed(2)}</span>
                        </div>
                    ` : ''}
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px; border-top: 1px solid #ccc; padding-top: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">TOTAL AMOUNT:</span>
                        <span style="font-weight: bold; font-size: 12px;">₱${finalAmount.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-size: 12px;">Amount Paid:</span>
                        <span style="font-size: 12px;">₱${amountPaid.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Balance:</span>
                        <span style="font-weight: bold; font-size: 12px; color: ${balance === 0 ? '#008000' : '#ff0000'};">₱${balance.toFixed(2)}</span>
                    </div>
                </div>

                <!-- Status Information -->
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Status:</span>
                        <span style="font-size: 12px; text-transform: uppercase;">${withdrawal.status}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span style="font-weight: bold; font-size: 12px;">Payment Status:</span>
                        <span style="font-size: 12px; text-transform: uppercase;">${withdrawal.payment_status}</span>
                    </div>
                </div>

                <!-- Footer -->
                <div style="text-align: center; border-top: 1px solid #000; padding-top: 10px;">
                    <p style="margin: 5px 0; font-size: 11px;">Thank you for your business!</p>
                    <p style="margin: 5px 0; font-size: 10px;">This is a computer-generated receipt</p>
                    <p style="margin: 5px 0; font-size: 10px;">Printed on: ${currentDate} at ${currentTime}</p>
                </div>
            </div>
        `;

        // Trigger print
        window.print();
    }

    confirmDelete(withdrawalId, customerName) {
        console.log('Confirming delete:', withdrawalId, customerName);
        this.currentWithdrawalId = withdrawalId;
        const modal = document.getElementById('deleteModal');
        const deleteInfo = document.getElementById('deleteWithdrawalInfo');
        if (modal && deleteInfo) {
            deleteInfo.textContent = `Withdrawal for ${customerName}`;
            modal.classList.add('is-active');
            document.body.classList.add('modal-open');
        }
    }

    closeDeleteModal() {
        console.log('Closing delete modal...');
        const modal = document.getElementById('deleteModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        }
    }

    async deleteWithdrawal() {
        if (!this.currentWithdrawalId) {
            this.showError('No withdrawal selected');
            return;
        }

        try {
            const response = await fetch('controllers/InventoryWithdrawalController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'delete',
                    withdrawal_id: this.currentWithdrawalId
                })
            });
            
            let result;
            try {
                result = await response.json();
            } catch (jsonErr) {
                const text = await response.text();
                console.error('Raw response:', text);
                this.showError('Server error: ' + text);
                return;
            }
            
            if (result.success) {
                this.showSuccess(result.message);
                this.closeDeleteModal();
                this.loadWithdrawals();
            } else {
                // Show full error message for debugging
                this.showError('Delete failed: ' + (result.message || 'Unknown error'));
                console.error('Delete error details:', result);
            }
        } catch (error) {
            console.error('Error deleting withdrawal:', error);
            this.showError('Failed to delete withdrawal: ' + error);
        }
    }

    goToPage(page) {
        console.log('Going to page:', page);
        if (page >= 1 && page <= this.totalPages) {
            this.currentPage = page;
            this.loadWithdrawals();
        }
    }

    renderPagination(pagination) {
        console.log('Rendering pagination:', pagination);
        
        const paginationContainer = document.getElementById('pagination');
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const paginationList = document.getElementById('paginationList');
        
        if (!paginationContainer || !prevPageBtn || !nextPageBtn || !paginationList) {
            console.error('Pagination elements not found');
            return;
        }
        
        // Update totalPages for goToPage function
        this.totalPages = pagination.total_pages;
        
        // Show/hide pagination based on total pages
        if (pagination.total_pages <= 1) {
            paginationContainer.style.display = 'none';
            return;
        } else {
            paginationContainer.style.display = 'flex';
        }
        
        // Update previous button
        if (pagination.current_page <= 1) {
            prevPageBtn.disabled = true;
            prevPageBtn.classList.add('is-disabled');
        } else {
            prevPageBtn.disabled = false;
            prevPageBtn.classList.remove('is-disabled');
        }
        
        // Update next button
        if (pagination.current_page >= pagination.total_pages) {
            nextPageBtn.disabled = true;
            nextPageBtn.classList.add('is-disabled');
        } else {
            nextPageBtn.disabled = false;
            nextPageBtn.classList.remove('is-disabled');
        }
        
        // Generate page numbers
        paginationList.innerHTML = '';
        
        const maxVisiblePages = 5;
        const currentPage = pagination.current_page;
        const totalPages = pagination.total_pages;
        
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        // Adjust startPage if endPage is at the limit
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        // Add first page and ellipsis if needed
        if (startPage > 1) {
            this.addPageButton(paginationList, 1, currentPage);
            if (startPage > 2) {
                this.addEllipsis(paginationList);
            }
        }
        
        // Add page numbers
        for (let i = startPage; i <= endPage; i++) {
            this.addPageButton(paginationList, i, currentPage);
        }
        
        // Add ellipsis and last page if needed
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                this.addEllipsis(paginationList);
            }
            this.addPageButton(paginationList, totalPages, currentPage);
        }
    }
    
    addPageButton(container, pageNumber, currentPage) {
        const li = document.createElement('li');
        const button = document.createElement('a');
        button.className = 'pagination-link';
        button.textContent = pageNumber;
        button.setAttribute('aria-label', `Go to page ${pageNumber}`);
        
        if (pageNumber === currentPage) {
            button.classList.add('is-current');
            button.setAttribute('aria-current', 'page');
        }
        
        button.addEventListener('click', (e) => {
            e.preventDefault();
            this.goToPage(pageNumber);
        });
        
        li.appendChild(button);
        container.appendChild(li);
    }
    
    addEllipsis(container) {
        const li = document.createElement('li');
        const span = document.createElement('span');
        span.className = 'pagination-ellipsis';
        span.innerHTML = '&hellip;';
        li.appendChild(span);
        container.appendChild(li);
    }

    calculateTotals() {
        console.log('Calculating totals...');
        
        // Calculate subtotal from all items
        let subtotal = 0;
        const itemEntries = document.querySelectorAll('.item-entry');
        
        itemEntries.forEach(entry => {
            const quantityInput = entry.querySelector('.item-quantity');
            const priceInput = entry.querySelector('.item-price');
            
            if (quantityInput && priceInput) {
                const quantity = parseFloat(quantityInput.value) || 0;
                const price = parseFloat(priceInput.value) || 0;
                const itemTotal = quantity * price;
                subtotal += itemTotal;
                
                // Update item total display
                const itemTotalDisplay = entry.querySelector('.item-total');
                if (itemTotalDisplay) {
                    itemTotalDisplay.textContent = `₱${itemTotal.toFixed(2)}`;
                }
            }
        });
        
        // Update subtotal display
        this.setElementValue('subtotal', `₱${subtotal.toFixed(2)}`);
        
        // Calculate discount
        const discountValue = parseFloat(this.getElementValue('discountValue')) || 0;
        const discountType = this.getElementValue('discountType');
        const discountAmount = this.calculateDiscountAmount(subtotal, discountValue, discountType);
        
        // Update discount amount display
        this.setElementValue('discountAmount', `-₱${discountAmount.toFixed(2)}`);
        
        // Calculate total amount due
        const totalAmountDue = subtotal - discountAmount;
        this.setElementValue('totalAmountDue', `₱${totalAmountDue.toFixed(2)}`);
        this.setElementValue('amountDue', totalAmountDue.toFixed(2)); // Hidden field for form submission
        
        // Calculate balance based on amount paid
        const amountPaid = parseFloat(this.getElementValue('amountPaid')) || 0;
        const balance = totalAmountDue - amountPaid;
        
        // Update balance display with color coding
        const balanceInput = document.getElementById('balance');
        if (balanceInput) {
            balanceInput.value = `₱${balance.toFixed(2)}`;
            if (balance === 0) {
                balanceInput.classList.add('has-text-success');
                balanceInput.classList.remove('has-text-danger');
            } else if (balance < 0) {
                balanceInput.classList.add('has-text-success');
                balanceInput.classList.remove('has-text-danger');
            } else {
                balanceInput.classList.add('has-text-danger');
                balanceInput.classList.remove('has-text-success');
            }
        }
        
        console.log('Totals calculated:', {
            subtotal: subtotal.toFixed(2),
            discountAmount: discountAmount.toFixed(2),
            totalAmountDue: totalAmountDue.toFixed(2),
            amountPaid: amountPaid.toFixed(2),
            balance: balance.toFixed(2)
        });
    }

    clearFilters() {
        console.log('Clearing filters...');
        this.setElementValue('searchInput', '');
        this.setElementValue('statusFilter', '');
        this.setElementValue('saleTypeFilter', '');
        this.setElementValue('sortBy', 'withdrawal_date');
        this.setElementValue('startDate', '');
        this.setElementValue('endDate', '');
        this.setElementValue('quickDateFilter', '');
        this.loadWithdrawals();
    }

    applyQuickDateFilter(filterValue) {
        console.log('Applying quick date filter:', filterValue);
        
        if (!filterValue) {
            this.clearDateFilter();
            return;
        }

        const today = new Date();
        const formatDate = (date) => {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        };

        let startDate = '';
        let endDate = '';

        switch (filterValue) {
            case 'today':
                startDate = formatDate(today);
                endDate = formatDate(today);
                break;
            case 'yesterday':
                const yesterday = new Date(today);
                yesterday.setDate(today.getDate() - 1);
                startDate = formatDate(yesterday);
                endDate = formatDate(yesterday);
                break;
            case 'this_week':
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay());
                startDate = formatDate(weekStart);
                endDate = formatDate(today);
                break;
            case 'last_week':
                const lastWeekStart = new Date(today);
                lastWeekStart.setDate(today.getDate() - today.getDay() - 7);
                const lastWeekEnd = new Date(today);
                lastWeekEnd.setDate(today.getDate() - today.getDay() - 1);
                startDate = formatDate(lastWeekStart);
                endDate = formatDate(lastWeekEnd);
                break;
            case 'this_month':
                const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
                startDate = formatDate(monthStart);
                endDate = formatDate(today);
                break;
            case 'last_month':
                const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
                startDate = formatDate(lastMonthStart);
                endDate = formatDate(lastMonthEnd);
                break;
            case 'this_year':
                const yearStart = new Date(today.getFullYear(), 0, 1);
                startDate = formatDate(yearStart);
                endDate = formatDate(today);
                break;
        }

        this.setElementValue('startDate', startDate);
        this.setElementValue('endDate', endDate);
        this.loadWithdrawals();
    }

    clearDateFilter() {
        console.log('Clearing date filter...');
        this.setElementValue('startDate', '');
        this.setElementValue('endDate', '');
        this.setElementValue('quickDateFilter', '');
        this.loadWithdrawals();
    }

    formatDateRange() {
        const startDate = this.getElementValue('startDate');
        const endDate = this.getElementValue('endDate');
        
        if (!startDate && !endDate) {
            return 'All Time';
        }
        
        if (startDate && !endDate) {
            return `From ${startDate}`;
        }
        
        if (!startDate && endDate) {
            return `Until ${endDate}`;
        }
        
        return `${startDate} to ${endDate}`;
    }

    updateReportInfo(pagination) {
        const reportInfo = document.getElementById('reportInfo');
        const recordCount = document.getElementById('recordCount');

        if (reportInfo && recordCount && pagination) {
            const currentPage = pagination.current_page || 1;
            const recordsPerPage = pagination.records_per_page || this.itemsPerPage;
            const totalRecords = pagination.total_records || 0;
            
            const start = Math.min((currentPage - 1) * recordsPerPage + 1, totalRecords);
            const end = Math.min(currentPage * recordsPerPage, totalRecords);

            if (totalRecords > 0) {
                reportInfo.textContent = `Showing ${start} to ${end} of ${totalRecords} records`;
            } else {
                reportInfo.textContent = 'No records found';
            }
            recordCount.textContent = `Total: ${totalRecords} records`;
        }
    }

    async printFilteredReport() {
        console.log('Printing filtered report...');
        try {
            const allData = await this.getAllFilteredData();
            if (allData.success) {
                this.generatePrintReport(allData.withdrawals, 'filtered');
            } else {
                this.showError('Failed to fetch data for printing');
            }
        } catch (error) {
            console.error('Error printing filtered report:', error);
            this.showError('Error generating print report');
        }
    }

    async printSummaryReport() {
        console.log('Printing summary report...');
        try {
            const allData = await this.getAllFilteredData();
            if (allData.success) {
                this.generatePrintReport(allData.withdrawals, 'summary');
            } else {
                this.showError('Failed to fetch data for printing');
            }
        } catch (error) {
            console.error('Error printing summary report:', error);
            this.showError('Error generating print report');
        }
    }

    async printDetailedReport() {
        console.log('Printing detailed report...');
        try {
            const allData = await this.getAllFilteredData();
            if (allData.success) {
                this.generatePrintReport(allData.withdrawals, 'detailed');
            } else {
                this.showError('Failed to fetch data for printing');
            }
        } catch (error) {
            console.error('Error printing detailed report:', error);
            this.showError('Error generating print report');
        }
    }

    async getAllFilteredData() {
        const params = new URLSearchParams({
            action: 'list',
            page: 1,
            limit: 1000, // Get all records
            search: this.getElementValue('searchInput'),
            status: this.getElementValue('statusFilter'),
            sale_type: this.getElementValue('saleTypeFilter'),
            sort: this.getElementValue('sortBy') || 'withdrawal_date',
            start_date: this.getElementValue('startDate'),
            end_date: this.getElementValue('endDate')
        });

        const response = await fetch(`controllers/InventoryWithdrawalController.php?${params}`);
        return await response.json();
    }

    generatePrintReport(withdrawals, reportType) {
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        let reportTitle = '';
        let reportContent = '';
        
        switch (reportType) {
            case 'summary':
                reportTitle = 'Inventory Withdrawals Summary Report';
                reportContent = this.generateSummaryContent(withdrawals);
                break;
            case 'detailed':
                reportTitle = 'Detailed Inventory Withdrawals Report';
                reportContent = this.generateDetailedContent(withdrawals);
                break;
            default:
                reportTitle = 'Inventory Withdrawals Report';
                reportContent = this.generateFilteredContent(withdrawals);
        }

        const dateRange = this.formatDateRange();
        const currentDate = new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        const printHTML = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>${reportTitle}</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                    font-size: 12px;
                    line-height: 1.4;
                    color: #333;
                }
                .header {
                    text-align: center;
                    border-bottom: 2px solid #000;
                    padding-bottom: 10px;
                    margin-bottom: 20px;
                    page-break-inside: avoid;
                }
                .hospital-name {
                    font-size: 18px;
                    font-weight: bold;
                    margin-bottom: 5px;
                }
                .report-title {
                    font-size: 16px;
                    font-weight: bold;
                    margin-bottom: 5px;
                }
                .report-date {
                    font-size: 12px;
                    color: #666;
                }
                .report-info {
                    margin-bottom: 20px;
                    padding: 10px;
                    background-color: #f9f9f9;
                    border: 1px solid #ddd;
                    page-break-inside: avoid;
                }
                .info-row {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 5px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                    page-break-inside: avoid;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 8px;
                    text-align: left;
                    vertical-align: top;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                th {
                    background-color: #f0f0f0;
                    font-weight: bold;
                }
                .text-right {
                    text-align: right;
                }
                .text-center {
                    text-align: center;
                }
                .amount {
                    text-align: right;
                }
                .footer {
                    margin-top: 30px;
                    text-align: center;
                    font-size: 10px;
                    border-top: 1px solid #000;
                    padding-top: 10px;
                    page-break-inside: avoid;
                }
                .page-break {
                    page-break-before: always;
                }
                .summary-box {
                    background-color: #f5f5f5;
                    padding: 15px;
                    margin: 20px 0;
                    border: 1px solid #ccc;
                    page-break-inside: avoid;
                }
                .items-table {
                    font-size: 11px;
                    margin-bottom: 10px;
                }
                .withdrawal-section {
                    margin-bottom: 40px;
                    page-break-inside: avoid;
                    page-break-after: always;
                }
                .withdrawal-section:last-child {
                    page-break-after: auto;
                }
                .grand-summary {
                    page-break-before: always;
                    page-break-inside: avoid;
                }
                
                /* Responsive table handling */
                .table-wrapper {
                    overflow-x: auto;
                    margin-bottom: 20px;
                }
                
                /* Prevent text overflow */
                .text-overflow {
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    max-width: 150px;
                }
                
                /* Grid layout fallback for older browsers */
                .grid-fallback {
                    display: table;
                    width: 100%;
                }
                .grid-item-fallback {
                    display: table-cell;
                    width: 33.33%;
                    padding: 15px;
                    text-align: center;
                    vertical-align: middle;
                }
                
                @media print {
                    body { 
                        margin: 0; 
                        font-size: 11px;
                        line-height: 1.3;
                    }
                    .page-break { 
                        page-break-before: always; 
                    }
                    .withdrawal-section {
                        page-break-after: always;
                        page-break-inside: avoid;
                    }
                    .grand-summary {
                        page-break-before: always;
                        page-break-inside: avoid;
                    }
                    table {
                        page-break-inside: avoid;
                    }
                    tr {
                        page-break-inside: avoid;
                    }
                    .no-print {
                        display: none;
                    }
                    /* Ensure grid displays properly in print */
                    .grid-fallback {
                        display: table !important;
                    }
                    .grid-item-fallback {
                        display: table-cell !important;
                    }
                    /* Override any flex/grid that might not work in print */
                    [style*="display: grid"] {
                        display: table !important;
                    }
                    [style*="display: flex"] {
                        display: block !important;
                    }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="hospital-name">Hospital Management System</div>
                <div class="report-title">${reportTitle}</div>
                <div class="report-date">Generated on: ${currentDate}</div>
            </div>
            
            <div class="report-info">
                <div class="info-row">
                    <span><strong>Date Range:</strong> ${dateRange}</span>
                    <span><strong>Total Records:</strong> ${withdrawals.length}</span>
                </div>
                <div class="info-row">
                    <span><strong>Search Filter:</strong> ${this.getElementValue('searchInput') || 'None'}</span>
                    <span><strong>Status Filter:</strong> ${this.getElementValue('statusFilter') || 'All'}</span>
                </div>
                <div class="info-row">
                    <span><strong>Sale Type Filter:</strong> ${this.getElementValue('saleTypeFilter') || 'All'}</span>
                    <span><strong>Sort By:</strong> ${this.getElementValue('sortBy') || 'Date'}</span>
                </div>
            </div>
            
            ${reportContent}
            
            <div class="footer">
                <p>Hospital Management System - Inventory Withdrawals Report</p>
                <p>Page 1 of 1 | Generated: ${currentDate}</p>
            </div>
        </body>
        </html>
        `;

        printWindow.document.write(printHTML);
        printWindow.document.close();
        
        // Wait for content to load then print
        printWindow.onload = function() {
            printWindow.focus();
            printWindow.print();
        };
    }

    generateFilteredContent(withdrawals) {
        if (withdrawals.length === 0) {
            return '<p style="text-align: center; font-style: italic;">No withdrawals found for the selected criteria.</p>';
        }

        let content = `
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Sale Type</th>
                    <th>Items Count</th>
                    <th>Total Amount</th>
                    <th>Amount Paid</th>
                    <th>Balance</th>
                    <th>Payment Status</th>
                </tr>
            </thead>
            <tbody>
        `;

        let grandTotal = 0;
        let totalAmountPaid = 0;
        let totalBalance = 0;

        withdrawals.forEach(withdrawal => {
            const totalAmount = withdrawal.items.reduce((sum, item) => {
                return sum + (parseFloat(item.price) * parseInt(item.quantity));
            }, 0);
            const amountPaid = parseFloat(withdrawal.amount_paid || 0);
            const balance = totalAmount - amountPaid;
            
            grandTotal += totalAmount;
            totalAmountPaid += amountPaid;
            totalBalance += balance;

            content += `
                <tr>
                    <td>#${withdrawal.withdrawal_id}</td>
                    <td>${this.formatDate(withdrawal.withdrawal_date)}</td>
                    <td>${this.escapeHtml(withdrawal.customer_name)}</td>
                    <td>${withdrawal.sale_type}</td>
                    <td class="text-center">${withdrawal.items.length}</td>
                    <td class="amount">₱${totalAmount.toFixed(2)}</td>
                    <td class="amount">₱${amountPaid.toFixed(2)}</td>
                    <td class="amount">₱${balance.toFixed(2)}</td>
                    <td class="text-center">${withdrawal.payment_status}</td>
                </tr>
            `;
        });

        content += `
            </tbody>
            <tfoot>
                <tr style="background-color: #f0f0f0; font-weight: bold;">
                    <td colspan="5">TOTAL</td>
                    <td class="amount">₱${grandTotal.toFixed(2)}</td>
                    <td class="amount">₱${totalAmountPaid.toFixed(2)}</td>
                    <td class="amount">₱${totalBalance.toFixed(2)}</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
        `;

        return content;
    }

    generateSummaryContent(withdrawals) {
        if (withdrawals.length === 0) {
            return '<p style="text-align: center; font-style: italic;">No withdrawals found for the selected criteria.</p>';
        }

        // Calculate summary statistics
        const stats = {
            totalWithdrawals: withdrawals.length,
            totalAmount: 0,
            totalPaid: 0,
            totalItems: 0,
            statusBreakdown: {},
            paymentStatusBreakdown: {},
            saleTypeBreakdown: {},
            customerBreakdown: {}
        };

        withdrawals.forEach(withdrawal => {
            const totalAmount = withdrawal.items.reduce((sum, item) => {
                return sum + (parseFloat(item.price) * parseInt(item.quantity));
            }, 0);
            
            stats.totalAmount += totalAmount;
            stats.totalPaid += parseFloat(withdrawal.amount_paid);
            stats.totalItems += withdrawal.items.length;
            
            // Count by status
            stats.statusBreakdown[withdrawal.status] = (stats.statusBreakdown[withdrawal.status] || 0) + 1;
            stats.paymentStatusBreakdown[withdrawal.payment_status] = (stats.paymentStatusBreakdown[withdrawal.payment_status] || 0) + 1;
            stats.saleTypeBreakdown[withdrawal.sale_type] = (stats.saleTypeBreakdown[withdrawal.sale_type] || 0) + 1;
            stats.customerBreakdown[withdrawal.customer_name] = (stats.customerBreakdown[withdrawal.customer_name] || 0) + 1;
        });

        let content = `
        <div class="summary-box">
            <h3>Summary Statistics</h3>
            <table style="border: none;">
                <tr style="border: none;">
                    <td style="border: none;"><strong>Total Withdrawals:</strong></td>
                    <td style="border: none;">${stats.totalWithdrawals}</td>
                    <td style="border: none;"><strong>Total Amount:</strong></td>
                    <td style="border: none;">₱${stats.totalAmount.toFixed(2)}</td>
                </tr>
                <tr style="border: none;">
                    <td style="border: none;"><strong>Total Items:</strong></td>
                    <td style="border: none;">${stats.totalItems}</td>
                    <td style="border: none;"><strong>Amount Paid:</strong></td>
                    <td style="border: none;">₱${stats.totalPaid.toFixed(2)}</td>
                </tr>
            </table>
        </div>
        `;

        // Status breakdown
        content += `
        <h3>Breakdown by Status</h3>
        <table>
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Count</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
        `;

        Object.entries(stats.statusBreakdown).forEach(([status, count]) => {
            const percentage = ((count / stats.totalWithdrawals) * 100).toFixed(1);
            content += `
                <tr>
                    <td>${status}</td>
                    <td class="text-center">${count}</td>
                    <td class="text-center">${percentage}%</td>
                </tr>
            `;
        });

        content += `</tbody></table>`;

        // Top customers
        const topCustomers = Object.entries(stats.customerBreakdown)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10);

        content += `
        <h3>Top Customers</h3>
        <table>
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Number of Withdrawals</th>
                </tr>
            </thead>
            <tbody>
        `;

        topCustomers.forEach(([customer, count]) => {
            content += `
                <tr>
                    <td>${this.escapeHtml(customer)}</td>
                    <td class="text-center">${count}</td>
                </tr>
            `;
        });

        content += `</tbody></table>`;

        return content;
    }

    generateDetailedContent(withdrawals) {
        if (withdrawals.length === 0) {
            return '<p style="text-align: center; font-style: italic;">No withdrawals found for the selected criteria.</p>';
        }

        let content = '';
        let grandTotal = 0;

        withdrawals.forEach((withdrawal, index) => {
            const totalAmount = withdrawal.items.reduce((sum, item) => {
                return sum + (parseFloat(item.price) * parseInt(item.quantity));
            }, 0);
            grandTotal += totalAmount;

            content += `
            <div class="withdrawal-section" style="
                margin-bottom: 40px; 
                border: 2px solid #333; 
                padding: 20px; 
                background-color: #fafafa;
                page-break-inside: avoid;
                border-radius: 8px;
            ">
                <div class="withdrawal-header" style="
                    background-color: #e8f4fd; 
                    margin: -20px -20px 20px -20px; 
                    padding: 15px 20px; 
                    border-bottom: 2px solid #333;
                ">
                    <h3 style="
                        margin: 0; 
                        font-size: 16px; 
                        font-weight: bold; 
                        color: #2c3e50;
                        text-align: center;
                    ">
                        WITHDRAWAL #${withdrawal.withdrawal_id} - ${this.escapeHtml(withdrawal.customer_name)}
                    </h3>
                </div>
                
                <div class="withdrawal-info" style="margin-bottom: 20px;">
                    <table style="
                        width: 100%; 
                        border: none; 
                        margin-bottom: 15px;
                        border-spacing: 0;
                    ">
                        <tr>
                            <td style="
                                border: none; 
                                width: 20%; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Date:</td>
                            <td style="
                                border: none; 
                                width: 30%; 
                                padding: 8px 15px 8px 0;
                                vertical-align: top;
                            ">${this.formatDate(withdrawal.withdrawal_date)}</td>
                            <td style="
                                border: none; 
                                width: 20%; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Sale Type:</td>
                            <td style="
                                border: none; 
                                width: 30%; 
                                padding: 8px 15px 8px 0;
                                vertical-align: top;
                            ">${withdrawal.sale_type.toUpperCase()}</td>
                        </tr>
                        <tr>
                            <td style="
                                border: none; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Payment Status:</td>
                            <td style="
                                border: none; 
                                padding: 8px 15px 8px 0;
                                color: ${withdrawal.payment_status === 'paid' ? '#28a745' : withdrawal.payment_status === 'partial' ? '#ffc107' : '#dc3545'};
                                font-weight: bold;
                                vertical-align: top;
                            ">${withdrawal.payment_status.toUpperCase()}</td>
                            <td style="
                                border: none; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Status:</td>
                            <td style="
                                border: none; 
                                padding: 8px 15px 8px 0;
                                color: ${withdrawal.status === 'completed' ? '#28a745' : withdrawal.status === 'pending' ? '#ffc107' : '#dc3545'};
                                font-weight: bold;
                                vertical-align: top;
                            ">${withdrawal.status.toUpperCase()}</td>
                        </tr>
                        <tr>
                            <td style="
                                border: none; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Amount Due:</td>
                            <td style="
                                border: none; 
                                padding: 8px 15px 8px 0;
                                font-weight: bold;
                                vertical-align: top;
                            ">₱${parseFloat(withdrawal.amount_due).toFixed(2)}</td>
                            <td style="
                                border: none; 
                                font-weight: bold; 
                                padding: 8px 15px 8px 0;
                                background-color: #f8f9fa;
                                vertical-align: top;
                            ">Amount Paid:</td>
                            <td style="
                                border: none; 
                                padding: 8px 15px 8px 0;
                                font-weight: bold;
                                vertical-align: top;
                            ">₱${parseFloat(withdrawal.amount_paid).toFixed(2)}</td>
                        </tr>
                    </table>
                </div>
                
                <div class="items-section">
                    <h4 style="
                        margin: 20px 0 15px 0; 
                        font-size: 14px; 
                        font-weight: bold; 
                        color: #2c3e50;
                        background-color: #e8f4fd;
                        padding: 10px;
                        border: 1px solid #bdc3c7;
                        text-align: center;
                    ">ITEMS PURCHASED</h4>
                    
                    <div style="overflow-x: auto; margin-bottom: 20px;">
                        <table style="
                            width: 100%;
                            border-collapse: collapse;
                            font-size: 11px;
                            background-color: white;
                        ">
                            <thead>
                                <tr style="background-color: #34495e; color: white;">
                                    <th style="
                                        border: 1px solid #2c3e50;
                                        padding: 12px 8px;
                                        text-align: left;
                                        font-weight: bold;
                                        width: 45%;
                                    ">Item Name</th>
                                    <th style="
                                        border: 1px solid #2c3e50;
                                        padding: 12px 8px;
                                        text-align: center;
                                        font-weight: bold;
                                        width: 15%;
                                    ">Qty</th>
                                    <th style="
                                        border: 1px solid #2c3e50;
                                        padding: 12px 8px;
                                        text-align: right;
                                        font-weight: bold;
                                        width: 20%;
                                    ">Unit Price</th>
                                    <th style="
                                        border: 1px solid #2c3e50;
                                        padding: 12px 8px;
                                        text-align: right;
                                        font-weight: bold;
                                        width: 20%;
                                    ">Total</th>
                                </tr>
                            </thead>
                            <tbody>
            `;

            withdrawal.items.forEach((item, itemIndex) => {
                const itemTotal = parseFloat(item.price) * parseInt(item.quantity);
                const rowColor = itemIndex % 2 === 0 ? '#ffffff' : '#f8f9fa';
                
                content += `
                    <tr style="background-color: ${rowColor};">
                        <td style="
                            border: 1px solid #bdc3c7;
                            padding: 10px 8px;
                            text-align: left;
                            vertical-align: top;
                        ">${this.escapeHtml(item.item_name)}</td>
                        <td style="
                            border: 1px solid #bdc3c7;
                            padding: 10px 8px;
                            text-align: center;
                            font-weight: bold;
                            vertical-align: top;
                        ">${item.quantity}</td>
                        <td style="
                            border: 1px solid #bdc3c7;
                            padding: 10px 8px;
                            text-align: right;
                            font-weight: bold;
                            vertical-align: top;
                        ">₱${parseFloat(item.price).toFixed(2)}</td>
                        <td style="
                            border: 1px solid #bdc3c7;
                            padding: 10px 8px;
                            text-align: right;
                            font-weight: bold;
                            color: #2c3e50;
                            vertical-align: top;
                        ">₱${itemTotal.toFixed(2)}</td>
                    </tr>
                `;
            });

            content += `
                            </tbody>
                            <tfoot>
                                <tr style="background-color: #2c3e50; color: white;">
                                    <td colspan="3" style="
                                        border: 1px solid #2c3e50;
                                        padding: 15px 8px;
                                        text-align: right;
                                        font-weight: bold;
                                        font-size: 12px;
                                    ">WITHDRAWAL TOTAL:</td>
                                    <td style="
                                        border: 1px solid #2c3e50;
                                        padding: 15px 8px;
                                        text-align: right;
                                        font-weight: bold;
                                        font-size: 12px;
                                    ">₱${totalAmount.toFixed(2)}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                
                <div class="withdrawal-summary" style="
                    background-color: #e8f6f3;
                    padding: 15px;
                    border: 1px solid #27ae60;
                    border-radius: 5px;
                    margin-top: 20px;
                ">
                    <table style="
                        width: 100%;
                        border: none;
                        margin: 0;
                        border-collapse: collapse;
                    ">
                        <tr>
                            <td style="
                                border: none;
                                padding: 0;
                                font-weight: bold;
                                color: #27ae60;
                                font-size: 12px;
                                text-align: left;
                                width: 33.33%;
                            ">Items Count: ${withdrawal.items.length}</td>
                            <td style="
                                border: none;
                                padding: 0;
                                font-weight: bold;
                                color: #27ae60;
                                font-size: 14px;
                                text-align: center;
                                width: 33.33%;
                            ">Total Amount: ₱${totalAmount.toFixed(2)}</td>
                            <td style="
                                border: none;
                                padding: 0;
                                font-weight: bold;
                                color: #27ae60;
                                font-size: 12px;
                                text-align: right;
                                width: 33.33%;
                            ">Balance: ₱${(parseFloat(withdrawal.amount_due) - parseFloat(withdrawal.amount_paid)).toFixed(2)}</td>
                        </tr>
                    </table>
                </div>
            </div>
            `;

            // Add page break after every withdrawal except the last one
            if (index < withdrawals.length - 1) {
                content += '<div style="page-break-before: always; margin: 30px 0;"></div>';
            }
        });

        // Grand total summary
        content += `
        <div style="page-break-before: always; margin-top: 40px;">
            <div class="grand-summary" style="
                background-color: #2c3e50;
                color: white;
                padding: 25px;
                border-radius: 10px;
                text-align: center;
                margin: 20px 0;
            ">
                <h2 style="
                    margin: 0 0 20px 0;
                    font-size: 20px;
                    font-weight: bold;
                ">GRAND TOTAL SUMMARY</h2>
                
                <div style="
                    display: grid;
                    grid-template-columns: 1fr 1fr 1fr;
                    gap: 20px;
                    margin-top: 20px;
                ">
                    <div style="
                        background-color: #34495e;
                        padding: 15px;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Total Withdrawals</div>
                        <div style="font-size: 24px; font-weight: bold;">${withdrawals.length}</div>
                    </div>
                    
                    <div style="
                        background-color: #27ae60;
                        padding: 15px;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Total Items</div>
                        <div style="font-size: 24px; font-weight: bold;">${withdrawals.reduce((sum, w) => sum + w.items.length, 0)}</div>
                    </div>
                    
                    <div style="
                        background-color: #e74c3c;
                        padding: 15px;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Grand Total</div>
                        <div style="font-size: 24px; font-weight: bold;">₱${grandTotal.toFixed(2)}</div>
                    </div>
                </div>
                
                <!-- Fallback layout for better print compatibility -->
                <div class="grid-fallback" style="
                    margin-top: 20px;
                    display: none;
                ">
                    <div class="grid-item-fallback" style="
                        background-color: #34495e;
                        color: white;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Total Withdrawals</div>
                        <div style="font-size: 24px; font-weight: bold;">${withdrawals.length}</div>
                    </div>
                    
                    <div class="grid-item-fallback" style="
                        background-color: #27ae60;
                        color: white;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Total Items</div>
                        <div style="font-size: 24px; font-weight: bold;">${withdrawals.reduce((sum, w) => sum + w.items.length, 0)}</div>
                    </div>
                    
                    <div class="grid-item-fallback" style="
                        background-color: #e74c3c;
                        color: white;
                        border-radius: 8px;
                    ">
                        <div style="font-size: 14px; margin-bottom: 5px;">Grand Total</div>
                        <div style="font-size: 24px; font-weight: bold;">₱${grandTotal.toFixed(2)}</div>
                    </div>
                </div>
            </div>
            
            <div style="
                background-color: #ecf0f1;
                padding: 20px;
                border: 1px solid #bdc3c7;
                border-radius: 8px;
                margin-top: 20px;
            ">
                <h3 style="
                    margin: 0 0 15px 0;
                    font-size: 16px;
                    color: #2c3e50;
                    text-align: center;
                ">DETAILED BREAKDOWN</h3>
                
                <table style="
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                ">
                    <thead>
                        <tr style="background-color: #95a5a6; color: white;">
                            <th style="border: 1px solid #7f8c8d; padding: 10px; text-align: left;">Metric</th>
                            <th style="border: 1px solid #7f8c8d; padding: 10px; text-align: center;">Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; background-color: #f8f9fa;">Total Withdrawals</td>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; text-align: center; font-weight: bold;">${withdrawals.length}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; background-color: #f8f9fa;">Total Items Sold</td>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; text-align: center; font-weight: bold;">${withdrawals.reduce((sum, w) => sum + w.items.length, 0)}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; background-color: #f8f9fa;">Average per Withdrawal</td>
                            <td style="border: 1px solid #bdc3c7; padding: 10px; text-align: center; font-weight: bold;">₱${(grandTotal / withdrawals.length).toFixed(2)}</td>
                        </tr>
                        <tr style="background-color: #2c3e50; color: white;">
                            <td style="border: 1px solid #2c3e50; padding: 12px; font-weight: bold;">GRAND TOTAL AMOUNT</td>
                            <td style="border: 1px solid #2c3e50; padding: 12px; text-align: center; font-weight: bold; font-size: 14px;">₱${grandTotal.toFixed(2)}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        `;

        return content;
    }

    calculateDiscountAmount(subtotal, discountValue, discountType) {
        let discountAmount = 0;
        if (discountValue > 0) {
            if (discountType === 'percentage') {
                discountAmount = (subtotal * discountValue) / 100;
            } else {
                discountAmount = discountValue;
            }
        }
        return discountAmount;
    }

    // Add update confirmation modal logic
    showUpdateConfirmModal(onConfirm) {
        let modal = document.getElementById('updateConfirmModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'modal';
            modal.id = 'updateConfirmModal';
            modal.innerHTML = `
                <div class="modal-background"></div>
                <div class="modal-card">
                    <header class="modal-card-head">
                        <p class="modal-card-title">Confirm Update</p>
                        <button class="delete" aria-label="close" id="closeUpdateConfirmModal"></button>
                    </header>
                    <section class="modal-card-body">
                        <div class="content">
                            <p>Are you sure you want to update this withdrawal?</p>
                            <p class="has-text-warning">This will overwrite the existing record.</p>
                        </div>
                    </section>
                    <footer class="modal-card-foot">
                        <button class="button is-success" id="confirmUpdate">Update Withdrawal</button>
                        <button class="button" id="cancelUpdate">Cancel</button>
                    </footer>
                </div>`;
            document.body.appendChild(modal);
        }
        modal.classList.add('is-active');
        document.body.classList.add('modal-open');
        // Wire up buttons
        document.getElementById('closeUpdateConfirmModal').onclick = () => {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        };
        document.getElementById('cancelUpdate').onclick = () => {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        };
        document.getElementById('confirmUpdate').onclick = () => {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
            if (onConfirm) onConfirm();
        };
    }

    closeViewModal() {
        const modal = document.getElementById('viewWithdrawalModal');
        if (modal) {
            modal.classList.remove('is-active');
            document.body.classList.remove('modal-open');
        }
    }
}

// Initialize the withdrawal manager when the page loads
console.log('Setting up DOMContentLoaded listener...');

function initializeWithdrawalManager() {
    console.log('Initializing withdrawal manager...');
    window.withdrawalManager = new WithdrawalManager();
}

// Multiple initialization approaches to ensure it works
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeWithdrawalManager);
} else {
    initializeWithdrawalManager();
}

// Fallback initialization
setTimeout(initializeWithdrawalManager, 100);

console.log('Inventory withdrawals JavaScript loaded successfully'); 