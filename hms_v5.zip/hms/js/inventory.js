// Inventory Management JavaScript
class InventoryManager {
    constructor() {
        this.currentPage = 1;
        this.itemsPerPage = 4;
        this.totalItems = 0;
        this.totalPages = 0;
        this.searchTerm = '';
        this.categoryFilter = '';
        this.statusFilter = '';
        this.stockFilter = '';
        this.sortBy = 'item_name';
        this.sortOrder = 'ASC';
        this.currentItemId = null;
        this.searchTimeout = null;
        this.categories = [];
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadCategories();
        this.loadInventoryItems();
    }

    setupEventListeners() {
        // Add item button
        document.getElementById('addInventoryBtn').addEventListener('click', () => {
            this.showAddModal();
        });

        // Modal close buttons
        document.getElementById('closeModal').addEventListener('click', () => {
            this.hideModal();
        });

        document.getElementById('cancelModal').addEventListener('click', () => {
            this.hideModal();
        });

        // Save item button
        document.getElementById('saveInventory').addEventListener('click', (e) => {
            e.preventDefault();
            this.saveItem();
        });

        // Delete modal handlers
        document.getElementById('closeDeleteModal').addEventListener('click', () => {
            this.hideDeleteModal();
        });

        document.getElementById('cancelDelete').addEventListener('click', () => {
            this.hideDeleteModal();
        });

        document.getElementById('confirmDelete').addEventListener('click', () => {
            this.deleteItem();
        });

        // View modal handlers
        document.getElementById('closeViewModal').addEventListener('click', () => {
            this.hideViewModal();
        });

        document.getElementById('closeViewInventory').addEventListener('click', () => {
            this.hideViewModal();
        });

        // Search input with debounce
        document.getElementById('searchInput').addEventListener('input', (e) => {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                this.searchTerm = e.target.value.trim();
                this.currentPage = 1;
                this.loadInventoryItems();
            }, 300);
        });

        // Filter handlers
        document.getElementById('categoryFilter').addEventListener('change', (e) => {
            this.categoryFilter = e.target.value;
            this.currentPage = 1;
            this.loadInventoryItems();
        });

        document.getElementById('statusFilter').addEventListener('change', (e) => {
            this.statusFilter = e.target.value;
            this.currentPage = 1;
            this.loadInventoryItems();
        });

        document.getElementById('stockFilter').addEventListener('change', (e) => {
            this.stockFilter = e.target.value;
            this.currentPage = 1;
            this.loadInventoryItems();
        });

        document.getElementById('sortBy').addEventListener('change', (e) => {
            this.sortBy = e.target.value;
            this.currentPage = 1;
            this.loadInventoryItems();
        });

        // Clear filters button
        document.getElementById('clearFilters').addEventListener('click', () => {
            this.clearFilters();
        });

        // Pagination handlers
        document.getElementById('prevPage').addEventListener('click', (e) => {
            e.preventDefault();
            if (this.currentPage > 1) {
                this.currentPage--;
                this.loadInventoryItems();
            }
        });

        document.getElementById('nextPage').addEventListener('click', (e) => {
            e.preventDefault();
            if (this.currentPage < this.totalPages) {
                this.currentPage++;
                this.loadInventoryItems();
            }
        });

        // Modal background click to close
        document.querySelector('#inventoryModal .modal-background').addEventListener('click', () => {
            this.hideModal();
        });

        document.querySelector('#deleteModal .modal-background').addEventListener('click', () => {
            this.hideDeleteModal();
        });

        document.querySelector('#viewInventoryModal .modal-background').addEventListener('click', () => {
            this.hideViewModal();
        });
    }

    async loadCategories() {
        try {
            const response = await fetch('controllers/InventoryItemController.php?action=getCategories');
            const data = await response.json();
            
            if (data.success) {
                this.categories = data.categories;
                this.populateCategoryFilters();
            }
        } catch (error) {
            console.error('Error loading categories:', error);
        }
    }

    populateCategoryFilters() {
        const categorySelect = document.getElementById('categoryId');
        const categoryFilter = document.getElementById('categoryFilter');
        
        // Clear existing options
        categorySelect.innerHTML = '<option value="">Select Category</option>';
        categoryFilter.innerHTML = '<option value="">All Categories</option>';
        
        // Add category options
        this.categories.forEach(category => {
            const option1 = document.createElement('option');
            option1.value = category.id;
            option1.textContent = category.name;
            categorySelect.appendChild(option1);
            
            const option2 = document.createElement('option');
            option2.value = category.id;
            option2.textContent = category.name;
            categoryFilter.appendChild(option2);
        });
    }

    async loadInventoryItems() {
        this.showLoading();
        
        try {
            const params = new URLSearchParams({
                action: 'getItems',
                page: this.currentPage,
                limit: this.itemsPerPage,
                search: this.searchTerm,
                category: this.categoryFilter,
                status: this.statusFilter,
                stock: this.stockFilter,
                sort: this.sortBy,
                order: this.sortOrder
            });

            const response = await fetch(`controllers/InventoryItemController.php?${params}`);
            const data = await response.json();
            
            if (data.success) {
                this.totalItems = data.total;
                this.totalPages = Math.ceil(this.totalItems / this.itemsPerPage);
                this.renderInventoryItems(data.items);
                this.updatePagination();
            } else {
                this.showError(data.message || 'Failed to load inventory items');
            }
        } catch (error) {
            console.error('Error loading inventory items:', error);
            this.showError('Failed to load inventory items');
        } finally {
            this.hideLoading();
        }
    }

    renderInventoryItems(items) {
        const container = document.getElementById('inventoryGrid');
        const emptyState = document.getElementById('emptyState');
        
        if (!items || items.length === 0) {
            container.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }
        
        emptyState.style.display = 'none';
        
        container.innerHTML = items.map(item => this.createInventoryCard(item)).join('');
        
        // Add event listeners to card actions
        this.attachCardEventListeners();
    }

    createInventoryCard(item) {
        const stockStatus = this.getStockStatus(item.quantity_in_stock, item.reorder_level);
        const stockIndicator = this.getStockIndicator(stockStatus);
        const statusBadge = this.getStatusBadge(item.status);
        const price = parseFloat(item.price || 0);
        const totalValue = price * parseInt(item.quantity_in_stock || 0);
        
        return `
            <div class="column">
                <div class="card">
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">
                                <figure class="image is-48x48">
                                    <div class="has-background-primary has-text-white is-flex is-align-items-center is-justify-content-center" style="width: 48px; height: 48px; border-radius: 6px;">
                                        <i class="fas fa-box fa-lg"></i>
                                    </div>
                                </figure>
                            </div>
                            <div class="media-content">
                                <p class="title is-6">${this.escapeHtml(item.item_name)}</p>
                                <p class="subtitle is-7 has-text-grey">${this.escapeHtml(item.category_name || 'No Category')}</p>
                            </div>
                        </div>
                        
                        <div class="content">
                            <div class="inventory-details">
                                <p class="mb-2">
                                    <span class="icon-text">
                                        <span class="icon is-small">
                                            <i class="fas fa-warehouse"></i>
                                        </span>
                                        <span>${stockIndicator} ${item.quantity_in_stock || 0} ${item.unit || 'units'}</span>
                                    </span>
                                </p>
                                <p class="mb-2">
                                    <span class="icon-text">
                                        <span class="icon is-small">
                                            <i class="fas fa-peso-sign"></i>
                                        </span>
                                        <span>₱${price.toFixed(2)} each</span>
                                    </span>
                                </p>
                                <p class="mb-2">
                                    <span class="icon-text">
                                        <span class="icon is-small">
                                            <i class="fas fa-calculator"></i>
                                        </span>
                                        <span>Total: ₱${totalValue.toFixed(2)}</span>
                                    </span>
                                </p>
                                <div class="tags">
                                    ${statusBadge}
                                    <span class="tag is-small ${this.getStockStatusClass(stockStatus)}">${stockStatus}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <footer class="card-footer">
                        <a class="card-footer-item" data-action="view" data-id="${item.id}">
                            <span class="icon is-small">
                                <i class="fas fa-eye"></i>
                            </span>
                            <span>View</span>
                        </a>
                        <a class="card-footer-item" data-action="edit" data-id="${item.id}">
                            <span class="icon is-small">
                                <i class="fas fa-edit"></i>
                            </span>
                            <span>Edit</span>
                        </a>
                        <a class="card-footer-item" data-action="delete" data-id="${item.id}">
                            <span class="icon is-small">
                                <i class="fas fa-trash"></i>
                            </span>
                            <span>Delete</span>
                        </a>
                    </footer>
                </div>
            </div>
        `;
    }

    getStockStatus(quantity, reorderLevel) {
        const qty = parseInt(quantity || 0);
        const reorder = parseInt(reorderLevel || 0);
        
        if (qty === 0) return 'Out of Stock';
        if (reorder > 0 && qty <= reorder) return 'Low Stock';
        return 'In Stock';
    }

    getStockIndicator(status) {
        switch (status) {
            case 'Out of Stock':
                return '<span class="stock-indicator stock-out"></span>';
            case 'Low Stock':
                return '<span class="stock-indicator stock-low"></span>';
            default:
                return '<span class="stock-indicator stock-good"></span>';
        }
    }

    getStockStatusClass(status) {
        switch (status) {
            case 'Out of Stock':
                return 'is-danger';
            case 'Low Stock':
                return 'is-warning';
            default:
                return 'is-success';
        }
    }

    getStatusBadge(status) {
        const statusClasses = {
            'active': 'is-success',
            'inactive': 'is-warning',
            'discontinued': 'is-danger'
        };
        
        const statusClass = statusClasses[status] || 'is-light';
        return `<span class="tag is-small ${statusClass} status-badge">${status}</span>`;
    }

    attachCardEventListeners() {
        document.querySelectorAll('.card-footer-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const action = item.getAttribute('data-action');
                const itemId = item.getAttribute('data-id');
                
                switch (action) {
                    case 'view':
                        this.viewItem(itemId);
                        break;
                    case 'edit':
                        this.editItem(itemId);
                        break;
                    case 'delete':
                        this.confirmDelete(itemId);
                        break;
                }
            });
        });
    }

    showAddModal() {
        document.getElementById('modalTitle').textContent = 'Add New Item';
        document.getElementById('itemId').value = '';
        document.getElementById('inventoryForm').reset();
        this.currentItemId = null;
        document.getElementById('inventoryModal').classList.add('is-active');
    }

    async editItem(itemId) {
        try {
            const response = await fetch(`controllers/InventoryItemController.php?action=getItem&id=${itemId}`);
            const data = await response.json();
            
            if (data.success) {
                this.populateForm(data.item);
                document.getElementById('modalTitle').textContent = 'Edit Item';
                this.currentItemId = itemId;
                document.getElementById('inventoryModal').classList.add('is-active');
            } else {
                this.showError(data.message || 'Failed to load item details');
            }
        } catch (error) {
            console.error('Error loading item details:', error);
            this.showError('Failed to load item details');
        }
    }

    populateForm(item) {
        document.getElementById('itemId').value = item.id;
        document.getElementById('itemName').value = item.item_name || '';
        document.getElementById('categoryId').value = item.category_id || '';
        document.getElementById('itemDescription').value = item.description || '';
        document.getElementById('serialNumber').value = item.serial_number || '';
        document.getElementById('productNumber').value = item.product_number || '';
        document.getElementById('quantityInStock').value = item.quantity_in_stock || '';
        document.getElementById('unit').value = item.unit || '';
        document.getElementById('price').value = item.price || '';
        document.getElementById('reorderLevel').value = item.reorder_level || '';
        document.getElementById('status').value = item.status || 'active';
    }

    async saveItem() {
        const formData = this.getFormData();
        
        if (!this.validateForm(formData)) {
            return;
        }

        try {
            const action = this.currentItemId ? 'updateItem' : 'createItem';
            const response = await fetch('controllers/InventoryItemController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: action,
                    ...formData
                })
            });

            const data = await response.json();
            
            if (data.success) {
                this.showSuccess(data.message || 'Item saved successfully');
                this.hideModal();
                this.loadInventoryItems();
            } else {
                this.showError(data.message || 'Failed to save item');
            }
        } catch (error) {
            console.error('Error saving item:', error);
            this.showError('Failed to save item');
        }
    }

    getFormData() {
        return {
            id: this.currentItemId,
            item_name: document.getElementById('itemName').value.trim(),
            category_id: document.getElementById('categoryId').value,
            description: document.getElementById('itemDescription').value.trim(),
            serial_number: document.getElementById('serialNumber').value.trim(),
            product_number: document.getElementById('productNumber').value.trim(),
            quantity_in_stock: document.getElementById('quantityInStock').value,
            unit: document.getElementById('unit').value.trim(),
            price: document.getElementById('price').value,
            reorder_level: document.getElementById('reorderLevel').value,
            status: document.getElementById('status').value
        };
    }

    validateForm(data) {
        const errors = [];
        
        if (!data.item_name) {
            errors.push('Item name is required');
        }
        
        if (!data.category_id) {
            errors.push('Category is required');
        }
        
        if (!data.quantity_in_stock || data.quantity_in_stock < 0) {
            errors.push('Valid quantity in stock is required');
        }
        
        if (!data.price || data.price < 0) {
            errors.push('Valid price is required');
        }
        
        if (errors.length > 0) {
            this.showError(errors.join('<br>'));
            return false;
        }
        
        return true;
    }

    async confirmDelete(itemId) {
        try {
            const response = await fetch(`controllers/InventoryItemController.php?action=getItem&id=${itemId}`);
            const data = await response.json();
            
            if (data.success) {
                this.currentItemId = itemId;
                document.getElementById('deleteItemInfo').textContent = data.item.item_name;
                document.getElementById('deleteModal').classList.add('is-active');
            } else {
                this.showError(data.message || 'Failed to load item details');
            }
        } catch (error) {
            console.error('Error loading item details:', error);
            this.showError('Failed to load item details');
        }
    }

    async deleteItem() {
        if (!this.currentItemId) return;
        
        try {
            const response = await fetch('controllers/InventoryItemController.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'deleteItem',
                    id: this.currentItemId
                })
            });

            const data = await response.json();
            
            if (data.success) {
                this.showSuccess(data.message || 'Item deleted successfully');
                this.hideDeleteModal();
                this.loadInventoryItems();
            } else {
                this.showError(data.message || 'Failed to delete item');
            }
        } catch (error) {
            console.error('Error deleting item:', error);
            this.showError('Failed to delete item');
        }
    }

    async viewItem(itemId) {
        try {
            const response = await fetch(`controllers/InventoryItemController.php?action=getItem&id=${itemId}`);
            const data = await response.json();
            
            if (data.success) {
                this.populateViewModal(data.item);
                document.getElementById('viewInventoryModal').classList.add('is-active');
            } else {
                this.showError(data.message || 'Failed to load item details');
            }
        } catch (error) {
            console.error('Error loading item details:', error);
            this.showError('Failed to load item details');
        }
    }

    populateViewModal(item) {
        const price = parseFloat(item.price || 0);
        const quantity = parseInt(item.quantity_in_stock || 0);
        const totalValue = price * quantity;
        const stockStatus = this.getStockStatus(item.quantity_in_stock, item.reorder_level);
        const statusBadge = this.getStatusBadge(item.status);
        
        // Header information
        document.getElementById('viewItemName').textContent = item.item_name || 'N/A';
        document.getElementById('viewCategoryName').textContent = item.category_name || 'No Category';
        document.getElementById('viewPrice').textContent = `₱${price.toFixed(2)}`;
        document.getElementById('viewPrice').className = 'tag is-large is-info';
        document.getElementById('viewStatus').innerHTML = statusBadge.replace('is-small', 'is-large');
        
        // Item details
        document.getElementById('viewDescription').textContent = item.description || 'No description available';
        document.getElementById('viewSerialNumber').textContent = item.serial_number || 'N/A';
        document.getElementById('viewProductNumber').textContent = item.product_number || 'N/A';
        
        // Stock information
        document.getElementById('viewQuantityStock').textContent = `${quantity} ${item.unit || 'units'}`;
        document.getElementById('viewUnit').textContent = item.unit || 'N/A';
        document.getElementById('viewReorderLevel').textContent = item.reorder_level || 'Not set';
        
        const stockStatusElement = document.getElementById('viewStockStatus');
        stockStatusElement.textContent = stockStatus;
        stockStatusElement.className = `tag ${this.getStockStatusClass(stockStatus)}`;
        
        // Summary information
        document.getElementById('viewItemId').textContent = item.id;
        document.getElementById('viewPriceSummary').textContent = `₱${price.toFixed(2)}`;
        document.getElementById('viewTotalValue').textContent = `₱${totalValue.toFixed(2)}`;
        document.getElementById('viewLastUpdated').textContent = this.formatDate(item.last_updated);
        
        const statusSummaryElement = document.getElementById('viewStatusSummary');
        statusSummaryElement.innerHTML = statusBadge.replace('is-small', 'is-medium');
    }

    hideModal() {
        document.getElementById('inventoryModal').classList.remove('is-active');
        this.currentItemId = null;
    }

    hideDeleteModal() {
        document.getElementById('deleteModal').classList.remove('is-active');
        this.currentItemId = null;
    }

    hideViewModal() {
        document.getElementById('viewInventoryModal').classList.remove('is-active');
    }

    clearFilters() {
        document.getElementById('searchInput').value = '';
        document.getElementById('categoryFilter').value = '';
        document.getElementById('statusFilter').value = '';
        document.getElementById('stockFilter').value = '';
        document.getElementById('sortBy').value = 'item_name';
        
        this.searchTerm = '';
        this.categoryFilter = '';
        this.statusFilter = '';
        this.stockFilter = '';
        this.sortBy = 'item_name';
        this.currentPage = 1;
        
        this.loadInventoryItems();
    }

    updatePagination() {
        const pagination = document.getElementById('pagination');
        const prevBtn = document.getElementById('prevPage');
        const nextBtn = document.getElementById('nextPage');
        const paginationList = document.getElementById('paginationList');
        
        if (this.totalPages <= 1) {
            pagination.style.display = 'none';
            return;
        }
        
        pagination.style.display = 'flex';
        
        // Update previous button
        prevBtn.classList.toggle('is-disabled', this.currentPage === 1);
        
        // Update next button
        nextBtn.classList.toggle('is-disabled', this.currentPage === this.totalPages);
        
        // Generate page numbers
        paginationList.innerHTML = '';
        
        const startPage = Math.max(1, this.currentPage - 2);
        const endPage = Math.min(this.totalPages, this.currentPage + 2);
        
        for (let i = startPage; i <= endPage; i++) {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.className = `pagination-link ${i === this.currentPage ? 'is-current' : ''}`;
            a.textContent = i;
            a.href = '#';
            
            a.addEventListener('click', (e) => {
                e.preventDefault();
                if (i !== this.currentPage) {
                    this.currentPage = i;
                    this.loadInventoryItems();
                }
            });
            
            li.appendChild(a);
            paginationList.appendChild(li);
        }
    }

    showLoading() {
        document.getElementById('loadingSpinner').style.display = 'block';
        document.getElementById('inventoryContainer').style.display = 'none';
    }

    hideLoading() {
        document.getElementById('loadingSpinner').style.display = 'none';
        document.getElementById('inventoryContainer').style.display = 'block';
    }

    showError(message) {
        // Create or update error notification
        this.removeExistingNotifications();
        
        const notification = document.createElement('div');
        notification.className = 'notification is-danger is-fixed';
        notification.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        notification.innerHTML = `
            <button class="delete"></button>
            <div class="content">
                <p>${message}</p>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
        
        // Add click handler to close button
        notification.querySelector('.delete').addEventListener('click', () => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        });
    }

    showSuccess(message) {
        // Create or update success notification
        this.removeExistingNotifications();
        
        const notification = document.createElement('div');
        notification.className = 'notification is-success is-fixed';
        notification.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        notification.innerHTML = `
            <button class="delete"></button>
            <div class="content">
                <p>${message}</p>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
        
        // Add click handler to close button
        notification.querySelector('.delete').addEventListener('click', () => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        });
    }

    removeExistingNotifications() {
        const existingNotifications = document.querySelectorAll('.notification.is-fixed');
        existingNotifications.forEach(notification => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        });
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch (error) {
            return 'Invalid Date';
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the inventory manager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new InventoryManager();
}); 