// Medical Records Management JavaScript
class MedicalRecordManager {
    constructor() {
        this.currentPage = 1;
        this.itemsPerPage = 4;
        this.totalPages = 1;
        this.currentRecordId = null;
        this.searchTimer = null;
        
        this.initializeEventListeners();
        this.loadDropdownData();
        this.loadMedicalRecords();
    }

    initializeEventListeners() {
        // Add Medical Record Button
        document.getElementById('addMedicalRecordBtn').addEventListener('click', () => {
            this.openModal();
        });

        // Modal Close Buttons
        document.getElementById('closeModal').addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('cancelModal').addEventListener('click', () => {
            this.closeModal();
        });

        // Save Medical Record Button
        document.getElementById('saveMedicalRecord').addEventListener('click', () => {
            this.saveMedicalRecord();
        });

        // Delete Modal Close Buttons
        document.getElementById('closeDeleteModal').addEventListener('click', () => {
            this.closeDeleteModal();
        });

        document.getElementById('cancelDelete').addEventListener('click', () => {
            this.closeDeleteModal();
        });

        // Confirm Delete Button
        document.getElementById('confirmDelete').addEventListener('click', () => {
            this.deleteMedicalRecord();
        });

        // Search Input with Debounce
        document.getElementById('searchInput').addEventListener('input', (e) => {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(() => {
                this.currentPage = 1;
                this.loadMedicalRecords();
            }, 500);
        });

        // Filter Dropdowns
        document.getElementById('patientFilter').addEventListener('change', () => {
            this.currentPage = 1;
            this.loadMedicalRecords();
        });

        document.getElementById('doctorFilter').addEventListener('change', () => {
            this.currentPage = 1;
            this.loadMedicalRecords();
        });

        document.getElementById('statusFilter').addEventListener('change', () => {
            this.currentPage = 1;
            this.loadMedicalRecords();
        });

        document.getElementById('sortBy').addEventListener('change', () => {
            this.currentPage = 1;
            this.loadMedicalRecords();
        });

        // Clear Filters Button
        document.getElementById('clearFilters').addEventListener('click', () => {
            this.clearFilters();
        });

        // Pagination
        document.getElementById('prevPage').addEventListener('click', () => {
            if (this.currentPage > 1) {
                this.currentPage--;
                this.loadMedicalRecords();
            }
        });

        document.getElementById('nextPage').addEventListener('click', () => {
            if (this.currentPage < this.totalPages) {
                this.currentPage++;
                this.loadMedicalRecords();
            }
        });

        // Modal Background Click
        document.querySelector('#medicalRecordModal .modal-background').addEventListener('click', () => {
            this.closeModal();
        });

        document.querySelector('#deleteModal .modal-background').addEventListener('click', () => {
            this.closeDeleteModal();
        });

        document.querySelector('#viewMedicalRecordModal .modal-background').addEventListener('click', () => {
            this.closeViewModal();
        });

        // View Modal Close Buttons
        document.getElementById('closeViewModal').addEventListener('click', () => {
            this.closeViewModal();
        });

        document.getElementById('closeViewMedicalRecord').addEventListener('click', () => {
            this.closeViewModal();
        });

        // Form Submit Prevention
        document.getElementById('medicalRecordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveMedicalRecord();
        });

        // BMI Auto-calculation
        document.getElementById('heightCm').addEventListener('input', () => {
            this.calculateBMI();
        });

        document.getElementById('weightKg').addEventListener('input', () => {
            this.calculateBMI();
        });

        // File upload handling
        document.getElementById('labImages').addEventListener('change', (e) => {
            this.handleFileSelection(e);
        });
    }

    async loadDropdownData() {
        try {
            // Load patients
            const patientsResponse = await fetch('controllers/PatientController.php?action=list_all');
            const patientsData = await patientsResponse.json();
            
            if (patientsData.success) {
                this.populatePatientDropdowns(patientsData.data);
            }

            // Load doctors
            const doctorsResponse = await fetch('controllers/DoctorController.php?action=list_all');
            const doctorsData = await doctorsResponse.json();
            
            if (doctorsData.success) {
                this.populateDoctorDropdowns(doctorsData.data);
            }
        } catch (error) {
            console.error('Error loading dropdown data:', error);
        }
    }

    populatePatientDropdowns(patients) {
        const patientSelect = document.getElementById('patientId');
        const patientFilter = document.getElementById('patientFilter');
        
        // Clear existing options (except first)
        patientSelect.innerHTML = '<option value="">Select Patient</option>';
        patientFilter.innerHTML = '<option value="">All Patients</option>';
        
        patients.forEach(patient => {
            const fullName = `${patient.first_name} ${patient.middle_name ? patient.middle_name + ' ' : ''}${patient.last_name}`;
            
            // Add to form select
            const option1 = document.createElement('option');
            option1.value = patient.patient_id;
            option1.textContent = fullName;
            patientSelect.appendChild(option1);
            
            // Add to filter select
            const option2 = document.createElement('option');
            option2.value = patient.patient_id;
            option2.textContent = fullName;
            patientFilter.appendChild(option2);
        });
    }

    populateDoctorDropdowns(doctors) {
        const doctorSelect = document.getElementById('doctorId');
        const doctorFilter = document.getElementById('doctorFilter');
        
        // Clear existing options (except first)
        doctorSelect.innerHTML = '<option value="">Select Doctor</option>';
        doctorFilter.innerHTML = '<option value="">All Doctors</option>';
        
        doctors.forEach(doctor => {
            const fullName = `${doctor.first_name} ${doctor.middle_name ? doctor.middle_name + ' ' : ''}${doctor.last_name}`;
            
            // Add to form select
            const option1 = document.createElement('option');
            option1.value = doctor.doctor_id;
            option1.textContent = fullName;
            doctorSelect.appendChild(option1);
            
            // Add to filter select
            const option2 = document.createElement('option');
            option2.value = doctor.doctor_id;
            option2.textContent = fullName;
            doctorFilter.appendChild(option2);
        });
    }

    calculateBMI() {
        const height = parseFloat(document.getElementById('heightCm').value);
        const weight = parseFloat(document.getElementById('weightKg').value);
        
        if (height && weight && height > 0) {
            const heightInMeters = height / 100;
            const bmi = weight / (heightInMeters * heightInMeters);
            document.getElementById('bmi').value = bmi.toFixed(2);
        } else {
            document.getElementById('bmi').value = '';
        }
    }

    handleFileSelection(event) {
        const files = event.target.files;
        const fileNameSpan = document.getElementById('labImagesFileName');
        const uploadedImagesContainer = document.getElementById('uploadedImagesContainer');
        const uploadedImagesGrid = document.getElementById('uploadedImagesGrid');

        if (files.length === 0) {
            fileNameSpan.textContent = 'No files selected';
            uploadedImagesContainer.style.display = 'none';
            return;
        }

        // Validate files
        const maxFiles = 5;
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/pdf'];

        if (files.length > maxFiles) {
            this.showError(`Maximum ${maxFiles} files allowed`);
            event.target.value = '';
            return;
        }

        let validFiles = [];
        for (let file of files) {
            if (!allowedTypes.includes(file.type)) {
                this.showError(`Invalid file type: ${file.name}. Only JPG, PNG, GIF, and PDF files are allowed.`);
                event.target.value = '';
                return;
            }
            if (file.size > maxSize) {
                this.showError(`File too large: ${file.name}. Maximum size is 5MB.`);
                event.target.value = '';
                return;
            }
            validFiles.push(file);
        }

        // Update file name display
        if (validFiles.length === 1) {
            fileNameSpan.textContent = validFiles[0].name;
        } else {
            fileNameSpan.textContent = `${validFiles.length} files selected`;
        }

        // Show preview of selected files
        this.showFilePreview(validFiles);
    }

    showFilePreview(files) {
        const uploadedImagesContainer = document.getElementById('uploadedImagesContainer');
        const uploadedImagesGrid = document.getElementById('uploadedImagesGrid');

        uploadedImagesGrid.innerHTML = '';
        uploadedImagesContainer.style.display = 'block';

        Array.from(files).forEach((file, index) => {
            const column = document.createElement('div');
            column.className = 'column is-3';

            const isPdf = file.type === 'application/pdf';
            const fileUrl = URL.createObjectURL(file);

            column.innerHTML = `
                <div class="card">
                    <div class="card-image">
                        <figure class="image is-4by3">
                            ${isPdf ? 
                                `<div class="has-background-grey-light is-flex is-align-items-center is-justify-content-center" style="height: 100%;">
                                    <span class="icon is-large has-text-grey">
                                        <i class="fas fa-file-pdf fa-2x"></i>
                                    </span>
                                </div>` :
                                `<img src="${fileUrl}" alt="Lab Image ${index + 1}">`
                            }
                        </figure>
                    </div>
                    <div class="card-content">
                        <p class="has-text-centered is-size-7">${file.name}</p>
                        <p class="has-text-centered is-size-7 has-text-grey">${this.formatFileSize(file.size)}</p>
                    </div>
                </div>
            `;

            uploadedImagesGrid.appendChild(column);
        });
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    displayExistingLabImages(labImagesJson) {
        const uploadedImagesContainer = document.getElementById('uploadedImagesContainer');
        const uploadedImagesGrid = document.getElementById('uploadedImagesGrid');
        const fileNameSpan = document.getElementById('labImagesFileName');

        if (!labImagesJson) {
            uploadedImagesContainer.style.display = 'none';
            fileNameSpan.textContent = 'No files selected';
            return;
        }

        try {
            const labImages = JSON.parse(labImagesJson);
            if (labImages.length === 0) {
                uploadedImagesContainer.style.display = 'none';
                fileNameSpan.textContent = 'No files selected';
                return;
            }

            uploadedImagesGrid.innerHTML = '';
            uploadedImagesContainer.style.display = 'block';
            fileNameSpan.textContent = `${labImages.length} existing file(s)`;

            labImages.forEach((image, index) => {
                const column = document.createElement('div');
                column.className = 'column is-3';

                const isPdf = image.file_type === 'application/pdf';
                const imageUrl = `uploads/lab_results/${image.filename}`;

                column.innerHTML = `
                    <div class="card">
                        <div class="card-image">
                            <figure class="image is-4by3">
                                ${isPdf ? 
                                    `<div class="has-background-grey-light is-flex is-align-items-center is-justify-content-center" style="height: 100%;">
                                        <span class="icon is-large has-text-grey">
                                            <i class="fas fa-file-pdf fa-2x"></i>
                                        </span>
                                    </div>` :
                                    `<img src="${imageUrl}" alt="Lab Image ${index + 1}" style="object-fit: cover;">`
                                }
                            </figure>
                        </div>
                        <div class="card-content">
                            <p class="has-text-centered is-size-7">${image.original_name}</p>
                            <p class="has-text-centered is-size-7 has-text-grey">${image.file_size || 'Unknown size'}</p>
                        </div>
                    </div>
                `;

                uploadedImagesGrid.appendChild(column);
            });
        } catch (error) {
            console.error('Error parsing lab images JSON:', error);
            uploadedImagesContainer.style.display = 'none';
            fileNameSpan.textContent = 'No files selected';
        }
    }

    async loadMedicalRecords() {
        this.showLoading();
        
        try {
            const searchTerm = document.getElementById('searchInput').value;
            const patientFilter = document.getElementById('patientFilter').value;
            const doctorFilter = document.getElementById('doctorFilter').value;
            const statusFilter = document.getElementById('statusFilter').value;
            const sortBy = document.getElementById('sortBy').value;
            
            const params = new URLSearchParams({
                page: this.currentPage,
                limit: this.itemsPerPage,
                search: searchTerm,
                patient_id: patientFilter,
                doctor_id: doctorFilter,
                status: statusFilter,
                sort: sortBy
            });

            const response = await fetch(`controllers/MedicalRecordController.php?action=list&${params}`);
            const data = await response.json();

            if (data.success && data.data && Array.isArray(data.data.medical_records)) {
                this.renderMedicalRecords(data.data.medical_records);
                this.renderPagination(data.data.pagination);
                this.hideLoading();
                
                if (data.data.medical_records.length === 0) {
                    this.showEmptyState();
                } else {
                    this.hideEmptyState();
                }
            } else {
                this.showError('Failed to load medical records: ' + data.message);
            }
        } catch (error) {
            console.error('Error loading medical records:', error);
            this.showError('Error loading medical records. Please try again.');
        }
    }

    renderMedicalRecords(records) {
        const grid = document.getElementById('medicalRecordsGrid');
        grid.innerHTML = '';

        records.forEach(record => {
            const recordCard = this.createRecordCard(record);
            grid.appendChild(recordCard);
        });
    }

    createRecordCard(record) {
        const column = document.createElement('div');
        column.className = 'column is-6';

        const statusClass = record.status === 'active' ? 'is-success' : 'is-warning';
        const statusIcon = record.status === 'active' ? 'fa-check-circle' : 'fa-archive';

        // Format record date
        const recordDate = new Date(record.record_date);
        const formattedDate = this.formatDate(record.record_date);

        // Patient name
        const patientName = record.patient_name || 'Unknown Patient';
        const doctorName = record.doctor_name || 'Unknown Doctor';

        // Truncate long text
        const diagnosis = record.diagnosis ? this.truncateText(record.diagnosis, 100) : 'No diagnosis recorded';
        const treatment = record.treatment ? this.truncateText(record.treatment, 100) : 'No treatment recorded';

        column.innerHTML = `
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <span class="icon is-large has-text-primary">
                                <i class="fas fa-notes-medical fa-2x"></i>
                            </span>
                        </div>
                        <div class="media-content">
                            <p class="title is-6">${this.escapeHtml(patientName)}</p>
                            <p class="subtitle is-7">
                                <span class="icon">
                                    <i class="fas fa-user-md"></i>
                                </span>
                                Dr. ${this.escapeHtml(doctorName)}
                            </p>
                            <div class="medical-record-details mb-2">
                                <div class="mb-1">
                                    <span class="icon is-small">
                                        <i class="fas fa-calendar"></i>
                                    </span>
                                    <strong>Date:</strong> ${formattedDate}
                                </div>
                                <div class="mb-1">
                                    <span class="icon is-small">
                                        <i class="fas fa-diagnoses"></i>
                                    </span>
                                    <strong>Diagnosis:</strong> ${this.escapeHtml(diagnosis)}
                                </div>
                                <div class="mb-1">
                                    <span class="icon is-small">
                                        <i class="fas fa-procedures"></i>
                                    </span>
                                    <strong>Treatment:</strong> ${this.escapeHtml(treatment)}
                                </div>
                            </div>
                            <div class="tags">
                                <span class="tag ${statusClass} status-badge">
                                    <span class="icon is-small">
                                        <i class="fas ${statusIcon}"></i>
                                    </span>
                                    <span>${record.status.charAt(0).toUpperCase() + record.status.slice(1)}</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="card-footer">
                    <a class="card-footer-item has-text-primary" onclick="medicalRecordManager.viewRecord(${record.record_id})">
                        <span class="icon">
                            <i class="fas fa-eye"></i>
                        </span>
                        <span>View</span>
                    </a>
                    <a class="card-footer-item has-text-success" onclick="medicalRecordManager.printRecord(${record.record_id})">
                        <span class="icon">
                            <i class="fas fa-print"></i>
                        </span>
                        <span>Print</span>
                    </a>
                    <a class="card-footer-item has-text-info" onclick="medicalRecordManager.editRecord(${record.record_id})">
                        <span class="icon">
                            <i class="fas fa-edit"></i>
                        </span>
                        <span>Edit</span>
                    </a>
                    <a class="card-footer-item has-text-danger" onclick="medicalRecordManager.confirmDelete(${record.record_id}, '${this.escapeHtml(patientName)}')">
                        <span class="icon">
                            <i class="fas fa-trash"></i>
                        </span>
                        <span>Delete</span>
                    </a>
                </footer>
            </div>
        `;

        return column;
    }

    renderPagination(pagination) {
        this.totalPages = pagination.total_pages;
        const paginationContainer = document.getElementById('pagination');
        const paginationList = document.getElementById('paginationList');
        
        if (this.totalPages <= 1) {
            paginationContainer.style.display = 'none';
            return;
        }

        paginationContainer.style.display = 'flex';
        paginationList.innerHTML = '';

        // Update Previous/Next buttons
        document.getElementById('prevPage').classList.toggle('is-disabled', this.currentPage === 1);
        document.getElementById('nextPage').classList.toggle('is-disabled', this.currentPage === this.totalPages);

        // Generate page numbers
        const startPage = Math.max(1, this.currentPage - 2);
        const endPage = Math.min(this.totalPages, this.currentPage + 2);

        for (let i = startPage; i <= endPage; i++) {
            const li = document.createElement('li');
            li.innerHTML = `
                <a class="pagination-link ${i === this.currentPage ? 'is-current' : ''}" 
                   onclick="medicalRecordManager.goToPage(${i})">${i}</a>
            `;
            paginationList.appendChild(li);
        }
    }

    goToPage(page) {
        this.currentPage = page;
        this.loadMedicalRecords();
    }

    openModal(record = null) {
        const modal = document.getElementById('medicalRecordModal');
        const modalTitle = document.getElementById('modalTitle');
        const form = document.getElementById('medicalRecordForm');
        
        // Reset form
        form.reset();
        
        if (record) {
            // Edit mode
            modalTitle.textContent = 'Edit Medical Record';
            document.getElementById('recordId').value = record.record_id;
            document.getElementById('patientId').value = record.patient_id;
            document.getElementById('doctorId').value = record.doctor_id;
            document.getElementById('recordDate').value = record.record_date;
            document.getElementById('status').value = record.status;
            
            // Vital signs
            document.getElementById('heightCm').value = record.height_cm || '';
            document.getElementById('weightKg').value = record.weight_kg || '';
            document.getElementById('bmi').value = record.bmi || '';
            document.getElementById('bloodPressure').value = record.blood_pressure || '';
            document.getElementById('heartRate').value = record.heart_rate || '';
            document.getElementById('temperatureC').value = record.temperature_c || '';
            document.getElementById('respiratoryRate').value = record.respiratory_rate || '';
            
            // SOAP notes
            document.getElementById('subjective').value = record.subjective || '';
            document.getElementById('objective').value = record.objective || '';
            document.getElementById('assessment').value = record.assessment || '';
            document.getElementById('plan').value = record.plan || '';
            
            // Diagnosis and treatment
            document.getElementById('diagnosis').value = record.diagnosis || '';
            document.getElementById('treatment').value = record.treatment || '';
            
            // Handle existing lab images
            this.displayExistingLabImages(record.lab_images);
            
            this.currentRecordId = record.record_id;
        } else {
            // Add mode
            modalTitle.textContent = 'Add New Medical Record';
            document.getElementById('recordId').value = '';
            
            // Set default record date to now
            const now = new Date();
            const formattedDate = now.toISOString().slice(0, 16);
            document.getElementById('recordDate').value = formattedDate;
            
            // Reset file upload
            document.getElementById('labImagesFileName').textContent = 'No files selected';
            document.getElementById('uploadedImagesContainer').style.display = 'none';
            
            this.currentRecordId = null;
        }
        
        modal.classList.add('is-active');
    }

    closeModal() {
        document.getElementById('medicalRecordModal').classList.remove('is-active');
        this.currentRecordId = null;
    }

    async editRecord(recordId) {
        try {
            const response = await fetch(`controllers/MedicalRecordController.php?action=get&id=${recordId}`);
            const data = await response.json();
            
            if (data.success) {
                this.openModal(data.record);
            } else {
                this.showError('Failed to load medical record: ' + data.message);
            }
        } catch (error) {
            console.error('Error loading medical record:', error);
            this.showError('Error loading medical record data.');
        }
    }

    async saveMedicalRecord() {
        const form = document.getElementById('medicalRecordForm');
        const saveButton = document.getElementById('saveMedicalRecord');
        
        // Validate form
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        // Disable button during save
        saveButton.classList.add('is-loading');
        saveButton.disabled = true;

        try {
            const formData = new FormData();
            formData.append('action', this.currentRecordId ? 'update' : 'create');
            
            if (this.currentRecordId) {
                formData.append('record_id', this.currentRecordId);
            }
            
            formData.append('patient_id', document.getElementById('patientId').value);
            formData.append('doctor_id', document.getElementById('doctorId').value);
            formData.append('record_date', document.getElementById('recordDate').value);
            formData.append('status', document.getElementById('status').value);
            
            // Vital signs
            formData.append('height_cm', document.getElementById('heightCm').value);
            formData.append('weight_kg', document.getElementById('weightKg').value);
            formData.append('bmi', document.getElementById('bmi').value);
            formData.append('blood_pressure', document.getElementById('bloodPressure').value);
            formData.append('heart_rate', document.getElementById('heartRate').value);
            formData.append('temperature_c', document.getElementById('temperatureC').value);
            formData.append('respiratory_rate', document.getElementById('respiratoryRate').value);
            
            // SOAP notes
            formData.append('subjective', document.getElementById('subjective').value);
            formData.append('objective', document.getElementById('objective').value);
            formData.append('assessment', document.getElementById('assessment').value);
            formData.append('plan', document.getElementById('plan').value);
            
            // Diagnosis and treatment
            formData.append('diagnosis', document.getElementById('diagnosis').value);
            formData.append('treatment', document.getElementById('treatment').value);

            // Handle lab images
            const labImagesInput = document.getElementById('labImages');
            if (labImagesInput.files.length > 0) {
                for (let i = 0; i < labImagesInput.files.length; i++) {
                    formData.append('lab_images[]', labImagesInput.files[i]);
                }
            }

            const response = await fetch('controllers/MedicalRecordController.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                this.closeModal();
                this.loadMedicalRecords();
                this.showSuccess(this.currentRecordId ? 'Medical record updated successfully!' : 'Medical record created successfully!');
            } else {
                this.showError('Failed to save medical record: ' + data.message);
            }
        } catch (error) {
            console.error('Error saving medical record:', error);
            this.showError('Error saving medical record. Please try again.');
        } finally {
            saveButton.classList.remove('is-loading');
            saveButton.disabled = false;
        }
    }

    confirmDelete(recordId, patientName) {
        this.currentRecordId = recordId;
        document.getElementById('deleteRecordInfo').textContent = `Record for ${patientName}`;
        document.getElementById('deleteModal').classList.add('is-active');
    }

    closeDeleteModal() {
        document.getElementById('deleteModal').classList.remove('is-active');
        this.currentRecordId = null;
    }

    async deleteMedicalRecord() {
        const deleteButton = document.getElementById('confirmDelete');
        
        deleteButton.classList.add('is-loading');
        deleteButton.disabled = true;

        try {
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('record_id', this.currentRecordId);

            const response = await fetch('controllers/MedicalRecordController.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                this.closeDeleteModal();
                this.loadMedicalRecords();
                this.showSuccess('Medical record deleted successfully!');
            } else {
                this.showError('Failed to delete medical record: ' + data.message);
            }
        } catch (error) {
            console.error('Error deleting medical record:', error);
            this.showError('Error deleting medical record. Please try again.');
        } finally {
            deleteButton.classList.remove('is-loading');
            deleteButton.disabled = false;
        }
    }

    async viewRecord(recordId) {
        try {
            const response = await fetch(`controllers/MedicalRecordController.php?action=get&id=${recordId}`);
            const data = await response.json();
            
            if (data.success) {
                this.showRecordDetails(data.record);
            } else {
                this.showError('Failed to load medical record: ' + data.message);
            }
        } catch (error) {
            console.error('Error loading medical record:', error);
            this.showError('Error loading medical record data.');
        }
    }

    showRecordDetails(record) {
        // Fill patient and doctor info
        document.getElementById('viewPatientName').textContent = record.patient_name || 'Unknown Patient';
        document.getElementById('viewDoctorName').textContent = record.doctor_name || 'Unknown Doctor';
        
        // Record date and status
        document.getElementById('viewRecordDate').textContent = this.formatDate(record.record_date);
        document.getElementById('viewStatus').textContent = record.status.charAt(0).toUpperCase() + record.status.slice(1);
        document.getElementById('viewStatus').className = `tag is-large ${record.status === 'active' ? 'is-success' : 'is-warning'}`;
        
        // Vital signs
        document.getElementById('viewHeight').textContent = record.height_cm ? `${record.height_cm} cm` : 'Not recorded';
        document.getElementById('viewWeight').textContent = record.weight_kg ? `${record.weight_kg} kg` : 'Not recorded';
        document.getElementById('viewBmi').textContent = record.bmi ? record.bmi : 'Not calculated';
        document.getElementById('viewBloodPressure').textContent = record.blood_pressure || 'Not recorded';
        document.getElementById('viewHeartRate').textContent = record.heart_rate ? `${record.heart_rate} bpm` : 'Not recorded';
        document.getElementById('viewTemperature').textContent = record.temperature_c ? `${record.temperature_c}°C` : 'Not recorded';
        document.getElementById('viewRespiratoryRate').textContent = record.respiratory_rate ? `${record.respiratory_rate} /min` : 'Not recorded';
        
        // SOAP notes
        document.getElementById('viewSubjective').textContent = record.subjective || 'Not recorded';
        document.getElementById('viewObjective').textContent = record.objective || 'Not recorded';
        document.getElementById('viewAssessment').textContent = record.assessment || 'Not recorded';
        document.getElementById('viewPlan').textContent = record.plan || 'Not recorded';
        
        // Diagnosis and treatment
        document.getElementById('viewDiagnosis').textContent = record.diagnosis || 'Not recorded';
        document.getElementById('viewTreatment').textContent = record.treatment || 'Not recorded';
        
        // Summary info
        document.getElementById('viewRecordId').textContent = record.record_id;
        document.getElementById('viewRecordDateSummary').textContent = this.formatDate(record.record_date);
        document.getElementById('viewCreatedDate').textContent = this.formatDate(record.created_at);
        document.getElementById('viewLastUpdated').textContent = this.formatDate(record.updated_at);
        document.getElementById('viewStatusSummary').textContent = record.status.charAt(0).toUpperCase() + record.status.slice(1);
        document.getElementById('viewStatusSummary').className = `tag is-medium ${record.status === 'active' ? 'is-success' : 'is-warning'}`;
        
        // Display lab images
        this.displayViewLabImages(record.lab_images);
        
        // Show modal
        document.getElementById('viewMedicalRecordModal').classList.add('is-active');
    }

    displayViewLabImages(labImagesJson) {
        const labImagesSection = document.getElementById('viewLabImagesSection');
        const labImagesGrid = document.getElementById('viewLabImagesGrid');

        if (!labImagesJson) {
            labImagesSection.style.display = 'none';
            return;
        }

        try {
            const labImages = JSON.parse(labImagesJson);
            if (labImages.length === 0) {
                labImagesSection.style.display = 'none';
                return;
            }

            labImagesGrid.innerHTML = '';
            labImagesSection.style.display = 'block';

            labImages.forEach((image, index) => {
                const column = document.createElement('div');
                column.className = 'column is-3';

                const isPdf = image.file_type === 'application/pdf';
                const imageUrl = `uploads/lab_results/${image.filename}`;

                column.innerHTML = `
                    <div class="card">
                        <div class="card-image">
                            <figure class="image is-4by3">
                                ${isPdf ? 
                                    `<div class="has-background-grey-light is-flex is-align-items-center is-justify-content-center" style="height: 100%;">
                                        <a href="${imageUrl}" target="_blank" class="has-text-grey">
                                            <span class="icon is-large">
                                                <i class="fas fa-file-pdf fa-2x"></i>
                                            </span>
                                        </a>
                                    </div>` :
                                    `<a href="${imageUrl}" target="_blank">
                                        <img src="${imageUrl}" alt="Lab Image ${index + 1}" style="object-fit: cover;">
                                    </a>`
                                }
                            </figure>
                        </div>
                        <div class="card-content">
                            <p class="has-text-centered is-size-7">${image.original_name}</p>
                            <p class="has-text-centered is-size-7 has-text-grey">${image.file_size || 'Unknown size'}</p>
                            <div class="has-text-centered mt-2">
                                <a href="${imageUrl}" target="_blank" class="button is-small is-primary">
                                    <span class="icon is-small">
                                        <i class="fas fa-external-link-alt"></i>
                                    </span>
                                    <span>View</span>
                                </a>
                            </div>
                        </div>
                    </div>
                `;

                labImagesGrid.appendChild(column);
            });
        } catch (error) {
            console.error('Error parsing lab images JSON:', error);
            labImagesSection.style.display = 'none';
        }
    }

    closeViewModal() {
        document.getElementById('viewMedicalRecordModal').classList.remove('is-active');
    }

    async printRecord(recordId) {
        try {
            const response = await fetch(`controllers/MedicalRecordController.php?action=get&id=${recordId}`);
            const data = await response.json();
            
            if (data.success) {
                this.generatePrintContent(data.record);
                window.print();
            } else {
                this.showError('Failed to load medical record for printing: ' + data.message);
            }
        } catch (error) {
            console.error('Error loading medical record for printing:', error);
            this.showError('Error loading medical record for printing.');
        }
    }

    generatePrintContent(record) {
        const printArea = document.getElementById('medicalRecordPrintArea');
        const currentDate = new Date().toLocaleDateString();
        
        printArea.innerHTML = `
            <div class="print-header">
                <div class="print-title">Hospital Management System</div>
                <div class="print-subtitle">Medical Record Report</div>
            </div>
            
            <div class="print-info">
                <h3>Patient Information</h3>
                <div class="print-info-grid">
                    <div class="print-info-item"><strong>Patient:</strong> ${record.patient_name || 'Unknown'}</div>
                    <div class="print-info-item"><strong>Doctor:</strong> ${record.doctor_name || 'Unknown'}</div>
                    <div class="print-info-item"><strong>Record Date:</strong> ${this.formatDate(record.record_date)}</div>
                    <div class="print-info-item"><strong>Status:</strong> ${record.status.charAt(0).toUpperCase() + record.status.slice(1)}</div>
                </div>
            </div>
            
            <div class="print-medical-records">
                <h3>Vital Signs</h3>
                <div class="print-info-grid">
                    <div class="print-info-item"><strong>Height:</strong> ${record.height_cm ? record.height_cm + ' cm' : 'Not recorded'}</div>
                    <div class="print-info-item"><strong>Weight:</strong> ${record.weight_kg ? record.weight_kg + ' kg' : 'Not recorded'}</div>
                    <div class="print-info-item"><strong>BMI:</strong> ${record.bmi || 'Not calculated'}</div>
                    <div class="print-info-item"><strong>Blood Pressure:</strong> ${record.blood_pressure || 'Not recorded'}</div>
                    <div class="print-info-item"><strong>Heart Rate:</strong> ${record.heart_rate ? record.heart_rate + ' bpm' : 'Not recorded'}</div>
                    <div class="print-info-item"><strong>Temperature:</strong> ${record.temperature_c ? record.temperature_c + '°C' : 'Not recorded'}</div>
                </div>
            </div>
            
            <div class="print-medical-records">
                <h3>SOAP Notes</h3>
                <div class="print-info-item"><strong>Subjective:</strong> ${record.subjective || 'Not recorded'}</div>
                <div class="print-info-item"><strong>Objective:</strong> ${record.objective || 'Not recorded'}</div>
                <div class="print-info-item"><strong>Assessment:</strong> ${record.assessment || 'Not recorded'}</div>
                <div class="print-info-item"><strong>Plan:</strong> ${record.plan || 'Not recorded'}</div>
            </div>
            
            <div class="print-medical-records">
                <h3>Diagnosis & Treatment</h3>
                <div class="print-info-item"><strong>Diagnosis:</strong> ${record.diagnosis || 'Not recorded'}</div>
                <div class="print-info-item"><strong>Treatment:</strong> ${record.treatment || 'Not recorded'}</div>
            </div>
            
            <div class="print-footer">
                <div class="print-footer-content">Generated on: ${currentDate}</div>
                <div class="print-footer-content">Hospital Management System - Medical Records</div>
            </div>
        `;
    }

    clearFilters() {
        document.getElementById('searchInput').value = '';
        document.getElementById('patientFilter').value = '';
        document.getElementById('doctorFilter').value = '';
        document.getElementById('statusFilter').value = '';
        document.getElementById('sortBy').value = 'record_date';
        this.currentPage = 1;
        this.loadMedicalRecords();
    }

    showLoading() {
        document.getElementById('loadingSpinner').style.display = 'block';
        document.getElementById('medicalRecordsContainer').style.display = 'none';
    }

    hideLoading() {
        document.getElementById('loadingSpinner').style.display = 'none';
        document.getElementById('medicalRecordsContainer').style.display = 'block';
    }

    showEmptyState() {
        document.getElementById('emptyState').style.display = 'block';
    }

    hideEmptyState() {
        document.getElementById('emptyState').style.display = 'none';
    }

    showSuccess(message) {
        this.showNotification(message, 'is-success');
    }

    showError(message) {
        this.showNotification(message, 'is-danger');
    }

    showNotification(message, type) {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.notification.floating-notification');
        existingNotifications.forEach(notification => notification.remove());

        // Create new notification
        const notification = document.createElement('div');
        notification.className = `notification ${type} floating-notification`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideInRight 0.3s ease-out;
        `;
        
        notification.innerHTML = `
            <button class="delete"></button>
            ${message}
        `;
        
        document.body.appendChild(notification);

        // Add delete functionality
        notification.querySelector('.delete').addEventListener('click', () => {
            notification.remove();
        });

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    truncateText(text, maxLength) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
}

// Initialize the medical record manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.medicalRecordManager = new MedicalRecordManager();
});

// Add CSS for floating notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .floating-notification {
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
`;
document.head.appendChild(style); 