<?php
// Test script to check inventory withdrawals
require_once 'config/config.php';

echo "<h2>Inventory Withdrawals Debug Test</h2>";
echo "<style>body { font-family: Arial, sans-serif; margin: 20px; }</style>";

// Test 1: Database connection
echo "<h3>1. Database Connection Test</h3>";
if (isset($conn) && $conn) {
    echo "<p>✅ Database connected successfully</p>";
} else {
    echo "<p>❌ Database connection failed</p>";
    exit;
}

// Test 2: Check if withdrawals table exists
echo "<h3>2. Table Existence Test</h3>";
$tables = ['inventory_withdrawals', 'inventory_withdrawal_items', 'inventory_items'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "<p>✅ Table '$table' exists</p>";
    } else {
        echo "<p>❌ Table '$table' missing</p>";
    }
}

// Test 3: Count records
echo "<h3>3. Data Count Test</h3>";
try {
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory_withdrawals");
    $count = $result->fetch_assoc()['count'];
    echo "<p>✅ Found $count withdrawals in database</p>";
    
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory_withdrawal_items");
    $count = $result->fetch_assoc()['count'];
    echo "<p>✅ Found $count withdrawal items in database</p>";
    
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory_items WHERE status = 'active'");
    $count = $result->fetch_assoc()['count'];
    echo "<p>✅ Found $count active inventory items</p>";
    
} catch (Exception $e) {
    echo "<p>❌ Error counting records: " . $e->getMessage() . "</p>";
}

// Test 4: Sample withdrawal data
echo "<h3>4. Sample Withdrawal Data</h3>";
try {
    $sql = "SELECT withdrawal_id, customer_name, withdrawal_date, status, sale_type 
            FROM inventory_withdrawals 
            ORDER BY withdrawal_date DESC 
            LIMIT 5";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr><th>ID</th><th>Customer</th><th>Date</th><th>Status</th><th>Sale Type</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['withdrawal_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['customer_name']) . "</td>";
            echo "<td>" . $row['withdrawal_date'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td>" . $row['sale_type'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ No withdrawal data found</p>";
    }
} catch (Exception $e) {
    echo "<p>❌ Error fetching withdrawals: " . $e->getMessage() . "</p>";
}

// Test 5: Test the API endpoint directly
echo "<h3>5. API Endpoint Test</h3>";
try {
    // Simulate what the JavaScript would do
    $_GET['action'] = 'list';
    $_GET['page'] = 1;
    $_GET['limit'] = 6;
    
    // Capture output from controller
    ob_start();
    include 'controllers/InventoryWithdrawalController.php';
    $output = ob_get_clean();
    
    echo "<p>✅ API endpoint accessible</p>";
    echo "<h4>API Response:</h4>";
    echo "<pre style='background: #f5f5f5; padding: 10px; border: 1px solid #ccc; overflow: auto; max-height: 300px;'>";
    echo htmlspecialchars($output);
    echo "</pre>";
    
} catch (Exception $e) {
    echo "<p>❌ API endpoint error: " . $e->getMessage() . "</p>";
}

// Test 6: JavaScript accessibility test
echo "<h3>6. JavaScript Console Test</h3>";
echo "<p>Open browser console (F12) and run this command:</p>";
echo "<code style='background: #f0f0f0; padding: 5px; display: block; margin: 10px 0;'>";
echo "fetch('controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6').then(r => r.json()).then(console.log)";
echo "</code>";

echo "<h3>7. Quick Links</h3>";
echo "<p><a href='inventory_withdrawals.php' target='_blank'>🔗 Open Inventory Withdrawals Page</a></p>";
echo "<p><a href='controllers/InventoryWithdrawalController.php?action=list&page=1&limit=6' target='_blank'>🔗 Test API Directly</a></p>";

echo "<hr>";
echo "<p><strong>Debug Summary:</strong></p>";
echo "<ul>";
echo "<li>If you see withdrawal data above but the page is empty, it's likely a JavaScript issue.</li>";
echo "<li>Check browser console (F12) for JavaScript errors.</li>";
echo "<li>Test the API link above to see if it returns JSON data.</li>";
echo "<li>Make sure you're logged in to the system.</li>";
echo "</ul>";
?> 