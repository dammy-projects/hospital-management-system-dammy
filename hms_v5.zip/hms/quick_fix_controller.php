<?php
// Quick fix script to check and repair controller issues
require_once 'config/config.php';

echo "<h2>Quick Fix - Controller Issues</h2>";

// Test 1: Check database structure
echo "<h3>1. Database Structure Check</h3>";
try {
    $result = $conn->query("DESCRIBE inventory_withdrawals");
    $columns = [];
    
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    $hasNotes = in_array('notes', $columns);
    $hasDiscountValue = in_array('discount_value', $columns);
    $hasDiscountType = in_array('discount_type', $columns);
    
    echo "<p><strong>Table Columns:</strong> " . implode(', ', $columns) . "</p>";
    
    if ($hasNotes) {
        echo "<p style='color: orange;'>⚠️ Notes column still exists (this might cause issues)</p>";
        echo "<p><a href='remove_notes_column.php' style='background: #dc3545; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Remove Notes Column</a></p>";
    } else {
        echo "<p style='color: green;'>✅ Notes column removed</p>";
    }
    
    if (!$hasDiscountValue || !$hasDiscountType) {
        echo "<p style='color: red;'>❌ Discount fields missing!</p>";
        echo "<p><a href='update_database.php' style='background: #28a745; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Add Discount Fields</a></p>";
    } else {
        echo "<p style='color: green;'>✅ Discount fields present</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}

// Test 2: Test API endpoints
echo "<h3>2. API Endpoint Tests</h3>";

$testResults = [];

// Test inventory-items endpoint
try {
    $_GET['action'] = 'inventory-items';
    ob_start();
    include 'controllers/InventoryWithdrawalController.php';
    $output = ob_get_clean();
    
    $testResults['inventory-items'] = [
        'success' => strpos($output, '"success":true') !== false,
        'output' => $output
    ];
} catch (Exception $e) {
    $testResults['inventory-items'] = [
        'success' => false,
        'output' => 'Error: ' . $e->getMessage()
    ];
}

// Test list endpoint
try {
    $_GET['action'] = 'list';
    ob_start();
    include 'controllers/InventoryWithdrawalController.php';
    $output = ob_get_clean();
    
    $testResults['list'] = [
        'success' => strpos($output, '"success":true') !== false,
        'output' => $output
    ];
} catch (Exception $e) {
    $testResults['list'] = [
        'success' => false,
        'output' => 'Error: ' . $e->getMessage()
    ];
}

foreach ($testResults as $action => $result) {
    $status = $result['success'] ? '✅ Working' : '❌ Failed';
    echo "<p><strong>$action:</strong> $status</p>";
    if (!$result['success']) {
        echo "<details><summary>Show Error</summary><pre>" . htmlspecialchars($result['output']) . "</pre></details>";
    }
}

// Test 3: Check for common issues
echo "<h3>3. Common Issues Check</h3>";

$controllerFile = 'controllers/InventoryWithdrawalController.php';
if (file_exists($controllerFile)) {
    $content = file_get_contents($controllerFile);
    
    // Check for parameter binding issues
    if (strpos($content, "'sssssdidssi'") !== false) {
        echo "<p style='color: red;'>❌ Found old parameter binding with notes - this needs fixing!</p>";
        echo "<p><strong>Solution:</strong> The parameter binding still includes 'notes' field</p>";
    } else {
        echo "<p style='color: green;'>✅ Parameter binding looks correct</p>";
    }
    
    // Check if discount fields are being used
    if (strpos($content, 'discount_value') === false || strpos($content, 'discount_type') === false) {
        echo "<p style='color: orange;'>⚠️ Controller might not be using discount fields</p>";
    } else {
        echo "<p style='color: green;'>✅ Controller includes discount fields</p>";
    }
    
} else {
    echo "<p style='color: red;'>❌ Controller file not found!</p>";
}

// Test 4: Quick database test
echo "<h3>4. Quick Database Operations Test</h3>";
try {
    // Test a simple SELECT
    $testSql = "SELECT COUNT(*) as count FROM inventory_withdrawals";
    $result = $conn->query($testSql);
    $count = $result->fetch_assoc()['count'];
    echo "<p style='color: green;'>✅ Database connection working - Found $count withdrawals</p>";
    
    // Test inventory items
    $testSql2 = "SELECT COUNT(*) as count FROM inventory_items WHERE status = 'active'";
    $result2 = $conn->query($testSql2);
    $count2 = $result2->fetch_assoc()['count'];
    echo "<p style='color: green;'>✅ Found $count2 active inventory items</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database test failed: " . $e->getMessage() . "</p>";
}

echo "<h3>5. Quick Actions</h3>";
echo "<p><a href='test_controller.php' style='background: #007cba; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Run Full Diagnostic</a></p>";
echo "<p><a href='inventory_withdrawals.php' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Try Inventory Withdrawals</a></p>";

$conn->close();
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2, h3 { color: #333; }
details { margin: 10px 0; }
summary { cursor: pointer; background: #f5f5f5; padding: 5px; }
pre { background: #f8f9fa; padding: 10px; border-left: 3px solid #dc3545; }
</style> 