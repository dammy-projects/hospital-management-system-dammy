<?php
require_once 'includes/header.php';
?>

<style>
/* Compact styles for smaller inventory cards */
.inventory-grid .column {
    margin-bottom: 1rem;
    padding: 0.5rem;
}

.inventory-grid .card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    border-radius: 6px;
}

.inventory-grid .card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card-footer-item {
    padding: 0.3rem 0.2rem;
    cursor: pointer;
    transition: background-color 0.2s ease;
    font-size: 0.7rem;
    text-align: center;
    border-right: 1px solid #dbdbdb;
    flex: 1;
    min-width: 0;
}

.card-footer-item:last-child {
    border-right: none;
}

.card-footer-item:hover {
    background-color: #f5f5f5;
}

.card-footer-item .icon {
    margin-right: 0.25rem !important;
}

.card-footer-item span:not(.icon) {
    font-size: 0.65rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Text overflow handling */
.card .title,
.card .subtitle {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* Ensure proper spacing between name and details */
.card .title.is-6 {
    margin-bottom: 0.25rem !important;
}

.card .subtitle.is-7 {
    margin-top: 0 !important;
    margin-bottom: 0.5rem !important;
}

/* Inventory details text handling */
.inventory-details {
    font-size: 0.75rem;
    color: #6c757d;
    line-height: 1.2em;
}

/* Status badge styling */
.status-badge {
    text-transform: capitalize;
}

/* Stock level indicators */
.stock-indicator {
    border-radius: 50%;
    width: 10px;
    height: 10px;
    display: inline-block;
    margin-right: 5px;
}

.stock-good { background-color: #48c774; }
.stock-low { background-color: #ffdd57; }
.stock-out { background-color: #f14668; }

/* Mobile responsiveness for smaller cards */
@media (max-width: 768px) {
    .inventory-grid .column {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media (min-width: 769px) and (max-width: 1023px) {
    .inventory-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (min-width: 1024px) and (max-width: 1215px) {
    .inventory-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (min-width: 1216px) {
    .inventory-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

/* View Modal Styling */
#viewInventoryModal .modal-card {
    width: 90vw;
    max-width: 1200px;
    max-height: 90vh;
    margin: auto;
}

#viewInventoryModal .modal-card-body {
    max-height: 70vh;
    overflow-y: auto;
    padding: 1.5rem;
}

#viewInventoryModal .field {
    margin-bottom: 1rem;
}

#viewInventoryModal .label {
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #363636;
}

#viewInventoryModal .box {
    padding: 1rem;
    margin-bottom: 0;
    min-height: 2.5rem;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

#viewInventoryModal .tag.is-large {
    font-size: 1rem;
    padding: 0.5rem 0.75rem;
    height: auto;
    white-space: nowrap;
}

#viewInventoryModal .subtitle {
    margin-bottom: 1rem !important;
    border-bottom: 1px solid #dbdbdb;
    padding-bottom: 0.5rem;
}

#viewInventoryModal .column {
    padding: 0.5rem;
}

#viewInventoryModal p {
    word-wrap: break-word;
    overflow-wrap: break-word;
    line-height: 1.5;
}

/* Responsive adjustments for view modal */
@media (max-width: 768px) {
    #viewInventoryModal .modal-card {
        width: 95vw;
        margin: 1rem auto;
    }
    
    #viewInventoryModal .columns {
        display: block;
    }
    
    #viewInventoryModal .column {
        width: 100% !important;
        flex: none !important;
    }
    
    #viewInventoryModal .card {
        margin-top: 1rem;
    }
}

/* Print Styles - Optimized for Bond Paper */
@media print {
    body * {
        visibility: hidden;
    }
    
    #inventoryPrintArea,
    #inventoryPrintArea * {
        visibility: visible;
    }
    
    #inventoryPrintArea {
        position: absolute;
        left: 0;
        top: 0;
        width: 100% !important;
        padding: 10px;
        font-family: Arial, sans-serif;
        display: block !important;
        visibility: visible !important;
        font-size: 12px;
        line-height: 1.3;
        page-break-inside: avoid;
        max-height: 100vh;
        overflow: hidden;
    }
    
    .print-header {
        text-align: center;
        border-bottom: 2px solid #000;
        padding-bottom: 6px;
        margin-bottom: 8px;
        page-break-inside: avoid;
    }
    
    .print-title {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 3px;
    }
    
    .print-subtitle {
        font-size: 13px;
        color: #666;
        margin: 0;
    }
    
    .print-info {
        margin-bottom: 8px;
        border: 1px solid #000;
        padding: 6px;
        page-break-inside: avoid;
    }
    
    .print-info h3 {
        margin: 0 0 4px 0 !important;
        font-size: 13px;
        border-bottom: 1px solid #ccc;
        padding-bottom: 3px;
        font-weight: bold;
    }
    
    .print-info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px;
        font-size: 11px;
        margin-bottom: 4px;
    }
    
    .print-inventory {
        margin-bottom: 8px;
        page-break-inside: avoid;
    }
    
    .print-inventory h3 {
        margin: 0 0 5px 0 !important;
        font-size: 13px;
        background-color: #f0f0f0;
        padding: 4px 6px;
        border: 1px solid #000;
        page-break-after: avoid;
        font-weight: bold;
    }
    
    .print-info-item {
        padding: 2px 4px;
        border-bottom: 1px solid #eee;
        line-height: 1.2;
    }
    
    .print-footer {
        margin-top: 8px;
        border-top: 1px solid #000;
        padding-top: 4px;
        text-align: center;
        font-size: 9px;
        line-height: 1.3;
        page-break-inside: avoid;
    }
    
    .print-footer-content {
        margin-bottom: 2px;
    }
    
    /* Optimize for bond paper */
    @page {
        margin: 0.4in;
        size: letter;
    }
    
    /* Prevent page breaks within sections */
    .print-inventory,
    .print-info,
    .print-header,
    .print-footer {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
    }
    
    /* Better spacing */
    h1, h2, h3, h4, h5, h6 {
        page-break-after: avoid;
        margin-top: 0 !important;
        margin-bottom: 4px !important;
    }
    
    p, div {
        margin: 0 !important;
    }
    
    /* Ensure content fits properly */
    * {
        max-width: 100% !important;
        box-sizing: border-box;
    }
    
    /* Hide elements that shouldn't be printed */
    .navbar, .tabs, .search-controls, .pagination-controls, 
    .button, .modal, .loading-overlay, .card-footer {
        display: none !important;
    }
}

/* Responsive button text */
@media (max-width: 1215px) {
    .card-footer-item span:not(.icon) {
        display: none;
    }
    
    .card-footer-item {
        padding: 0.4rem 0.2rem;
    }
}

@media (min-width: 1216px) {
    .card-footer-item span:not(.icon) {
        display: inline;
    }
}
</style>

<div class="page-transition mt-4">
    <!-- Page Header -->
    <div class="columns is-vcentered mb-4">
        <div class="column">
            <h1 class="title is-3">
                <span class="icon">
                    <i class="fas fa-boxes"></i>
                </span>
                Inventory Management
            </h1>
            <p class="subtitle">Manage hospital inventory items and stock levels</p>
        </div>
        <div class="column is-narrow">
            <button class="button is-primary" id="addInventoryBtn">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>Add New Item</span>
            </button>
        </div>
    </div>

    <!-- Search and Filter Section -->
    <div class="card mb-4">
        <div class="card-content">
            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Search Items</label>
                        <div class="control has-icons-left">
                            <input class="input" type="text" id="searchInput" placeholder="Search by name, description, serial..." />
                            <span class="icon is-small is-left">
                                <i class="fas fa-search"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Filter by Category</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="categoryFilter">
                                    <option value="">All Categories</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Filter by Status</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="statusFilter">
                                    <option value="">All Status</option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                    <option value="discontinued">Discontinued</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Filter by Stock</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="stockFilter">
                                    <option value="">All Items</option>
                                    <option value="low">Low Stock</option>
                                    <option value="out">Out of Stock</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Sort By</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="sortBy">
                                    <option value="item_name">Item Name</option>
                                    <option value="category_name">Category</option>
                                    <option value="quantity_in_stock">Stock Level</option>
                                    <option value="last_updated">Last Updated</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="columns mt-3">
                <div class="column is-2">
                    <div class="field">
                        <label class="label">&nbsp;</label>
                        <div class="control">
                            <button class="button is-info is-fullwidth" id="clearFilters">
                                <span class="icon">
                                    <i class="fas fa-redo"></i>
                                </span>
                                <span>Reset</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Inventory Grid -->
    <div id="inventoryContainer">
        <div class="columns is-multiline inventory-grid" id="inventoryGrid">
            <!-- Inventory items will be loaded here -->
        </div>
    </div>

    <!-- Loading Spinner -->
    <div class="has-text-centered mt-6 mb-6" id="loadingSpinner" style="display: none;">
        <span class="icon is-large">
            <i class="fas fa-spinner fa-pulse fa-2x"></i>
        </span>
        <p class="mt-2">Loading inventory...</p>
    </div>

    <!-- Empty State -->
    <div class="has-text-centered mt-6 mb-6" id="emptyState" style="display: none;">
        <span class="icon is-large has-text-grey-light">
            <i class="fas fa-boxes fa-3x"></i>
        </span>
        <p class="title is-5 has-text-grey mt-3">No inventory items found</p>
        <p class="subtitle is-6 has-text-grey">Try adjusting your search criteria or add a new item</p>
    </div>

    <!-- Pagination -->
    <nav class="pagination is-centered mt-5" role="navigation" aria-label="pagination" id="pagination" style="display: none;">
        <a class="pagination-previous" id="prevPage">Previous</a>
        <a class="pagination-next" id="nextPage">Next page</a>
        <ul class="pagination-list" id="paginationList">
            <!-- Pagination buttons will be generated here -->
        </ul>
    </nav>
</div>

<!-- Add/Edit Inventory Modal -->
<div class="modal" id="inventoryModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title" id="modalTitle">Add New Item</p>
            <button class="delete" aria-label="close" id="closeModal"></button>
        </header>
        <section class="modal-card-body">
            <form id="inventoryForm">
                <input type="hidden" id="itemId" />
                
                <div class="columns">
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Item Name *</label>
                            <div class="control">
                                <input class="input" type="text" id="itemName" placeholder="Enter item name" required />
                            </div>
                        </div>
                    </div>
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Category *</label>
                            <div class="control">
                                <div class="select is-fullwidth">
                                    <select id="categoryId" required>
                                        <option value="">Select Category</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="field">
                    <label class="label">Description</label>
                    <div class="control">
                        <textarea class="textarea" id="itemDescription" placeholder="Enter item description" rows="3"></textarea>
                    </div>
                </div>

                <div class="columns">
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Serial Number</label>
                            <div class="control">
                                <input class="input" type="text" id="serialNumber" placeholder="Enter serial number" />
                            </div>
                        </div>
                    </div>
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Product Number</label>
                            <div class="control">
                                <input class="input" type="text" id="productNumber" placeholder="Enter product number" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="columns">
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Quantity in Stock</label>
                            <div class="control">
                                <input class="input" type="number" id="quantityInStock" placeholder="0" min="0" required />
                            </div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Unit</label>
                            <div class="control">
                                <input class="input" type="text" id="unit" placeholder="e.g., pieces, bottles, boxes" />
                            </div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Price (₱) *</label>
                            <div class="control">
                                <input class="input" type="number" id="price" placeholder="0.00" min="0" step="0.01" required />
                            </div>
                            <p class="help">Price per unit in Philippine Peso</p>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Reorder Level</label>
                            <div class="control">
                                <input class="input" type="number" id="reorderLevel" placeholder="0" min="0" />
                            </div>
                            <p class="help">Alert when stock falls below this level</p>
                        </div>
                    </div>
                </div>

                <div class="field">
                    <label class="label">Status *</label>
                    <div class="control">
                        <div class="select is-fullwidth">
                            <select id="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="discontinued">Discontinued</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </section>
        <footer class="modal-card-foot">
            <button class="button is-success" id="saveInventory">Save Item</button>
            <button class="button" id="cancelModal">Cancel</button>
        </footer>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal" id="deleteModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Confirm Delete</p>
            <button class="delete" aria-label="close" id="closeDeleteModal"></button>
        </header>
        <section class="modal-card-body">
            <div class="content">
                <p>Are you sure you want to delete this inventory item?</p>
                <p><strong id="deleteItemInfo"></strong></p>
                <p class="has-text-danger">This action cannot be undone and may affect related records.</p>
            </div>
        </section>
        <footer class="modal-card-foot">
            <button class="button is-danger" id="confirmDelete">Delete Item</button>
            <button class="button" id="cancelDelete">Cancel</button>
        </footer>
    </div>
</div>

<!-- View Inventory Details Modal -->
<div class="modal" id="viewInventoryModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">
                <span class="icon">
                    <i class="fas fa-boxes"></i>
                </span>
                Inventory Item Details
            </p>
            <button class="delete" aria-label="close" id="closeViewModal"></button>
        </header>
        <section class="modal-card-body">
            <div class="columns">
                <div class="column is-9">
                    <!-- Inventory Information -->
                    <div class="content">
                        <!-- Item Header with Key Info -->
                        <div class="box mb-4">
                            <div class="level">
                                <div class="level-left">
                                    <div class="level-item">
                                        <div>
                                            <p class="title is-4" id="viewItemName"></p>
                                            <p class="subtitle is-6">
                                                <span class="icon">
                                                    <i class="fas fa-tag"></i>
                                                </span>
                                                Category: <strong id="viewCategoryName"></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="level-right">
                                    <div class="level-item">
                                        <div class="tags has-addons">
                                            <span class="tag is-large" id="viewPrice"></span>
                                            <span class="tag is-large" id="viewStatus"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Item Details Section -->
                        <div class="mb-5">
                            <h4 class="subtitle is-5">
                                <span class="icon">
                                    <i class="fas fa-info-circle"></i>
                                </span>
                                Item Information
                            </h4>
                            <div class="columns">
                                <div class="column is-6">
                                    <div class="field">
                                        <label class="label">Description</label>
                                        <div class="box" id="viewDescription">
                                            <!-- Description content -->
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-6">
                                    <div class="field">
                                        <label class="label">Serial Number</label>
                                        <div class="content">
                                            <p id="viewSerialNumber"></p>
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Product Number</label>
                                        <div class="content">
                                            <p id="viewProductNumber"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Stock Information Section -->
                        <div class="mb-5">
                            <h4 class="subtitle is-5">
                                <span class="icon">
                                    <i class="fas fa-warehouse"></i>
                                </span>
                                Stock Information
                            </h4>
                            <div class="columns">
                                <div class="column is-3">
                                    <div class="field">
                                        <label class="label">Current Stock</label>
                                        <div class="content">
                                            <p id="viewQuantityStock"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-3">
                                    <div class="field">
                                        <label class="label">Unit</label>
                                        <div class="content">
                                            <p id="viewUnit"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-3">
                                    <div class="field">
                                        <label class="label">Reorder Level</label>
                                        <div class="content">
                                            <p id="viewReorderLevel"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="column is-3">
                                    <div class="field">
                                        <label class="label">Stock Status</label>
                                        <div class="content">
                                            <span class="tag" id="viewStockStatus"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="column is-3">
                    <!-- Inventory Summary Card -->
                    <div class="card">
                        <div class="card-header">
                            <p class="card-header-title">
                                <span class="icon">
                                    <i class="fas fa-info-circle"></i>
                                </span>
                                Summary
                            </p>
                        </div>
                        <div class="card-content">
                            <div class="content">
                                <div class="field">
                                    <label class="label is-small">Item ID</label>
                                    <p id="viewItemId"></p>
                                </div>
                                <hr>
                                <div class="field">
                                    <label class="label is-small">Price per Unit</label>
                                    <p id="viewPriceSummary"></p>
                                </div>
                                <div class="field">
                                    <label class="label is-small">Total Value</label>
                                    <p id="viewTotalValue"></p>
                                </div>
                                <div class="field">
                                    <label class="label is-small">Last Updated</label>
                                    <p id="viewLastUpdated"></p>
                                </div>
                                <div class="field">
                                    <label class="label is-small">Status</label>
                                    <div class="content">
                                        <span class="tag is-medium" id="viewStatusSummary"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="modal-card-foot">
            <button class="button" id="closeViewInventory">
                <span class="icon">
                    <i class="fas fa-times"></i>
                </span>
                <span>Close</span>
            </button>
        </footer>
    </div>
</div>

<!-- Hidden Print Area for Inventory Info -->
<div id="inventoryPrintArea" style="display: none;">
    <!-- Inventory print content will be generated here -->
</div>

<!-- JavaScript -->
<script src="js/inventory.js?v=<?php echo time(); ?>"></script>

</div> <!-- End of container from header.php --> 