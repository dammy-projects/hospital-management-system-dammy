<?php
// Database update script for discount fields
require_once 'config/config.php';

echo "<h2>Database Update Script - Adding Discount Fields</h2>";

try {
    // Check if discount fields already exist
    $checkQuery = "SHOW COLUMNS FROM inventory_withdrawals LIKE 'discount_value'";
    $result = $conn->query($checkQuery);
    
    if ($result->num_rows > 0) {
        echo "<p style='color: green;'>✅ Discount fields already exist in the database!</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ Discount fields not found. Adding them now...</p>";
        
        // Add discount_value column
        $sql1 = "ALTER TABLE inventory_withdrawals 
                 ADD COLUMN discount_value DECIMAL(10,2) DEFAULT 0.00 AFTER amount_paid";
        
        if ($conn->query($sql1) === TRUE) {
            echo "<p style='color: green;'>✅ Added discount_value column</p>";
        } else {
            echo "<p style='color: red;'>❌ Error adding discount_value: " . $conn->error . "</p>";
        }
        
        // Add discount_type column
        $sql2 = "ALTER TABLE inventory_withdrawals 
                 ADD COLUMN discount_type ENUM('percentage','fixed') DEFAULT 'percentage' AFTER discount_value";
        
        if ($conn->query($sql2) === TRUE) {
            echo "<p style='color: green;'>✅ Added discount_type column</p>";
        } else {
            echo "<p style='color: red;'>❌ Error adding discount_type: " . $conn->error . "</p>";
        }
    }
    
    // Show current table structure
    echo "<h3>Current inventory_withdrawals table structure:</h3>";
    $structureQuery = "DESCRIBE inventory_withdrawals";
    $structureResult = $conn->query($structureQuery);
    
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $structureResult->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p style='color: green; font-weight: bold;'>🎉 Database update completed successfully!</p>";
    echo "<p>You can now go back to the <a href='inventory_withdrawals.php'>Inventory Withdrawals</a> page and try creating a new withdrawal.</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

$conn->close();
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2 { color: #333; }
table { width: 100%; max-width: 800px; }
th { background-color: #f0f0f0; padding: 8px; }
td { padding: 5px; border: 1px solid #ccc; }
</style> 