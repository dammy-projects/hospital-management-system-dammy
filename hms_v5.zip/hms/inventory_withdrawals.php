<?php
require_once 'includes/header.php';
?>

<style>
/* Compact styles for smaller withdrawal cards */
.withdrawals-grid .column {
    margin-bottom: 1rem;
    padding: 0.5rem;
}

.withdrawals-grid .card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    border-radius: 6px;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.withdrawals-grid .card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card-footer-item {
    padding: 0.3rem 0.2rem;
    cursor: pointer;
    transition: background-color 0.2s ease;
    font-size: 0.7rem;
    text-align: center;
    border-right: 1px solid #dbdbdb;
    flex: 1;
    min-width: 0;
}

.card-footer-item:last-child {
    border-right: none;
}

.card-footer-item:hover {
    background-color: #f5f5f5;
}

.card-footer-item .icon {
    margin-right: 0.25rem !important;
}

.card-footer-item span:not(.icon) {
    font-size: 0.65rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Text overflow handling */
.card .title,
.card .subtitle {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.card .title.is-6 {
    margin-bottom: 0.25rem !important;
}

.card .subtitle.is-7 {
    margin-top: 0 !important;
    margin-bottom: 0.5rem !important;
}

/* Withdrawal details text handling */
.withdrawal-details {
    font-size: 0.75rem;
    color: #6c757d;
    line-height: 1.2em;
}

/* Status badge styling */
.status-badge {
    font-size: 0.65rem;
    padding: 0.15rem 0.4rem;
    border-radius: 8px;
    font-weight: 600;
    text-transform: uppercase;
}

/* Payment status badge styling */
.payment-status-badge {
    font-size: 0.65rem;
    padding: 0.15rem 0.4rem;
    border-radius: 8px;
    font-weight: 600;
    text-transform: uppercase;
}

/* Mobile responsiveness for smaller cards */
@media (max-width: 768px) {
    .withdrawals-grid .column {
        flex: 0 0 100%;
        max-width: 100%;
    }
    
    .card-footer-item span:not(.icon) {
        display: none;
    }
    
    .card-footer-item {
        padding: 0.4rem 0.2rem;
    }
}

@media (min-width: 769px) and (max-width: 1023px) {
    .withdrawals-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (min-width: 1024px) and (max-width: 1215px) {
    .withdrawals-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (min-width: 1216px) {
    .withdrawals-grid .column {
        flex: 0 0 50%;
        max-width: 50%;
    }
    
    .card-footer-item span:not(.icon) {
        display: inline;
    }
}

/* Items entry styling */
.item-entry {
    border: 1px solid #dbdbdb;
    border-radius: 6px;
    padding: 1rem;
    margin-bottom: 1rem;
    background-color: #fafafa;
    position: relative;
}

.remove-item-btn {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background: none;
    border: none;
    color: #ff3860;
    cursor: pointer;
    font-size: 1.2rem;
    padding: 0.25rem;
    border-radius: 50%;
    width: 2rem;
    height: 2rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

.remove-item-btn:hover {
    background-color: rgba(255, 56, 96, 0.1);
}

/* View Modal Styling */
#viewWithdrawalModal .modal-card {
    width: 90vw;
    max-width: 1200px;
    max-height: 90vh;
    margin: auto;
}

#viewWithdrawalModal .modal-card-body {
    max-height: 70vh;
    overflow-y: auto;
    padding: 1.5rem;
}

#viewWithdrawalModal .field {
    margin-bottom: 1rem;
}

#viewWithdrawalModal .label {
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #363636;
}

#viewWithdrawalModal .box {
    padding: 1rem;
    margin-bottom: 0;
    min-height: 2.5rem;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

#viewWithdrawalModal .subtitle {
    margin-bottom: 1rem !important;
    border-bottom: 1px solid #dbdbdb;
    padding-bottom: 0.5rem;
}

#viewWithdrawalModal .column {
    padding: 0.5rem;
}

/* Withdrawal Modal Styling */
#withdrawalModal .modal-card {
    width: 95vw;
    max-width: 1400px;
    max-height: 95vh;
    margin: auto;
}

#withdrawalModal .modal-card-body {
    max-height: 80vh;
    overflow-y: auto;
    padding: 2rem;
}

#withdrawalModal .field {
    margin-bottom: 1.5rem;
}

#withdrawalModal .label {
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #363636;
}

#withdrawalModal .select {
    width: 100%;
}

#withdrawalModal .select select {
    width: 100%;
    max-width: none;
}

#withdrawalModal .item-entry {
    border: 1px solid #dbdbdb;
    border-radius: 6px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    background-color: #fafafa;
    position: relative;
}

#withdrawalModal .remove-item-btn {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background: none;
    border: none;
    color: #ff3860;
    cursor: pointer;
    font-size: 1.2rem;
    padding: 0.25rem;
    border-radius: 50%;
    width: 2rem;
    height: 2rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

#withdrawalModal .remove-item-btn:hover {
    background-color: rgba(255, 56, 96, 0.1);
}

/* Ensure dropdowns are visible */
#withdrawalModal .select:not(.is-multiple):not(.is-loading)::after {
    border-color: #3273dc;
    right: 1.125em;
    z-index: 4;
    height: 0.625em;
    width: 0.625em;
    margin-top: -0.4375em;
    pointer-events: none;
}

#withdrawalModal .select select {
    cursor: pointer;
    display: block;
    font-size: 1em;
    max-width: 100%;
    outline: none;
    padding-right: 2.5em;
}

#withdrawalModal .select select:focus {
    border-color: #3273dc;
    box-shadow: 0 0 0 0.125em rgba(50, 115, 220, 0.25);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    #withdrawalModal .modal-card {
        width: 98vw;
        margin: 1vw;
    }
    
    #withdrawalModal .modal-card-body {
        padding: 1rem;
    }
    
    #withdrawalModal .columns {
        margin-left: -0.5rem;
        margin-right: -0.5rem;
    }
    
    #withdrawalModal .column {
        padding: 0.5rem;
    }
}

/* Items table styling */
.items-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

.items-table th,
.items-table td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #dbdbdb;
}

.items-table th {
    background-color: #f5f5f5;
    font-weight: 600;
}

/* Print styles */
@media print {
    body * {
        visibility: hidden;
    }
    
    #withdrawalPrintArea,
    #withdrawalPrintArea * {
        visibility: visible;
    }
    
    #withdrawalPrintArea {
        position: absolute;
        left: 0;
        top: 0;
        width: 100% !important;
        padding: 15px;
        font-family: Arial, sans-serif;
        display: block !important;
        visibility: visible !important;
        font-size: 12px;
        line-height: 1.4;
    }
    
    .print-header {
        text-align: center;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
        margin-bottom: 15px;
    }
    
    .print-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 5px;
    }
    
    .print-subtitle {
        font-size: 14px;
        color: #666;
        margin: 0;
    }
    
    .print-section {
        margin-bottom: 15px;
        border: 1px solid #000;
        padding: 10px;
    }
    
    .print-section h3 {
        margin: 0 0 10px 0 !important;
        font-size: 14px;
        border-bottom: 1px solid #ccc;
        padding-bottom: 5px;
    }
    
    .print-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-bottom: 10px;
    }
    
    .print-items-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }
    
    .print-items-table th,
    .print-items-table td {
        border: 1px solid #000;
        padding: 5px;
        text-align: left;
        font-size: 11px;
    }
    
    .print-items-table th {
        background-color: #f0f0f0;
        font-weight: bold;
    }
    
    .print-footer {
        margin-top: 20px;
        text-align: center;
        font-size: 10px;
        border-top: 1px solid #000;
        padding-top: 10px;
    }
}
</style>

<div class="page-transition mt-4">
    <!-- Page Header -->
    <div class="columns is-vcentered mb-4">
        <div class="column">
            <h1 class="title is-3">
                <span class="icon">
                    <i class="fas fa-box-open"></i>
                </span>
                Inventory Withdrawals
            </h1>
            <p class="subtitle">Manage inventory withdrawals and customer transactions</p>
        </div>
        <div class="column is-narrow">
            <button class="button is-primary" id="addWithdrawalBtn">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>New Withdrawal</span>
            </button>
        </div>
    </div>

    <!-- Search and Filter Section -->
    <div class="card mb-4">
        <div class="card-content">
            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Search Withdrawals</label>
                        <div class="control has-icons-left">
                            <input class="input" type="text" id="searchInput" placeholder="Search by customer, notes..." />
                            <span class="icon is-small is-left">
                                <i class="fas fa-search"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Filter by Status</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="statusFilter">
                                    <option value="">All Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="approved">Approved</option>
                                    <option value="completed">Completed</option>
                                    <option value="cancelled">Cancelled</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Filter by Sale Type</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="saleTypeFilter">
                                    <option value="">All Types</option>
                                    <option value="retail">Retail</option>
                                    <option value="wholesale">Wholesale</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Sort By</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="sortBy">
                                    <option value="withdrawal_date">Date</option>
                                    <option value="customer_name">Customer Name</option>
                                    <option value="amount_due">Amount Due</option>
                                    <option value="status">Status</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">&nbsp;</label>
                        <div class="control">
                            <button class="button is-info is-fullwidth" id="clearFilters">
                                <span class="icon">
                                    <i class="fas fa-redo"></i>
                                </span>
                                <span>Reset</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Date Range Filter Row -->
            <div class="columns">
                <div class="column is-3">
                    <div class="field">
                        <label class="label">From Date</label>
                        <div class="control has-icons-left">
                            <input class="input" type="date" id="startDate" />
                            <span class="icon is-small is-left">
                                <i class="fas fa-calendar-alt"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="column is-3">
                    <div class="field">
                        <label class="label">To Date</label>
                        <div class="control has-icons-left">
                            <input class="input" type="date" id="endDate" />
                            <span class="icon is-small is-left">
                                <i class="fas fa-calendar-alt"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">Quick Filters</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="quickDateFilter">
                                    <option value="">All Time</option>
                                    <option value="today">Today</option>
                                    <option value="yesterday">Yesterday</option>
                                    <option value="this_week">This Week</option>
                                    <option value="last_week">Last Week</option>
                                    <option value="this_month">This Month</option>
                                    <option value="last_month">Last Month</option>
                                    <option value="this_year">This Year</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">&nbsp;</label>
                        <div class="control">
                            <button class="button is-success is-fullwidth" id="applyDateFilter">
                                <span class="icon">
                                    <i class="fas fa-filter"></i>
                                </span>
                                <span>Apply Filter</span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="column is-2">
                    <div class="field">
                        <label class="label">&nbsp;</label>
                        <div class="control">
                            <button class="button is-light is-fullwidth" id="clearDateFilter">
                                <span class="icon">
                                    <i class="fas fa-times"></i>
                                </span>
                                <span>Clear Dates</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Print and Export Row -->
            <div class="columns">
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Print & Export</label>
                        <div class="field is-grouped">
                            <div class="control">
                                <button class="button is-primary" id="printFilteredReport">
                                    <span class="icon">
                                        <i class="fas fa-print"></i>
                                    </span>
                                    <span>Print Filtered Report</span>
                                </button>
                            </div>
                            <div class="control">
                                <button class="button is-info" id="printSummary">
                                    <span class="icon">
                                        <i class="fas fa-chart-bar"></i>
                                    </span>
                                    <span>Print Summary</span>
                                </button>
                            </div>
                            <div class="control">
                                <button class="button is-link" id="printDetailedReport">
                                    <span class="icon">
                                        <i class="fas fa-file-alt"></i>
                                    </span>
                                    <span>Print Detailed Report</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-6">
                    <div class="field">
                        <label class="label">Report Info</label>
                        <div class="content">
                            <p class="is-size-7">
                                <span id="reportInfo">Showing all withdrawals</span>
                                <br>
                                <span id="recordCount" class="has-text-weight-bold">Total: 0 records</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Withdrawals Grid -->
    <div id="withdrawalsContainer">
        <div class="columns is-multiline withdrawals-grid" id="withdrawalsGrid">
            <!-- Withdrawals will be loaded here -->
        </div>
    </div>

    <!-- Loading Spinner -->
    <div class="has-text-centered mt-6 mb-6" id="loadingSpinner" style="display: none;">
        <span class="icon is-large">
            <i class="fas fa-spinner fa-pulse fa-2x"></i>
        </span>
        <p class="mt-2">Loading withdrawals...</p>
    </div>

    <!-- Empty State -->
    <div class="has-text-centered mt-6 mb-6" id="emptyState" style="display: none;">
        <span class="icon is-large has-text-grey-light">
            <i class="fas fa-box-open fa-3x"></i>
        </span>
        <p class="title is-5 has-text-grey mt-3">No withdrawals found</p>
        <p class="subtitle is-6 has-text-grey">Try adjusting your search criteria or create a new withdrawal</p>
    </div>

    <!-- Pagination -->
    <nav class="pagination is-centered mt-5" role="navigation" aria-label="pagination" id="pagination" style="display: none;">
        <a class="pagination-previous" id="prevPage">Previous</a>
        <a class="pagination-next" id="nextPage">Next page</a>
        <ul class="pagination-list" id="paginationList">
            <!-- Pagination buttons will be generated here -->
        </ul>
    </nav>
</div>

<!-- Add/Edit Withdrawal Modal -->
<div class="modal" id="withdrawalModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title" id="modalTitle">New Withdrawal</p>
            <button class="delete" aria-label="close" id="closeModal"></button>
        </header>
        <section class="modal-card-body">
            <form id="withdrawalForm">
                <input type="hidden" id="withdrawalId" />
                
                <!-- Customer Information -->
                <div class="columns">
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Customer Name *</label>
                            <div class="control">
                                <input class="input" type="text" id="customerName" placeholder="Enter customer name" required />
                            </div>
                        </div>
                    </div>
                    <div class="column is-3">
                        <div class="field">
                            <label class="label">Sale Type *</label>
                            <div class="control">
                                <div class="select is-fullwidth">
                                    <select id="saleType" required>
                                        <option value="retail">Retail</option>
                                        <option value="wholesale">Wholesale</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Status dropdown removed -->
                </div>

                <!-- Withdrawal Details -->
                <div class="columns">
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Withdrawal Date *</label>
                            <div class="control">
                                <input class="input" type="datetime-local" id="withdrawalDate" required />
                            </div>
                        </div>
                    </div>
                    <div class="column is-6">
                        <div class="field">
                            <label class="label">Payment Status</label>
                            <div class="control">
                                <div class="select is-fullwidth">
                                    <select id="paymentStatus">
                                        <option value="unpaid">Unpaid</option>
                                        <option value="partial">Partial</option>
                                        <option value="paid">Paid</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Payment Information -->
                <div class="box has-background-light">
                    <h4 class="title is-6 has-text-primary">
                        <span class="icon">
                            <i class="fas fa-calculator"></i>
                        </span>
                        Payment Calculation
                    </h4>
                    
                    <!-- Calculation Display -->
                    <div class="columns">
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Subtotal (₱)</label>
                                <div class="control">
                                    <input class="input" type="text" id="subtotal" value="₱0.00" readonly />
                                </div>
                                <p class="help">Auto-calculated from items</p>
                            </div>
                        </div>
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Discount</label>
                                <div class="field has-addons">
                                    <div class="control is-expanded">
                                        <input class="input" type="number" id="discountValue" placeholder="0" step="0.01" min="0" />
                                    </div>
                                    <div class="control">
                                        <div class="select">
                                            <select id="discountType">
                                                <option value="percentage">%</option>
                                                <option value="fixed">₱</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <p class="help">Enter discount amount or percentage</p>
                            </div>
                        </div>
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Discount Amount (₱)</label>
                                <div class="control">
                                    <input class="input has-text-weight-bold has-text-danger" type="text" id="discountAmount" value="-₱0.00" readonly />
                                </div>
                                <p class="help">Calculated discount</p>
                            </div>
                        </div>
                    </div>

                    <!-- Final Amount -->
                    <div class="columns">
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Total Amount Due (₱)</label>
                                <div class="control">
                                    <input class="input is-large has-text-weight-bold has-text-primary" type="text" id="totalAmountDue" value="₱0.00" readonly />
                                </div>
                                <p class="help">Final amount after discount</p>
                            </div>
                        </div>
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Amount Paid (₱)</label>
                                <div class="control">
                                    <input class="input" type="number" id="amountPaid" placeholder="0.00" step="0.01" min="0" />
                                </div>
                                <p class="help">Amount received from customer</p>
                            </div>
                        </div>
                        <div class="column is-4">
                            <div class="field">
                                <label class="label">Balance (₱)</label>
                                <div class="control">
                                    <input class="input has-text-weight-bold" type="text" id="balance" value="₱0.00" readonly />
                                </div>
                                <p class="help">Remaining amount</p>
                            </div>
                        </div>
                    </div>

                    <!-- Hidden field for form submission -->
                    <input type="hidden" id="amountDue" />
                </div>

                <!-- Items Section -->
                <div class="field">
                    <label class="label">Withdrawal Items *</label>
                    <div class="control">
                        <button type="button" class="button is-info is-small" id="addItemBtn">
                            <span class="icon">
                                <i class="fas fa-plus"></i>
                            </span>
                            <span>Add Item</span>
                        </button>
                    </div>
                </div>

                <div id="itemsContainer">
                    <!-- Dynamic withdrawal items will be added here -->
                </div>
            </form>
        </section>
        <footer class="modal-card-foot">
            <button class="button is-success" id="saveWithdrawal">Save Withdrawal</button>
        </footer>
    </div>
</div>

<!-- View Withdrawal Modal -->
<div class="modal" id="viewWithdrawalModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Withdrawal Details</p>
            <!-- X close button removed -->
        </header>
        <section class="modal-card-body">
            <div id="withdrawalDetails">
                <!-- Withdrawal details will be loaded here -->
            </div>
        </section>
        <footer class="modal-card-foot">
            <button class="button" id="closeViewModalBtn">Close</button>
        </footer>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal" id="deleteModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Confirm Delete</p>
            <button class="delete" aria-label="close" id="closeDeleteModal"></button>
        </header>
        <section class="modal-card-body">
            <div class="content">
                <p>Are you sure you want to delete this withdrawal?</p>
                <p><strong id="deleteWithdrawalInfo"></strong></p>
                <p class="has-text-danger">This action cannot be undone and may affect inventory records.</p>
            </div>
        </section>
        <footer class="modal-card-foot">
            <button class="button is-danger" id="confirmDelete">Delete Withdrawal</button>
            <button class="button" id="cancelDelete">Cancel</button>
        </footer>
    </div>
</div>

<!-- Hidden Print Area -->
<div id="withdrawalPrintArea" style="display: none;">
    <!-- Print content will be generated here -->
</div>

<!-- JavaScript -->
<script>
// Configure pagination settings
window.withdrawalConfig = {
    itemsPerPage: 4,
    defaultPage: 1
};
</script>
<script src="js/inventory_withdrawals_fixed.js?v=<?php echo time(); ?>"></script>

    </div> <!-- End of container from header.php -->
</body>
</html> 