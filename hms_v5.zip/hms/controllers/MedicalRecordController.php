<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once __DIR__ . '/../config/config.php';

// Start output buffering to catch any unwanted output
ob_start();

class MedicalRecordController {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'list':
                    $this->listMedicalRecords();
                    break;
                case 'get':
                    $this->getMedicalRecord();
                    break;
                case 'create':
                    $this->createMedicalRecord();
                    break;
                case 'update':
                    $this->updateMedicalRecord();
                    break;
                case 'delete':
                    $this->deleteMedicalRecord();
                    break;
                default:
                    $this->sendResponse(false, 'Invalid action specified');
            }
        } catch (Exception $e) {
            error_log("Medical Record Controller Error: " . $e->getMessage());
            $this->sendResponse(false, 'An error occurred: ' . $e->getMessage());
        }
    }
    
    private function listMedicalRecords() {
        $page = max(1, intval($_GET['page'] ?? 1));
        $limit = max(1, min(50, intval($_GET['limit'] ?? 8)));
        $offset = ($page - 1) * $limit;
        
        $search = trim($_GET['search'] ?? '');
        $patientId = intval($_GET['patient_id'] ?? 0);
        $doctorId = intval($_GET['doctor_id'] ?? 0);
        $status = trim($_GET['status'] ?? '');
        $sort = trim($_GET['sort'] ?? 'record_date');
        
        // Validate sort field
        $allowedSorts = ['record_date', 'created_at', 'patient_name', 'doctor_name'];
        if (!in_array($sort, $allowedSorts)) {
            $sort = 'record_date';
        }
        
        // Build WHERE clause
        $whereConditions = [];
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $whereConditions[] = "(CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) LIKE ? OR 
                                   CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) LIKE ? OR 
                                   mr.diagnosis LIKE ? OR mr.treatment LIKE ? OR mr.subjective LIKE ? OR mr.assessment LIKE ?)";
            $searchParam = "%{$search}%";
            for ($i = 0; $i < 6; $i++) {
                $params[] = $searchParam;
                $types .= 's';
            }
        }
        
        if ($patientId > 0) {
            $whereConditions[] = "mr.patient_id = ?";
            $params[] = $patientId;
            $types .= 'i';
        }
        
        if ($doctorId > 0) {
            $whereConditions[] = "mr.doctor_id = ?";
            $params[] = $doctorId;
            $types .= 'i';
        }
        
        if (!empty($status)) {
            $whereConditions[] = "mr.status = ?";
            $params[] = $status;
            $types .= 's';
        }
        
        $whereClause = '';
        if (!empty($whereConditions)) {
            $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        }
        
        // Determine ORDER BY clause
        $orderBy = '';
        switch ($sort) {
            case 'patient_name':
                $orderBy = 'ORDER BY p.first_name, p.last_name';
                break;
            case 'doctor_name':
                $orderBy = 'ORDER BY d.first_name, d.last_name';
                break;
            case 'created_at':
                $orderBy = 'ORDER BY mr.created_at DESC';
                break;
            case 'record_date':
            default:
                $orderBy = 'ORDER BY mr.record_date DESC';
                break;
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total 
                     FROM medical_records mr 
                     LEFT JOIN patients p ON mr.patient_id = p.patient_id 
                     LEFT JOIN doctors d ON mr.doctor_id = d.doctor_id 
                     {$whereClause}";
        
        $countStmt = $this->conn->prepare($countSql);
        
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        
        $countStmt->execute();
        $countResult = $countStmt->get_result();
        $totalRecords = $countResult->fetch_assoc()['total'];
        $totalPages = ceil($totalRecords / $limit);
        
        // Get medical records with patient and doctor names
        $sql = "SELECT mr.*, 
                       CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) AS patient_name,
                       CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) AS doctor_name
                FROM medical_records mr 
                LEFT JOIN patients p ON mr.patient_id = p.patient_id 
                LEFT JOIN doctors d ON mr.doctor_id = d.doctor_id 
                {$whereClause} 
                {$orderBy}
                LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($sql);
        
        $allParams = $params;
        $allTypes = $types;
        $allParams[] = $limit;
        $allParams[] = $offset;
        $allTypes .= 'ii';
        
        if (!empty($allParams)) {
            $stmt->bind_param($allTypes, ...$allParams);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $records = [];
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
        
        $this->sendResponse(true, 'Medical records retrieved successfully', [
            'data' => [
                'medical_records' => $records,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => $totalPages,
                    'total_records' => $totalRecords,
                    'records_per_page' => $limit
                ]
            ]
        ]);
    }
    
    private function getMedicalRecord() {
        $recordId = intval($_GET['id'] ?? 0);
        
        if ($recordId <= 0) {
            $this->sendResponse(false, 'Valid record ID is required');
            return;
        }
        
        $sql = "SELECT mr.*, 
                       CONCAT(p.first_name, ' ', COALESCE(p.middle_name, ''), ' ', p.last_name) AS patient_name,
                       CONCAT(d.first_name, ' ', COALESCE(d.middle_name, ''), ' ', d.last_name) AS doctor_name
                FROM medical_records mr 
                LEFT JOIN patients p ON mr.patient_id = p.patient_id 
                LEFT JOIN doctors d ON mr.doctor_id = d.doctor_id 
                WHERE mr.record_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $recordId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($record = $result->fetch_assoc()) {
            $this->sendResponse(true, 'Medical record retrieved successfully', [
                'record' => $record
            ]);
        } else {
            $this->sendResponse(false, 'Medical record not found');
        }
    }
    
    private function createMedicalRecord() {
        $patientId = intval($_POST['patient_id'] ?? 0);
        $doctorId = intval($_POST['doctor_id'] ?? 0);
        $recordDate = trim($_POST['record_date'] ?? '');
        $status = trim($_POST['status'] ?? 'active');
        
        // Vital signs
        $heightCm = floatval($_POST['height_cm'] ?? 0) ?: null;
        $weightKg = floatval($_POST['weight_kg'] ?? 0) ?: null;
        $bmi = floatval($_POST['bmi'] ?? 0) ?: null;
        $bloodPressure = trim($_POST['blood_pressure'] ?? '') ?: null;
        $heartRate = intval($_POST['heart_rate'] ?? 0) ?: null;
        $temperatureC = floatval($_POST['temperature_c'] ?? 0) ?: null;
        $respiratoryRate = intval($_POST['respiratory_rate'] ?? 0) ?: null;
        
        // SOAP notes
        $subjective = trim($_POST['subjective'] ?? '') ?: null;
        $objective = trim($_POST['objective'] ?? '') ?: null;
        $assessment = trim($_POST['assessment'] ?? '') ?: null;
        $plan = trim($_POST['plan'] ?? '') ?: null;
        
        // Diagnosis and treatment
        $diagnosis = trim($_POST['diagnosis'] ?? '') ?: null;
        $treatment = trim($_POST['treatment'] ?? '') ?: null;
        
        // Validation
        $errors = $this->validateMedicalRecordData($patientId, $doctorId, $recordDate, $status);
        if (!empty($errors)) {
            $this->sendResponse(false, implode(', ', $errors));
            return;
        }
        
        // Handle lab images upload
        $labImagesJson = null;
        if (isset($_FILES['lab_images']) && is_array($_FILES['lab_images']['name'])) {
            $uploadResult = $this->handleLabImagesUpload($_FILES['lab_images']);
            if ($uploadResult['success']) {
                $labImagesJson = json_encode($uploadResult['images']);
            } else {
                $this->sendResponse(false, 'File upload error: ' . $uploadResult['message']);
                return;
            }
        }
        
        // Check if patient exists
        if (!$this->patientExists($patientId)) {
            $this->sendResponse(false, 'Selected patient does not exist');
            return;
        }
        
        // Check if doctor exists
        if (!$this->doctorExists($doctorId)) {
            $this->sendResponse(false, 'Selected doctor does not exist');
            return;
        }
        
        $sql = "INSERT INTO medical_records (patient_id, doctor_id, record_date, status, 
                                           height_cm, weight_kg, bmi, blood_pressure, heart_rate, temperature_c, respiratory_rate,
                                           subjective, objective, assessment, plan, diagnosis, treatment, lab_images,
                                           created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('iissdddsidssssssss', 
            $patientId, $doctorId, $recordDate, $status,
            $heightCm, $weightKg, $bmi, $bloodPressure, $heartRate, $temperatureC, $respiratoryRate,
            $subjective, $objective, $assessment, $plan, $diagnosis, $treatment, $labImagesJson
        );
        
        if ($stmt->execute()) {
            $recordId = $this->conn->insert_id;
            
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Created medical record for patient ID: {$patientId}");
            
            $this->sendResponse(true, 'Medical record created successfully', [
                'record_id' => $recordId
            ]);
        } else {
            $this->sendResponse(false, 'Failed to create medical record');
        }
    }
    
    private function updateMedicalRecord() {
        $recordId = intval($_POST['record_id'] ?? 0);
        $patientId = intval($_POST['patient_id'] ?? 0);
        $doctorId = intval($_POST['doctor_id'] ?? 0);
        $recordDate = trim($_POST['record_date'] ?? '');
        $status = trim($_POST['status'] ?? 'active');
        
        // Vital signs
        $heightCm = floatval($_POST['height_cm'] ?? 0) ?: null;
        $weightKg = floatval($_POST['weight_kg'] ?? 0) ?: null;
        $bmi = floatval($_POST['bmi'] ?? 0) ?: null;
        $bloodPressure = trim($_POST['blood_pressure'] ?? '') ?: null;
        $heartRate = intval($_POST['heart_rate'] ?? 0) ?: null;
        $temperatureC = floatval($_POST['temperature_c'] ?? 0) ?: null;
        $respiratoryRate = intval($_POST['respiratory_rate'] ?? 0) ?: null;
        
        // SOAP notes
        $subjective = trim($_POST['subjective'] ?? '') ?: null;
        $objective = trim($_POST['objective'] ?? '') ?: null;
        $assessment = trim($_POST['assessment'] ?? '') ?: null;
        $plan = trim($_POST['plan'] ?? '') ?: null;
        
        // Diagnosis and treatment
        $diagnosis = trim($_POST['diagnosis'] ?? '') ?: null;
        $treatment = trim($_POST['treatment'] ?? '') ?: null;
        
        if ($recordId <= 0) {
            $this->sendResponse(false, 'Valid record ID is required');
            return;
        }
        
        // Validation
        $errors = $this->validateMedicalRecordData($patientId, $doctorId, $recordDate, $status);
        if (!empty($errors)) {
            $this->sendResponse(false, implode(', ', $errors));
            return;
        }
        
        // Handle lab images upload
        $labImagesJson = null;
        $updateLabImages = false;
        if (isset($_FILES['lab_images']) && is_array($_FILES['lab_images']['name']) && !empty($_FILES['lab_images']['name'][0])) {
            $uploadResult = $this->handleLabImagesUpload($_FILES['lab_images']);
            if ($uploadResult['success']) {
                $labImagesJson = json_encode($uploadResult['images']);
                $updateLabImages = true;
            } else {
                $this->sendResponse(false, 'File upload error: ' . $uploadResult['message']);
                return;
            }
        }
        
        // Check if record exists
        if (!$this->recordExists($recordId)) {
            $this->sendResponse(false, 'Medical record not found');
            return;
        }
        
        // Check if patient exists
        if (!$this->patientExists($patientId)) {
            $this->sendResponse(false, 'Selected patient does not exist');
            return;
        }
        
        // Check if doctor exists
        if (!$this->doctorExists($doctorId)) {
            $this->sendResponse(false, 'Selected doctor does not exist');
            return;
        }
        
        if ($updateLabImages) {
            $sql = "UPDATE medical_records 
                    SET patient_id = ?, doctor_id = ?, record_date = ?, status = ?, 
                        height_cm = ?, weight_kg = ?, bmi = ?, blood_pressure = ?, heart_rate = ?, temperature_c = ?, respiratory_rate = ?,
                        subjective = ?, objective = ?, assessment = ?, plan = ?, diagnosis = ?, treatment = ?, lab_images = ?,
                        updated_at = NOW() 
                    WHERE record_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('iissdddsidssssssssi', 
                $patientId, $doctorId, $recordDate, $status,
                $heightCm, $weightKg, $bmi, $bloodPressure, $heartRate, $temperatureC, $respiratoryRate,
                $subjective, $objective, $assessment, $plan, $diagnosis, $treatment, $labImagesJson,
                $recordId
            );
        } else {
            $sql = "UPDATE medical_records 
                    SET patient_id = ?, doctor_id = ?, record_date = ?, status = ?, 
                        height_cm = ?, weight_kg = ?, bmi = ?, blood_pressure = ?, heart_rate = ?, temperature_c = ?, respiratory_rate = ?,
                        subjective = ?, objective = ?, assessment = ?, plan = ?, diagnosis = ?, treatment = ?,
                        updated_at = NOW() 
                    WHERE record_id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('iissdddsidsssssssi', 
                $patientId, $doctorId, $recordDate, $status,
                $heightCm, $weightKg, $bmi, $bloodPressure, $heartRate, $temperatureC, $respiratoryRate,
                $subjective, $objective, $assessment, $plan, $diagnosis, $treatment,
                $recordId
            );
        }
        
        if ($stmt->execute()) {
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Updated medical record ID: {$recordId}");
            
            $this->sendResponse(true, 'Medical record updated successfully');
        } else {
            $this->sendResponse(false, 'Failed to update medical record');
        }
    }
    
    private function deleteMedicalRecord() {
        $recordId = intval($_POST['record_id'] ?? 0);
        
        if ($recordId <= 0) {
            $this->sendResponse(false, 'Valid record ID is required');
            return;
        }
        
        // Check if record exists
        if (!$this->recordExists($recordId)) {
            $this->sendResponse(false, 'Medical record not found');
            return;
        }
        
        $sql = "DELETE FROM medical_records WHERE record_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $recordId);
        
        if ($stmt->execute()) {
            // Log the action
            $this->logAction($_SESSION['user_id'] ?? null, "Deleted medical record ID: {$recordId}");
            
            $this->sendResponse(true, 'Medical record deleted successfully');
        } else {
            $this->sendResponse(false, 'Failed to delete medical record');
        }
    }
    
    private function validateMedicalRecordData($patientId, $doctorId, $recordDate, $status) {
        $errors = [];
        
        if ($patientId <= 0) {
            $errors[] = 'Patient selection is required';
        }
        
        if ($doctorId <= 0) {
            $errors[] = 'Doctor selection is required';
        }
        
        if (empty($recordDate)) {
            $errors[] = 'Record date is required';
        } elseif (!$this->isValidDateTime($recordDate)) {
            $errors[] = 'Invalid record date format';
        }
        
        if (empty($status)) {
            $errors[] = 'Status is required';
        } elseif (!in_array($status, ['active', 'archived'])) {
            $errors[] = 'Invalid status. Must be active or archived';
        }
        
        return $errors;
    }
    
    private function isValidDateTime($dateTime) {
        $d = DateTime::createFromFormat('Y-m-d\TH:i', $dateTime);
        return $d && $d->format('Y-m-d\TH:i') === $dateTime;
    }
    
    private function recordExists($recordId) {
        $sql = "SELECT COUNT(*) as count FROM medical_records WHERE record_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $recordId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }
    
    private function patientExists($patientId) {
        $sql = "SELECT COUNT(*) as count FROM patients WHERE patient_id = ? AND status = 'active'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $patientId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }
    
    private function doctorExists($doctorId) {
        $sql = "SELECT COUNT(*) as count FROM doctors WHERE doctor_id = ? AND status = 'active'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $doctorId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'] > 0;
    }
    
    private function handleLabImagesUpload($files) {
        // Create upload directory if it doesn't exist
        $uploadDir = __DIR__ . '/../uploads/lab_results/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/pdf'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        $maxFiles = 5;
        
        $uploadedImages = [];
        $fileCount = count($files['name']);
        
        if ($fileCount > $maxFiles) {
            return ['success' => false, 'message' => "Maximum {$maxFiles} files allowed"];
        }
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($files['error'][$i] !== UPLOAD_ERR_OK) {
                continue; // Skip files with errors
            }
            
            $fileName = $files['name'][$i];
            $fileType = $files['type'][$i];
            $fileSize = $files['size'][$i];
            $fileTmpName = $files['tmp_name'][$i];
            
            // Validate file type
            if (!in_array($fileType, $allowedTypes)) {
                return ['success' => false, 'message' => "Invalid file type: {$fileName}. Only JPG, PNG, GIF, and PDF files are allowed."];
            }
            
            // Validate file size
            if ($fileSize > $maxSize) {
                return ['success' => false, 'message' => "File too large: {$fileName}. Maximum size is 5MB."];
            }
            
            // Generate unique filename
            $extension = pathinfo($fileName, PATHINFO_EXTENSION);
            $uniqueFileName = 'lab_' . time() . '_' . uniqid() . '.' . $extension;
            $filePath = $uploadDir . $uniqueFileName;
            
            // Move uploaded file
            if (move_uploaded_file($fileTmpName, $filePath)) {
                $uploadedImages[] = [
                    'filename' => $uniqueFileName,
                    'original_name' => $fileName,
                    'file_type' => $fileType,
                    'file_size' => $this->formatFileSize($fileSize),
                    'upload_date' => date('Y-m-d H:i:s')
                ];
            } else {
                return ['success' => false, 'message' => "Failed to upload file: {$fileName}"];
            }
        }
        
        return ['success' => true, 'images' => $uploadedImages];
    }
    
    private function formatFileSize($bytes) {
        if ($bytes === 0) return '0 Bytes';
        $k = 1024;
        $sizes = ['Bytes', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes) / log($k));
        return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
    }
    
    private function logAction($userId, $action) {
        if ($userId) {
            $sql = "INSERT INTO system_logs (user_id, action, log_timestamp) VALUES (?, ?, NOW())";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('is', $userId, $action);
            $stmt->execute();
        }
    }
    
    private function sendResponse($success, $message, $data = null) {
        // Clear any output buffer
        ob_clean();
        
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if ($data !== null) {
            $response = array_merge($response, $data);
        }
        
        echo json_encode($response);
        exit;
    }
}

// Check authentication
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    ob_end_clean();
    header('Content-Type: application/json');
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Initialize controller and handle request
try {
    ob_end_clean();
    header('Content-Type: application/json');
    $controller = new MedicalRecordController($conn);
    $controller->handleRequest();
} catch (Exception $e) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
?> 