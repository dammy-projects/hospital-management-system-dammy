<?php
// Suppress error output to prevent HTML before JSON
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/InventoryItem.php';

// Start output buffering to catch any unwanted output
ob_start();

class InventoryItemController {
    private $inventoryItem;
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
        $this->inventoryItem = new InventoryItem($connection);
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        header('Content-Type: application/json');
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGetRequest();
                    break;
                case 'POST':
                    $this->handlePostRequest();
                    break;
                default:
                    $this->sendResponse(false, 'Method not allowed', null, 405);
                    break;
            }
        } catch (Exception $e) {
            error_log("InventoryItemController Error: " . $e->getMessage());
            $this->sendResponse(false, 'Internal server error: ' . $e->getMessage(), null, 500);
        }
    }
    
    private function handleGetRequest() {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'getItems':
                $this->getItems();
                break;
            case 'getItem':
                $this->getItem();
                break;
            case 'getCategories':
                $this->getCategories();
                break;
            default:
                $this->sendResponse(false, 'Invalid action: ' . $action);
                break;
        }
    }
    
    private function handlePostRequest() {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['action'])) {
            $this->sendResponse(false, 'Invalid input data');
            return;
        }
        
        $action = $input['action'];
        
        switch ($action) {
            case 'createItem':
                $this->createItem($input);
                break;
            case 'updateItem':
                $this->updateItem($input);
                break;
            case 'deleteItem':
                $this->deleteItem($input);
                break;
            default:
                $this->sendResponse(false, 'Invalid action: ' . $action);
                break;
        }
    }
    
    private function getItems() {
        try {
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = max(1, intval($_GET['limit'] ?? 8));
            $search = trim($_GET['search'] ?? '');
            $categoryFilter = trim($_GET['category'] ?? '');
            $statusFilter = trim($_GET['status'] ?? '');
            $stockFilter = trim($_GET['stock'] ?? '');
            $sortBy = trim($_GET['sort'] ?? 'item_name');
            $sortOrder = strtoupper(trim($_GET['order'] ?? 'ASC'));
            
            // Use the existing model method
            $items = $this->inventoryItem->getItems($page, $limit, $search, $categoryFilter, $statusFilter, $stockFilter);
            $totalItems = $this->inventoryItem->getTotalItems($search, $categoryFilter, $statusFilter, $stockFilter);
            
            // Transform data to match expected format
            $transformedItems = [];
            foreach ($items as $item) {
                $transformedItems[] = [
                    'id' => $item['item_id'],
                    'item_name' => $item['item_name'],
                    'description' => $item['item_description'] ?? '',
                    'serial_number' => $item['serial_number'] ?? '',
                    'product_number' => $item['product_number'] ?? '',
                    'category_id' => $item['category_id'],
                    'category_name' => $item['category_name'] ?? '',
                    'quantity_in_stock' => $item['quantity_in_stock'],
                    'unit' => $item['unit'] ?? '',
                    'price' => $item['price'] ?? '0.00',
                    'reorder_level' => $item['reorder_level'] ?? 0,
                    'status' => $item['status'],
                    'last_updated' => $item['last_updated'] ?? ''
                ];
            }
            
            $this->sendResponse(true, 'Items retrieved successfully', [
                'items' => $transformedItems,
                'total' => intval($totalItems),
                'page' => $page,
                'limit' => $limit,
                'pages' => ceil($totalItems / $limit)
            ]);
            
        } catch (Exception $e) {
            error_log("Error in getItems: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to retrieve items: ' . $e->getMessage());
        }
    }
    
    private function getItem() {
        try {
            $itemId = intval($_GET['id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendResponse(false, 'Invalid item ID');
                return;
            }
            
            $item = $this->inventoryItem->getItemById($itemId);
            
            if (!$item) {
                $this->sendResponse(false, 'Item not found');
                return;
            }
            
            // Transform data to match expected format
            $transformedItem = [
                'id' => $item['item_id'],
                'item_name' => $item['item_name'],
                'description' => $item['item_description'] ?? '',
                'serial_number' => $item['serial_number'] ?? '',
                'product_number' => $item['product_number'] ?? '',
                'category_id' => $item['category_id'],
                'category_name' => $item['category_name'] ?? '',
                'quantity_in_stock' => $item['quantity_in_stock'],
                'unit' => $item['unit'] ?? '',
                'price' => $item['price'] ?? '0.00',
                'reorder_level' => $item['reorder_level'] ?? 0,
                'status' => $item['status'],
                'last_updated' => $item['last_updated'] ?? ''
            ];
            
            $this->sendResponse(true, 'Item retrieved successfully', ['item' => $transformedItem]);
            
        } catch (Exception $e) {
            error_log("Error in getItem: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to retrieve item: ' . $e->getMessage());
        }
    }
    
    private function getCategories() {
        try {
            $categories = $this->inventoryItem->getCategories();
            
            // Transform data to match expected format
            $transformedCategories = [];
            foreach ($categories as $category) {
                $transformedCategories[] = [
                    'id' => $category['category_id'],
                    'name' => $category['category_name'],
                    'description' => '' // No description field in the database
                ];
            }
            
            $this->sendResponse(true, 'Categories retrieved successfully', ['categories' => $transformedCategories]);
            
        } catch (Exception $e) {
            error_log("Error in getCategories: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to retrieve categories: ' . $e->getMessage());
        }
    }
    
    private function createItem($data) {
        try {
            // Validate required fields
            $requiredFields = ['item_name', 'category_id', 'quantity_in_stock', 'price'];
            foreach ($requiredFields as $field) {
                if (empty($data[$field]) && $data[$field] !== '0') {
                    $this->sendResponse(false, "Field '$field' is required");
                    return;
                }
            }
            
            // Validate numeric fields
            if (!is_numeric($data['quantity_in_stock']) || $data['quantity_in_stock'] < 0) {
                $this->sendResponse(false, 'Quantity in stock must be a valid non-negative number');
                return;
            }
            
            if (!is_numeric($data['price']) || $data['price'] < 0) {
                $this->sendResponse(false, 'Price must be a valid non-negative number');
                return;
            }
            
            if (isset($data['reorder_level']) && !empty($data['reorder_level'])) {
                if (!is_numeric($data['reorder_level']) || $data['reorder_level'] < 0) {
                    $this->sendResponse(false, 'Reorder level must be a valid non-negative number');
                    return;
                }
            }
            
            // Prepare data for model
            $itemData = [
                'item_name' => $data['item_name'],
                'item_description' => $data['description'] ?? '',
                'serial_number' => $data['serial_number'] ?? '',
                'product_number' => $data['product_number'] ?? '',
                'category_id' => $data['category_id'],
                'quantity_in_stock' => $data['quantity_in_stock'],
                'unit' => $data['unit'] ?? '',
                'price' => $data['price'],
                'reorder_level' => $data['reorder_level'] ?? 0,
                'status' => $data['status'] ?? 'active'
            ];
            
            $itemId = $this->inventoryItem->createItem($itemData);
            
            if ($itemId) {
                $this->sendResponse(true, 'Item created successfully', ['item_id' => $itemId]);
            } else {
                $this->sendResponse(false, 'Failed to create item');
            }
            
        } catch (Exception $e) {
            error_log("Error in createItem: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to create item: ' . $e->getMessage());
        }
    }
    
    private function updateItem($data) {
        try {
            $itemId = intval($data['id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendResponse(false, 'Invalid item ID');
                return;
            }
            
            // Check if item exists
            $existingItem = $this->inventoryItem->getItemById($itemId);
            if (!$existingItem) {
                $this->sendResponse(false, 'Item not found');
                return;
            }
            
            // Validate required fields
            $requiredFields = ['item_name', 'category_id', 'quantity_in_stock', 'price'];
            foreach ($requiredFields as $field) {
                if (empty($data[$field]) && $data[$field] !== '0') {
                    $this->sendResponse(false, "Field '$field' is required");
                    return;
                }
            }
            
            // Validate numeric fields
            if (!is_numeric($data['quantity_in_stock']) || $data['quantity_in_stock'] < 0) {
                $this->sendResponse(false, 'Quantity in stock must be a valid non-negative number');
                return;
            }
            
            if (!is_numeric($data['price']) || $data['price'] < 0) {
                $this->sendResponse(false, 'Price must be a valid non-negative number');
                return;
            }
            
            if (isset($data['reorder_level']) && !empty($data['reorder_level'])) {
                if (!is_numeric($data['reorder_level']) || $data['reorder_level'] < 0) {
                    $this->sendResponse(false, 'Reorder level must be a valid non-negative number');
                    return;
                }
            }
            
            // Prepare data for model
            $itemData = [
                'item_name' => $data['item_name'],
                'item_description' => $data['description'] ?? '',
                'serial_number' => $data['serial_number'] ?? '',
                'product_number' => $data['product_number'] ?? '',
                'category_id' => $data['category_id'],
                'quantity_in_stock' => $data['quantity_in_stock'],
                'unit' => $data['unit'] ?? '',
                'price' => $data['price'],
                'reorder_level' => $data['reorder_level'] ?? 0,
                'status' => $data['status'] ?? 'active'
            ];
            
            $result = $this->inventoryItem->updateItem($itemId, $itemData);
            
            if ($result) {
                $this->sendResponse(true, 'Item updated successfully');
            } else {
                $this->sendResponse(false, 'Failed to update item');
            }
            
        } catch (Exception $e) {
            error_log("Error in updateItem: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to update item: ' . $e->getMessage());
        }
    }
    
    private function deleteItem($data) {
        try {
            $itemId = intval($data['id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendResponse(false, 'Invalid item ID');
                return;
            }
            
            // Check if item exists
            $item = $this->inventoryItem->getItemById($itemId);
            if (!$item) {
                $this->sendResponse(false, 'Item not found');
                return;
            }
            
            $result = $this->inventoryItem->deleteItem($itemId);
            
            if ($result) {
                $this->sendResponse(true, 'Item "' . $item['item_name'] . '" deleted successfully');
            } else {
                $this->sendResponse(false, 'Failed to delete item');
            }
            
        } catch (Exception $e) {
            error_log("Error in deleteItem: " . $e->getMessage());
            $this->sendResponse(false, 'Failed to delete item: ' . $e->getMessage());
        }
    }
    
    private function sendResponse($success, $message, $data = null, $statusCode = 200) {
        // Clean any output buffer
        if (ob_get_level()) {
            ob_clean();
        }
        
        http_response_code($statusCode);
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if ($data !== null) {
            $response = array_merge($response, $data);
        }
        
        echo json_encode($response);
        exit;
    }
}

// Handle the request
try {
    $controller = new InventoryItemController($conn);
    $controller->handleRequest();
} catch (Exception $e) {
    ob_end_clean();
    header('Content-Type: application/json');
    error_log("InventoryItemController Fatal Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'A fatal error occurred']);
}
?> 